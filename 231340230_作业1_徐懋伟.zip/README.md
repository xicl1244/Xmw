# 课程学习与作业管理平台（Vue 3 组件化 + REST 契约设计）

课外作业 1 的完整实现：组件设计、状态管理、REST 接口契约、按契约实现的 Mock 后端、编码规范与无障碍。

- 前端：Vite + Vue 3 + TypeScript + Vue Router + Pinia + Axios（展示组件全部自研，无 UI 框架依赖）
- 后端：Node.js + Express 的 Mock 服务，严格按 `docs/api-contract-v1.md` 实现，并提供 Swagger UI
- 契约：`docs/api-contract-v1.md`（v1.0.0，19 个端点）
- 说明文档：`作业1-说明.md`（A / B / C / D 四部分）
- 契约自检：`npm run test:api`（48 条用例 + 信封一致性 + 敏感字段扫描）

> 项目内全部数据为虚构示例数据（姓名虚构，邮箱统一 `example.com` 域），不含任何真实个人信息。

---

## 快速开始

```bash
npm install        # 安装依赖（含前端与 Mock 服务依赖）

npm run server     # 终端 1：启动 Mock 后端（http://localhost:3000，Swagger UI：/api-docs）
npm run dev        # 终端 2：启动前端（http://localhost:5173）
```

也可以一条命令同时启动两者：`npm run dev:all`

打开 <http://localhost:5173> 即可看到概览页。页面右上角可切换演示身份（教师 / 学生 / 管理员），用于观察按钮权限与 `403` 响应。

| 演示账号 | 角色 | 口令 |
| --- | --- | --- |
| `t1001` | teacher | `Demo@1234` |
| `s2026001` | student | `Demo@1234` |
| `admin` | admin | `Demo@1234` |

> 口令只存在于 Mock 服务的用户数据与登录请求体中，**任何响应都不会回传口令字段**（契约自检脚本会逐条扫描）。

## 全部脚本

| 命令 | 作用 |
| --- | --- |
| `npm run dev` | 启动前端开发服务器（`/api` 代理到 `localhost:3000`） |
| `npm run server` | 启动契约 Mock 服务（Express + Swagger UI） |
| `npm run dev:all` | 同时启动前端与 Mock 服务 |
| `npm run lint` | ESLint 检查，`--max-warnings 0`（要求零错误零警告） |
| `npm run lint:fix` | ESLint 自动修复 |
| `npm run format` / `npm run format:check` | Prettier 格式化 / 校验 |
| `npm run type-check` | `vue-tsc` 类型检查 |
| `npm run build` | 类型检查 + 生产构建（产物在 `dist/`） |
| `npm run test:api` | 契约自检：自行拉起 Mock 服务（端口 3100）并执行 48 条用例 |

对已经运行中的服务做自检（PowerShell 示例）：

```powershell
$env:SMOKE_BASE_URL="http://localhost:3000/api/v1"; npm run test:api
```

## 目录结构

- `docs/api-contract-v1.md` —— C 部分：接口契约（前后端唯一依据）
- `server/` —— 契约 Mock 服务
  - `index.js`：19 个端点的实现（信封、权限、校验、业务规则）
  - `openapi.js`：OpenAPI 3.0 描述，供 Swagger UI 使用
  - `codes.js`：业务状态码表（与契约第 3 节一一对应）
  - `seed.js`：虚构示例数据（时间相对服务启动时刻生成）
- `scripts/api-smoke.mjs` —— 契约自检脚本（48 条用例）
- `src/components/` —— A 部分：可复用展示组件
  - `CourseCard.vue`：课程卡片（卡片视图 / 详情抽屉 / 概览页三处复用）
  - `AppStatCard.vue`：统计卡（概览页 4 个 + 课程页 3 个实例）
  - `StatusTag.vue`：状态标签（英文枚举 → 文字 + 符号 + 颜色）
  - `AppPagination.vue`：分页器（课程列表 + 作业列表）
  - `EmptyState.vue`：空态（课程列表 + 作业列表）
  - `CourseDetailDrawer.vue` / `CourseFormDialog.vue`：容器组件（取数、校验、编排）
- `src/views/` —— `DashboardView.vue` / `CourseListView.vue` / `AssignmentListView.vue` / `NotFoundView.vue`
- `src/stores/` —— B 部分：`course.ts`（含两条状态一致性规则）/ `assignment.ts` / `auth.ts`
- `src/services/` —— 唯一出现 `axios` 的地方：`api.ts`（拦截器、拆信封、`ApiError`）+ 三个 service
- `src/types/` —— 与契约一一对应的 TS 类型：`api.ts` / `course.ts` / `assignment.ts` / `user.ts`
- `src/assets/main.css` —— 设计令牌、`:focus-visible` 焦点样式、行高 1.6
- `evidence/` —— D 部分证据（lint 输出、git 日志、无障碍截图）
- `作业1-说明.md` —— A / B / C / D 四部分说明文档
- `仓库地址.txt` —— 仓库 URL 与提交号列表

## 一次请求的完整链路

1. 展示组件通过 `emit` 把用户意图抛给页面（组件内没有 `axios`、不读 `route` / `store`）；
2. 页面调用 store 的 action（例如 `courseStore.applyQuery({ status })`）；
3. store 调用 `src/services`，`axios` 以 `baseURL=/api/v1` 发请求；
4. Vite 把 `/api` 代理到 `http://localhost:3000`，Express Mock 按契约返回统一信封 `{ code, message, data, timestamp, requestId }`；
5. 响应拦截器拆信封：成功 resolve `data`，失败抛出 `ApiError(code, httpStatus, errors)`；
6. store 写入 `list` / `total` / `page` / `error`，组件重新渲染。

切换到真实后端时不需要改业务代码，只需把 `vite.config.ts` 中 `server.proxy['/api'].target` 指向真实服务地址（生产环境同域部署时可直接删除代理）。

## 契约要点（详见 `docs/api-contract-v1.md`）

1. **统一信封**：`code` / `message` / `data` / `timestamp` / `requestId`，失败响应同样遵守；`data: null` 表示无数据。
2. **业务失败用 HTTP 200**：`30001`（业务冲突）、`30002`（规则不满足）返回 200；参数错误 400、未登录 401、权限不足 403、资源不存在 404。
3. **分页**：`list / total / page / size`；`page` 越界时返回最后一页并回写实际页码；`size` 允许 1~100。
4. **排序**：白名单 + `id,asc` 兜底，保证翻页结果稳定。
5. **删除语义**：课程为软删除（`status=archived`，列表默认不返回）；删除成功统一 `200` + `data: null`，不用 204。
6. **权限**：教师只能维护 `teacherName` 为本人姓名的课程；学生只能为本人选课、退选本人课程。
7. **敏感字段**：口令只出现在请求体中，任何响应不得回传。

## 常见问题

1. **页面提示"无法连接后端服务"**：Mock 服务没有启动，另开一个终端执行 `npm run server`。
2. **端口被占用**：Mock 默认 3000、前端默认 5173。Mock 可用 `node server/index.js --port 3100` 换端口（同时修改 `vite.config.ts` 的代理 target）；前端可用 `npm run dev -- --port 5174`。
3. **切换身份后按钮消失**：这是刻意的权限演示 —— 学生身份看不到"新建 / 编辑 / 删除"，直接调用接口会收到 `403` + `20002`。
4. **删除课程后还能搜到它**：课程是软删除，把状态筛选切到"已归档"即可看到（契约第 6.2 节）。
5. **控制台出现 Vue DevTools 相关提示**：`vite-plugin-vue-devtools` 仅在开发环境生效，不影响构建；不需要可在 `vite.config.ts` 中移除。
