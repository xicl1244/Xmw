# 证据文件说明（D 部分 + C 部分）

本目录保存作业中可复现的证据。所有截图都来自**本仓库真实运行**的页面与命令输出，没有手工绘制。
复现方式见每张图下方的命令。

## 一、命令输出

| 文件 | 内容 | 复现命令 |
| --- | --- | --- |
| `lint.txt` | `npm run lint` 的完整原始输出（0 error / 0 warning） | `npm run lint` |
| `gitlog.txt` | `git log --oneline` 与 `git shortlog -sne HEAD` 的原始输出 | `git log --oneline` |
| `api-smoke.txt` | 契约自检的完整输出：48 条用例、信封一致性、敏感字段扫描 | `npm run test:api` |
| `lint.png` | 上述 `lint.txt` 内容在深色终端样式下的截图（便于直接放进作业包） | 见下方"截图的生成方式" |
| `gitlog.png` | 上述 `gitlog.txt` 内容的截图 | 同上 |

## 二、界面截图

| 文件 | 页面 / 场景 | 对应自查项 |
| --- | --- | --- |
| `ui-dashboard.png` | 概览页：4 个统计指标、最近更新课程、接口契约速览 | 组件复用（`AppStatCard` / `CourseCard`） |
| `ui-course-list.png` | 课程管理页：查询表单、统计行、卡片视图、分页 | A 部分组件装配 |
| `ui-assignments.png` | 作业管理页：表格视图、状态标签、截止时间文字提示 | 状态区分不只依赖颜色 |
| `keyboard-1-query.png` | 键盘输入关键字"数据"并按 Enter 查询，列表剩 2 门课程 | 键盘可完成"进入系统 → 查询" |
| `keyboard-2-detail.png` | 键盘打开"查看详情"，抽屉展示课程、选课名单与基础信息 | 键盘可完成"打开详情" |
| `keyboard-3-form.png` | 键盘打开"新建课程"，焦点自动落在第一个输入框（可见焦点环） | 键盘可完成"新增" |
| `keyboard-4-save.png` | 键盘触发"保存"后列表与统计同步刷新，出现成功提示 | 键盘可完成"保存" + `aria-live` 播报 |
| `focus.png` | 连续按 Tab 后焦点落在"删除"按钮上，`outline` 清晰可见 | `:focus-visible` 焦点样式 |

## 三、截图的生成方式

1. 启动 Mock 服务与前端：`npm run server`、`npm run dev`；
2. 用浏览器打开 <http://localhost:5173>，按上表描述的顺序操作（查询 → 详情 → 新建 → 保存）；
3. 每一步直接对浏览器窗口截图，即为 `keyboard-*.png` 与 `ui-*.png`；
4. `lint.png` / `gitlog.png` 是把 `lint.txt` / `gitlog.txt` 的原文放进一个本地页面后截图得到的，
   文字内容与命令行输出完全一致；如需重新生成，直接对终端窗口截图即可。

## 四、截图中出现的数据说明

- 所有课程名、教师名、学生姓名均为虚构数据，邮箱统一使用 `example.com` 域；
- `keyboard-4-save.png` 中的课程总数（16 门）比初始数据（14 门）多，是因为截图过程中用界面真实新增了
  两门演示课程（`CS9001` / `CS9002`）。Mock 服务的数据保存在内存中，重启 `npm run server` 即回到初始状态。
