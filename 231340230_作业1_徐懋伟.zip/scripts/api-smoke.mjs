/**
 * 契约自检脚本：启动 Mock 服务（独立端口 3100），逐条验证 docs/api-contract-v1.md 的行为。
 * 运行：npm run test:api
 *
 * 它同时验证三件事：
 * 1. 每个端点的成功路径；2. 每个端点的失败路径（校验失败 / 权限不足 / 业务冲突）；
 * 3. 统一信封（code / message / data / timestamp / requestId）在所有响应中都成立，且不含敏感字段。
 */
import { spawn } from 'node:child_process'
import process from 'node:process'

const PORT = 3100
/** 设置 SMOKE_BASE_URL 时直接对已有服务做自检，不再自行拉起 Mock 进程 */
const EXTERNAL_BASE = process.env.SMOKE_BASE_URL
const BASE = EXTERNAL_BASE ? EXTERNAL_BASE.replace(/\/$/, '') : `http://localhost:${PORT}/api/v1`

const results = []
let envelopeViolations = []
const sensitiveHits = []

function check(name, condition, detail = '') {
  results.push({ name, ok: Boolean(condition), detail })
}

function inspectEnvelope(label, json, headers) {
  if (!json || typeof json !== 'object') {
    envelopeViolations.push(`${label}: 响应体不是 JSON 对象`)
    return
  }
  if (typeof json.code !== 'number') envelopeViolations.push(`${label}: code 缺失或不是 number`)
  if (typeof json.message !== 'string') envelopeViolations.push(`${label}: message 缺失`)
  if (!('data' in json)) envelopeViolations.push(`${label}: data 字段缺失`)
  if (typeof json.timestamp !== 'string' || Number.isNaN(Date.parse(json.timestamp)))
    envelopeViolations.push(`${label}: timestamp 不是 ISO 8601 时间`)
  if (typeof json.requestId !== 'string' || json.requestId.length === 0)
    envelopeViolations.push(`${label}: requestId 缺失`)
  const headerId = headers.get('x-request-id')
  if (headerId && headerId !== json.requestId) {
    envelopeViolations.push(`${label}: 响应头 X-Request-Id 与 body.requestId 不一致`)
  }
  const serialized = JSON.stringify(json)
  if (serialized.includes('"password":') || serialized.includes('"tokenHash":')) {
    sensitiveHits.push(`${label}: 响应中出现疑似敏感字段`)
  }
}

async function call(method, path, { token, body } = {}) {
  const headers = {}
  if (token) headers.Authorization = `Bearer ${token}`
  if (body !== undefined) headers['Content-Type'] = 'application/json'
  const response = await fetch(`${BASE}${path}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
  })
  const json = await response.json().catch(() => null)
  inspectEnvelope(`${method} ${path}`, json, response.headers)
  return { status: response.status, body: json }
}

async function waitForServer(timeoutMs = 15000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const response = await fetch(`${BASE}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: 't1001', password: 'Demo@1234' }),
      })
      if (response.ok) return true
    } catch {
      // 服务尚未就绪，继续等待
    }
    await new Promise((resolve) => setTimeout(resolve, 250))
  }
  return false
}

async function run() {
  /* ---------------- 认证 ---------------- */
  const wrongLogin = await call('POST', '/auth/login', {
    body: { username: 't1001', password: 'wrong-password' },
  })
  check(
    '登录失败返回 HTTP 401 + code 20001',
    wrongLogin.status === 401 && wrongLogin.body.code === 20001,
    `实际 ${wrongLogin.status} / ${wrongLogin.body.code}`,
  )

  const loginMissingField = await call('POST', '/auth/login', { body: { username: '' } })
  check(
    '登录缺字段返回 400 + 10001 且带逐字段错误',
    loginMissingField.status === 400 &&
      loginMissingField.body.code === 10001 &&
      Array.isArray(loginMissingField.body.data?.errors),
    `实际 ${loginMissingField.status} / ${loginMissingField.body.code}`,
  )

  const teacherLogin = await call('POST', '/auth/login', {
    body: { username: 't1001', password: 'Demo@1234' },
  })
  const teacherToken = teacherLogin.body.data?.token
  check(
    '教师登录成功并返回 token / expiresIn',
    teacherLogin.status === 200 &&
      typeof teacherToken === 'string' &&
      typeof teacherLogin.body.data?.expiresIn === 'number',
  )
  check(
    '登录响应 user 中不包含 password 字段',
    !('password' in (teacherLogin.body.data?.user ?? {})),
  )

  const studentLogin = await call('POST', '/auth/login', {
    body: { username: 's2026001', password: 'Demo@1234' },
  })
  const studentToken = studentLogin.body.data?.token

  const me = await call('GET', '/auth/me', { token: teacherToken })
  check('GET /auth/me 返回当前用户', me.status === 200 && me.body.data?.username === 't1001')

  const meAnonymous = await call('GET', '/auth/me')
  check('未携带令牌访问受保护端点返回 401', meAnonymous.status === 401 && meAnonymous.body.code === 20001)

  /* ---------------- 课程查询 ---------------- */
  const firstPage = await call('GET', '/courses?page=1&size=5')
  check(
    '课程列表分页返回 list/total/page/size',
    firstPage.status === 200 &&
      firstPage.body.data?.list?.length === 5 &&
      typeof firstPage.body.data?.total === 'number' &&
      firstPage.body.data?.page === 1 &&
      firstPage.body.data?.size === 5,
    JSON.stringify(firstPage.body.data).slice(0, 120),
  )
  check('默认不返回 archived 课程', firstPage.body.data?.list?.every((item) => item.status !== 'archived'))

  const overPage = await call('GET', '/courses?page=999&size=5')
  check(
    'page 越界时夹紧到最后一页',
    overPage.status === 200 && overPage.body.data?.page === Math.ceil(overPage.body.data?.total / 5),
    `page=${overPage.body.data?.page} total=${overPage.body.data?.total}`,
  )

  const badSize = await call('GET', '/courses?size=1000')
  check(
    'size 超出 1~100 返回 400 + 10001',
    badSize.status === 400 && badSize.body.code === 10001,
    `实际 ${badSize.status} / ${badSize.body.code}`,
  )

  const archived = await call('GET', '/courses?status=archived')
  check('显式查询 archived 可看到软删除课程', archived.status === 200 && archived.body.data?.total >= 1)

  const keywordSearch = await call('GET', '/courses?keyword=数据结构')
  check('keyword 命中课程名称', keywordSearch.status === 200 && keywordSearch.body.data?.total === 1)

  const keywordByTeacher = await call('GET', '/courses?keyword=王砚秋&size=100')
  check('keyword 支持按任课教师匹配', keywordByTeacher.body.data?.total >= 4)

  const detail = await call('GET', '/courses/C1001')
  check(
    '课程详情的 enrolledCount 由选课记录统计生成（42+2=44）',
    detail.status === 200 && detail.body.data?.enrolledCount === 44,
    `实际 ${detail.body.data?.enrolledCount}`,
  )

  const detailMissing = await call('GET', '/courses/C9999')
  check('课程不存在返回 404 + 10002', detailMissing.status === 404 && detailMissing.body.code === 10002)

  /* ---------------- 课程写操作 ---------------- */
  const invalidCreate = await call('POST', '/courses', {
    token: teacherToken,
    body: { code: 'cs1', title: 'a', teacherName: '王砚秋', term: '2026-2027-3', category: 'x', credits: 0.3, capacity: 0 },
  })
  check(
    '新建课程校验失败返回 400 + 10001 且 errors 覆盖多个字段',
    invalidCreate.status === 400 &&
      invalidCreate.body.code === 10001 &&
      invalidCreate.body.data?.errors?.length >= 5 &&
      invalidCreate.body.message.startsWith('参数校验失败：'),
    `errors=${invalidCreate.body.data?.errors?.length}`,
  )

  const forbiddenCreate = await call('POST', '/courses', {
    token: teacherToken,
    body: {
      code: 'CS2001',
      title: '越权课程',
      teacherName: '李向南',
      term: '2026-2027-1',
      category: 'elective',
      credits: 2,
      capacity: 30,
    },
  })
  check(
    '教师为他人建课返回 403 + 20002',
    forbiddenCreate.status === 403 && forbiddenCreate.body.code === 20002,
    `实际 ${forbiddenCreate.status} / ${forbiddenCreate.body.code}`,
  )

  const duplicateCreate = await call('POST', '/courses', {
    token: teacherToken,
    body: {
      code: 'CS1001',
      title: '重复代码课程',
      teacherName: '王砚秋',
      term: '2026-2027-1',
      category: 'required',
      credits: 3,
      capacity: 30,
    },
  })
  check(
    '课程代码重复返回 HTTP 200 + code 30001',
    duplicateCreate.status === 200 && duplicateCreate.body.code === 30001,
    `实际 ${duplicateCreate.status} / ${duplicateCreate.body.code}`,
  )

  const created = await call('POST', '/courses', {
    token: teacherToken,
    body: {
      code: 'CS2002',
      title: '契约自检课程',
      teacherName: '王砚秋',
      term: '2026-2027-2',
      category: 'elective',
      credits: 1.5,
      capacity: 30,
      status: 'draft',
      description: null,
    },
  })
  const createdId = created.body.data?.id
  check('新建课程成功返回 201 + code 0 + 服务端生成的 id', created.status === 201 && created.body.code === 0 && Boolean(createdId))
  check(
    '新建课程 enrolledCount 初始为 0 且带 createdAt/updatedAt',
    created.body.data?.enrolledCount === 0 &&
      typeof created.body.data?.createdAt === 'string' &&
      typeof created.body.data?.updatedAt === 'string',
  )

  const patched = await call('PATCH', `/courses/${createdId}/status`, {
    token: teacherToken,
    body: { status: 'open' },
  })
  check('状态 draft→open 允许', patched.status === 200 && patched.body.data?.status === 'open')

  const sameStatus = await call('PATCH', `/courses/${createdId}/status`, {
    token: teacherToken,
    body: { status: 'open' },
  })
  check(
    '状态与当前相同返回 30001（业务冲突）',
    sameStatus.status === 200 && sameStatus.body.code === 30001,
    `实际 ${sameStatus.status} / ${sameStatus.body.code}`,
  )

  const illegalTransition = await call('PATCH', `/courses/${createdId}/status`, {
    token: teacherToken,
    body: { status: 'draft' },
  })
  check(
    '非法状态迁移返回 30002（规则不满足）',
    illegalTransition.status === 200 && illegalTransition.body.code === 30002,
    `实际 ${illegalTransition.status} / ${illegalTransition.body.code}`,
  )

  const deleteWithPending = await call('DELETE', '/courses/C1001', { token: teacherToken })
  check(
    '存在未截止已发布作业时删除课程返回 30002',
    deleteWithPending.status === 200 && deleteWithPending.body.code === 30002,
    `实际 ${deleteWithPending.status} / ${deleteWithPending.body.code}`,
  )

  const deleted = await call('DELETE', `/courses/${createdId}`, { token: teacherToken })
  check('删除课程成功返回 200 + data:null', deleted.status === 200 && deleted.body.data === null)
  const restoredView = await call('GET', '/courses?status=archived&size=100')
  check(
    '软删除后课程出现在 archived 视图中',
    restoredView.body.data?.list?.some((item) => item.id === createdId),
  )

  const deleteByStudent = await call('DELETE', '/courses/C1002', { token: studentToken })
  check(
    '学生删除课程返回 403 + 20002',
    deleteByStudent.status === 403 && deleteByStudent.body.code === 20002,
    `实际 ${deleteByStudent.status} / ${deleteByStudent.body.code}`,
  )

  /* ---------------- 选课 ---------------- */
  const enrollments = await call('GET', '/courses/C1001/enrollments', { token: teacherToken })
  check(
    '教师可查询选课名单且包含 studentName',
    enrollments.status === 200 && enrollments.body.data?.length === 3 && Boolean(enrollments.body.data?.[0]?.studentName),
  )
  const enrollmentsByStudent = await call('GET', '/courses/C1001/enrollments', { token: studentToken })
  check(
    '学生查询选课名单返回 403',
    enrollmentsByStudent.status === 403 && enrollmentsByStudent.body.code === 20002,
  )

  const fullCourse = await call('POST', '/courses/C1004/enrollments', {
    token: studentToken,
    body: { studentId: 'U2001' },
  })
  check(
    '容量已满时选课返回 30002',
    fullCourse.status === 200 && fullCourse.body.code === 30002,
    `实际 ${fullCourse.status} / ${fullCourse.body.code}`,
  )

  const duplicatedEnroll = await call('POST', '/courses/C1001/enrollments', {
    token: studentToken,
    body: { studentId: 'U2001' },
  })
  check(
    '重复选课返回 30001',
    duplicatedEnroll.status === 200 && duplicatedEnroll.body.code === 30001,
    `实际 ${duplicatedEnroll.status} / ${duplicatedEnroll.body.code}`,
  )

  const enrollOther = await call('POST', '/courses/C1005/enrollments', {
    token: studentToken,
    body: { studentId: 'U2002' },
  })
  check(
    '学生为他人选课返回 403',
    enrollOther.status === 403 && enrollOther.body.code === 20002,
  )

  const enrollSelf = await call('POST', '/courses/C1005/enrollments', {
    token: studentToken,
    body: { studentId: 'U2001' },
  })
  const enrollmentId = enrollSelf.body.data?.id
  check('本人选课成功返回 201', enrollSelf.status === 201 && Boolean(enrollmentId))

  const drop = await call('DELETE', `/enrollments/${enrollmentId}`, { token: studentToken })
  check('退课成功返回 200 + data:null', drop.status === 200 && drop.body.data === null)

  const dropAgain = await call('DELETE', `/enrollments/${enrollmentId}`, { token: studentToken })
  check(
    '重复退课返回 30001（状态冲突）',
    dropAgain.status === 200 && dropAgain.body.code === 30001,
    `实际 ${dropAgain.status} / ${dropAgain.body.code}`,
  )

  /* ---------------- 作业 ---------------- */
  const assignmentList = await call('GET', '/assignments?size=100')
  check(
    '作业列表默认按 dueAt 升序返回',
    assignmentList.status === 200 &&
      assignmentList.body.data?.total >= 13 &&
      assignmentList.body.data?.list?.[0]?.dueAt <= assignmentList.body.data?.list?.[1]?.dueAt,
  )

  const assignmentByCourse = await call('GET', '/assignments?courseId=C1001&size=100')
  check('按 courseId 过滤作业', assignmentByCourse.body.data?.total === 3)

  const submissionsByStudent = await call('GET', '/assignments/A2001/submissions', {
    token: studentToken,
  })
  check(
    '学生查询提交列表返回 403',
    submissionsByStudent.status === 403 && submissionsByStudent.body.code === 20002,
  )

  const badDue = await call('POST', '/assignments', {
    token: teacherToken,
    body: {
      courseId: 'C1001',
      title: '时间非法作业',
      publishAt: '2026-09-20T02:00:00.000Z',
      dueAt: '2026-09-19T02:00:00.000Z',
      maxScore: 100,
    },
  })
  check(
    'dueAt 早于 publishAt 返回 400 + 10001（字段 dueAt）',
    badDue.status === 400 && badDue.body.data?.errors?.some((item) => item.field === 'dueAt'),
  )

  const badCourse = await call('POST', '/assignments', {
    token: teacherToken,
    body: {
      courseId: 'C9999',
      title: '课程不存在作业',
      publishAt: '2026-09-16T02:00:00.000Z',
      dueAt: '2026-09-23T02:00:00.000Z',
      maxScore: 100,
    },
  })
  check(
    'courseId 指向不存在课程返回 404 + 10002',
    badCourse.status === 404 && badCourse.body.code === 10002,
  )

  const createdAssignment = await call('POST', '/assignments', {
    token: teacherToken,
    body: {
      courseId: 'C1002',
      title: '契约自检作业',
      publishAt: '2026-09-16T02:00:00.000Z',
      dueAt: '2026-09-30T02:00:00.000Z',
      maxScore: 100,
      status: 'draft',
    },
  })
  check(
    '新建作业成功返回 201 且 submitCount 为 0',
    createdAssignment.status === 201 && createdAssignment.body.data?.submitCount === 0,
  )

  const deleteWithSubmissions = await call('DELETE', '/assignments/A2001', { token: teacherToken })
  check(
    '已有提交的作业不能删除（30002）',
    deleteWithSubmissions.status === 200 && deleteWithSubmissions.body.code === 30002,
    `实际 ${deleteWithSubmissions.status} / ${deleteWithSubmissions.body.code}`,
  )

  const deletedAssignment = await call('DELETE', `/assignments/${createdAssignment.body.data?.id}`, {
    token: teacherToken,
  })
  check('无提交的作业删除成功返回 200', deletedAssignment.status === 200 && deletedAssignment.body.code === 0)

  /* ---------------- 统计与兜底 ---------------- */
  const statistics = await call('GET', '/statistics/overview', { token: teacherToken })
  check(
    '统计概览返回四项指标与生成时间',
    statistics.status === 200 &&
      typeof statistics.body.data?.courseTotal === 'number' &&
      typeof statistics.body.data?.openTotal === 'number' &&
      typeof statistics.body.data?.creditTotal === 'number' &&
      typeof statistics.body.data?.assignmentTotal === 'number' &&
      typeof statistics.body.data?.generatedAt === 'string',
  )

  const statisticsAnonymous = await call('GET', '/statistics/overview')
  check(
    '未登录访问统计返回 401',
    statisticsAnonymous.status === 401 && statisticsAnonymous.body.code === 20001,
  )

  const unknown = await call('GET', '/not-exist')
  check('未知端点返回 404 + 10002', unknown.status === 404 && unknown.body.code === 10002)

  const badJson = await fetch(`${BASE}/courses`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${teacherToken}` },
    body: '{ not json',
  })
  const badJsonBody = await badJson.json().catch(() => null)
  check(
    '非法 JSON 请求体返回 400 + 10001',
    badJson.status === 400 && badJsonBody?.code === 10001,
    `实际 ${badJson.status} / ${badJsonBody?.code}`,
  )

  const logout = await call('POST', '/auth/logout', { token: teacherToken })
  const afterLogout = await call('GET', '/auth/me', { token: teacherToken })
  check(
    '退出登录后令牌立即失效（401）',
    logout.status === 200 && afterLogout.status === 401,
  )
}

function printReport() {
  const failed = results.filter((item) => !item.ok)
  console.log('\n契约自检结果（docs/api-contract-v1.md）')
  console.log('='.repeat(78))
  for (const item of results) {
    const mark = item.ok ? 'PASS' : 'FAIL'
    console.log(`[${mark}] ${item.name}${item.ok || !item.detail ? '' : ` -> ${item.detail}`}`)
  }
  console.log('='.repeat(78))
  console.log(`用例：${results.length} 个，通过 ${results.length - failed.length} 个，失败 ${failed.length} 个`)
  console.log(`信封一致性违规：${envelopeViolations.length} 处${envelopeViolations.slice(0, 3).join(' | ')}`)
  console.log(`响应敏感字段命中：${sensitiveHits.length} 处${sensitiveHits.slice(0, 3).join(' | ')}`)
  console.log('='.repeat(78))
  return failed.length === 0 && envelopeViolations.length === 0 && sensitiveHits.length === 0
}

// stdio 使用 inherit：某些受限环境会拒绝带管道的新进程
const server = EXTERNAL_BASE
  ? null
  : spawn(process.execPath, ['server/index.js', '--port', String(PORT)], { stdio: 'inherit' })

let exitCode = 1
try {
  const ready = await waitForServer()
  if (!ready) {
    throw new Error(`Mock 服务在 15 秒内未在端口 ${PORT} 就绪`)
  }
  await run()
  exitCode = printReport() ? 0 : 1
} catch (error) {
  console.error('契约自检执行失败：', error)
  exitCode = 1
} finally {
  server?.kill()
}

process.exit(exitCode)
