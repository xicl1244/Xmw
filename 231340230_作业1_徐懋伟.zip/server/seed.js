/**
 * Mock 数据源。
 * 所有数据均为虚构示例数据：姓名是虚构的，邮箱统一使用 example.com 域，
 * 不含任何真实学号、手机号或口令散列。
 *
 * 说明 1：所有时间都以"服务启动时刻"为基准按相对小时数生成，
 *   这样无论哪天演示，"未截止作业""已截止作业""本学期 / 下学期"都保持正确语义。
 * 说明 2：courses 中的 enrolledBase 表示"Mock 里未逐条展开的历史选课记录数"，
 * 接口返回的 enrolledCount = enrolledBase + 实际在修选课记录数，
 * 这样既能看到真实的选课名单，又能演示容量相关的业务规则。
 */

const HOUR = 3600 * 1000
/** 服务启动时刻，作为所有示例时间的基准 */
const BASE_TIME = Date.now()

/** 相对基准时刻偏移若干小时，负数为过去 */
function hoursFromBase(hours) {
  return new Date(BASE_TIME + hours * HOUR).toISOString()
}

const userSeed = [
  {
    id: 'U1001',
    username: 't1001',
    name: '王砚秋',
    email: 'wangyq@example.com',
    role: 'teacher',
    status: 'active',
    password: 'Demo@1234',
  },
  {
    id: 'U1002',
    username: 't1002',
    name: '李向南',
    email: 'lixn@example.com',
    role: 'teacher',
    status: 'active',
    password: 'Demo@1234',
  },
  {
    id: 'U2001',
    username: 's2026001',
    name: '张小北',
    email: 'zhangxb@example.com',
    role: 'student',
    status: 'active',
    password: 'Demo@1234',
  },
  {
    id: 'U2002',
    username: 's2026002',
    name: '林知远',
    email: 'linzy@example.com',
    role: 'student',
    status: 'active',
    password: 'Demo@1234',
  },
  {
    id: 'U2003',
    username: 's2026003',
    name: '沈书瑶',
    email: 'shensy@example.com',
    role: 'student',
    status: 'inactive',
    password: 'Demo@1234',
  },
  {
    id: 'U9001',
    username: 'admin',
    name: '平台运维',
    email: 'admin@example.com',
    role: 'admin',
    status: 'active',
    password: 'Demo@1234',
  },
]

// [id, code, title, teacherName, term, category, credits, capacity, enrolledBase, status, description]
const courseSeed = [
  ['C1001', 'CS1001', '数据结构与算法', '王砚秋', '2026-2027-1', 'required', 4, 60, 42, 'open', '线性表、树、图与排序算法的实现与复杂度分析，配套 6 次实验。'],
  ['C1002', 'CS1002', 'Web 前端工程实践', '李向南', '2026-2027-1', 'elective', 3, 40, 38, 'open', '以组件化、状态管理与接口契约为核心的前端工程训练。'],
  ['C1003', 'CS1003', '数据库原理与应用', '王砚秋', '2026-2027-1', 'required', 3.5, 55, 51, 'open', '关系模型、SQL、事务与索引优化，含一次综合实训。'],
  ['C1004', 'CS1004', '计算机组成原理', '李向南', '2026-2027-1', 'required', 4, 50, 50, 'open', '数据表示、指令系统与存储层次，课程容量固定为 50 人，用于演示"容量已满"。'],
  ['C1005', 'CS1005', '人工智能导论', '李向南', '2026-2027-1', 'elective', 2, 80, 24, 'open', '搜索、机器学习与神经网络的基础概念与实验。'],
  ['C1006', 'CS1006', '学术写作与表达', '王砚秋', '2026-2027-1', 'general', 1, 120, 12, 'draft', '文献检索、论证结构与学术表达规范，尚未正式发布。'],
  ['C1007', 'CS1007', '操作系统', '王砚秋', '2026-2027-2', 'required', 4, 60, 0, 'draft', '进程、内存、文件系统与并发控制，下学期开课。'],
  ['C1008', 'CS1008', '移动应用开发', '李向南', '2026-2027-1', 'elective', 2.5, 35, 31, 'open', '跨平台移动应用开发与真机调试。'],
  ['C1009', 'CS1009', '计算机网络', '王砚秋', '2026-2027-1', 'required', 3.5, 55, 47, 'open', 'TCP/IP 协议栈、可靠传输与应用层协议分析。'],
  ['C1010', 'CS1010', '软件工程方法', '李向南', '2026-2027-1', 'required', 3, 50, 33, 'closed', '需求、设计、测试与配置管理，本学期已结课。'],
  ['C1011', 'CS1011', '离散数学', '王砚秋', '2026-2027-1', 'required', 3, 70, 66, 'open', '集合、图论、数理逻辑与组合计数。'],
  ['C1012', 'CS1012', '信息安全基础', '李向南', '2026-2027-1', 'elective', 2, 45, 29, 'open', '密码学基础、身份认证与常见攻防实验。'],
  ['C1013', 'CS1013', '数字媒体技术', '王砚秋', '2025-2026-2', 'elective', 2, 40, 18, 'closed', '图像、音频与视频处理基础，上学期已结课。'],
  ['C1014', 'CS1014', '云计算与虚拟化', '李向南', '2026-2027-1', 'elective', 3, 40, 25, 'open', '容器、编排与云原生部署实践。'],
  ['C1015', 'CS1015', '程序设计基础实践', '王砚秋', '2025-2026-2', 'general', 1, 150, 148, 'archived', '面向新生的编程入门实践，已归档。'],
]

// [id, courseId, title, publishOffsetHours（负数=已发布）, dueOffsetHours（正数=未截止）, maxScore, status, submitCount]
const assignmentSeed = [
  ['A2001', 'C1001', '实验一：顺序表与链表实现', -240, 48, 100, 'published', 12],
  ['A2002', 'C1001', '实验二：二叉树的遍历与重建', -168, 120, 100, 'published', 6],
  ['A2003', 'C1001', '期末课程设计选题报告', 72, 720, 100, 'draft', 0],
  ['A2004', 'C1002', '作业 1：组件设计卡与拆分四问', -336, 24, 100, 'published', 35],
  ['A2005', 'C1002', '作业 2：REST 接口契约文档', -120, 168, 100, 'published', 21],
  ['A2006', 'C1002', '期末项目：前后端联调与演示', 48, 960, 100, 'draft', 0],
  ['A2007', 'C1003', '实验二：多表连接与索引优化', -240, 96, 100, 'published', 44],
  ['A2008', 'C1003', '期中测试（开卷）', -240, -24, 100, 'closed', 53],
  ['A2009', 'C1004', '组成原理实验：指令译码', -200, 240, 100, 'published', 30],
  ['A2010', 'C1005', '论文导读与读书报告', -100, 200, 50, 'published', 9],
  ['A2011', 'C1008', '移动端页面适配实践', -150, 150, 100, 'published', 14],
  ['A2012', 'C1009', '抓包分析实验报告', -300, 60, 100, 'published', 26],
  ['A2013', 'C1011', '离散数学第 3 次作业', -400, -24, 100, 'closed', 61],
]

// [id, courseId, studentId, status, score, createdOffsetHours]
const enrollmentSeed = [
  ['E3001', 'C1001', 'U2001', 'enrolled', null, 0],
  ['E3002', 'C1001', 'U2002', 'enrolled', null, 2],
  ['E3003', 'C1001', 'U2003', 'dropped', null, 6],
  ['E3004', 'C1002', 'U2001', 'enrolled', null, 10],
  ['E3005', 'C1002', 'U2002', 'enrolled', null, 12],
  ['E3006', 'C1003', 'U2001', 'enrolled', null, 20],
  ['E3007', 'C1003', 'U2002', 'completed', 92, 22],
  ['E3008', 'C1005', 'U2002', 'enrolled', null, 30],
  ['E3009', 'C1009', 'U2001', 'enrolled', null, 32],
  ['E3010', 'C1011', 'U2003', 'completed', 88, 40],
]

export function createDatabase() {
  return {
    users: userSeed.map((row) => ({
      ...row,
      createdAt: hoursFromBase(-4000),
      updatedAt: hoursFromBase(-800),
    })),
    courses: courseSeed.map((row, index) => ({
      id: row[0],
      code: row[1],
      title: row[2],
      teacherName: row[3],
      term: row[4],
      category: row[5],
      credits: row[6],
      capacity: row[7],
      enrolledBase: row[8],
      status: row[9],
      description: row[10],
      // 课程创建时间各不相同，默认按 createdAt 倒序时顺序稳定且可解释
      createdAt: hoursFromBase(-1200 + index * 12),
      updatedAt: hoursFromBase(-600 + index * 8),
    })),
    assignments: assignmentSeed.map((row) => ({
      id: row[0],
      courseId: row[1],
      title: row[2],
      description: `${row[2]}的提交要求与评分标准请见课程公告。`,
      publishAt: hoursFromBase(row[3]),
      dueAt: hoursFromBase(row[4]),
      maxScore: row[5],
      status: row[6],
      submitCount: row[7],
      createdAt: hoursFromBase(row[3] - 24),
      updatedAt: hoursFromBase(row[3] - 12),
    })),
    enrollments: enrollmentSeed.map((row) => ({
      id: row[0],
      courseId: row[1],
      studentId: row[2],
      status: row[3],
      score: row[4],
      createdAt: hoursFromBase(-900 + row[5]),
    })),
    sequences: { course: 1016, assignment: 2014, enrollment: 3011 },
  }
}
