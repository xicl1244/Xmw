/**
 * OpenAPI 3.0 描述文件，与 docs/api-contract-v1.md 保持同源。
 * 通过 /api-docs 提供可视化的 Swagger UI，便于后端实现者逐条对照。
 */

const envelopeSchema = {
  type: 'object',
  required: ['code', 'message', 'data', 'timestamp', 'requestId'],
  properties: {
    code: { type: 'integer', description: '业务状态码，0 表示成功', example: 0 },
    message: { type: 'string', example: 'OK' },
    data: { description: '业务数据，失败时为 null；参数校验失败时为 { errors: [] }' },
    timestamp: {
      type: 'string',
      format: 'date-time',
      description: '服务端生成时间（UTC，毫秒精度）',
      example: '2026-09-16T06:21:33.412Z',
    },
    requestId: { type: 'string', description: '请求追踪号，与响应头 X-Request-Id 一致' },
  },
}

const errorResponse = {
  description: '统一信封包装的业务失败响应',
  content: {
    'application/json': {
      schema: envelopeSchema,
      example: {
        code: 10001,
        message: '参数校验失败：code 必须是 2 位大写字母 + 4 位数字，例如 CS1001；credits 必须在 0.5~10 之间',
        data: {
          errors: [
            { field: 'code', message: '必须是 2 位大写字母 + 4 位数字，例如 CS1001' },
            { field: 'credits', message: '必须在 0.5~10 之间' },
          ],
        },
        timestamp: '2026-09-16T06:21:33.412Z',
        requestId: '3f9c1d42-6b7e-4f0a-9c2d-51b8e0a7d3a1',
      },
    },
  },
}

const courseSchema = {
  type: 'object',
  required: [
    'id',
    'code',
    'title',
    'teacherName',
    'term',
    'category',
    'credits',
    'capacity',
    'enrolledCount',
    'status',
    'description',
    'createdAt',
    'updatedAt',
  ],
  properties: {
    id: { type: 'string', example: 'C1001' },
    code: { type: 'string', pattern: '^[A-Z]{2}\\d{4}$', example: 'CS1001' },
    title: { type: 'string', minLength: 2, maxLength: 60, example: '数据结构与算法' },
    teacherName: { type: 'string', minLength: 1, maxLength: 20, example: '王砚秋' },
    term: { type: 'string', pattern: '^\\d{4}-\\d{4}-[12]$', example: '2026-2027-1' },
    category: { type: 'string', enum: ['required', 'elective', 'general'] },
    credits: { type: 'number', minimum: 0.5, maximum: 10, multipleOf: 0.5, example: 4 },
    capacity: { type: 'integer', minimum: 1, maximum: 300, example: 60 },
    enrolledCount: { type: 'integer', description: '服务端统计生成，只读', example: 45 },
    status: { type: 'string', enum: ['draft', 'open', 'closed', 'archived'] },
    description: { type: 'string', nullable: true, maxLength: 200 },
    createdAt: { type: 'string', format: 'date-time' },
    updatedAt: { type: 'string', format: 'date-time' },
  },
}

const courseInputSchema = {
  type: 'object',
  required: ['code', 'title', 'teacherName', 'term', 'category', 'credits', 'capacity'],
  properties: {
    code: { type: 'string', pattern: '^[A-Z]{2}\\d{4}$' },
    title: { type: 'string', minLength: 2, maxLength: 60 },
    teacherName: { type: 'string', minLength: 1, maxLength: 20 },
    term: { type: 'string', pattern: '^\\d{4}-\\d{4}-[12]$' },
    category: { type: 'string', enum: ['required', 'elective', 'general'] },
    credits: { type: 'number', minimum: 0.5, maximum: 10, multipleOf: 0.5 },
    capacity: { type: 'integer', minimum: 1, maximum: 300 },
    status: {
      type: 'string',
      enum: ['draft', 'open', 'closed', 'archived'],
      default: 'draft',
      description: '可选，缺省为 draft',
    },
    description: { type: 'string', nullable: true, maxLength: 200 },
  },
}

const assignmentSchema = {
  type: 'object',
  properties: {
    id: { type: 'string', example: 'A2001' },
    courseId: { type: 'string', example: 'C1001' },
    title: { type: 'string', minLength: 2, maxLength: 60 },
    description: { type: 'string', nullable: true, maxLength: 500 },
    publishAt: { type: 'string', format: 'date-time' },
    dueAt: { type: 'string', format: 'date-time', description: '必须晚于 publishAt' },
    maxScore: { type: 'integer', minimum: 1, maximum: 100 },
    status: { type: 'string', enum: ['draft', 'published', 'closed'] },
    submitCount: { type: 'integer', description: '服务端统计生成，只读' },
    createdAt: { type: 'string', format: 'date-time' },
    updatedAt: { type: 'string', format: 'date-time' },
  },
}

const enrollmentSchema = {
  type: 'object',
  properties: {
    id: { type: 'string', example: 'E3001' },
    courseId: { type: 'string', example: 'C1001' },
    studentId: { type: 'string', example: 'U2001' },
    studentName: { type: 'string', example: '张小北' },
    status: { type: 'string', enum: ['enrolled', 'dropped', 'completed'] },
    score: { type: 'number', nullable: true, minimum: 0, maximum: 100 },
    createdAt: { type: 'string', format: 'date-time' },
  },
}

const userSchema = {
  type: 'object',
  description: '响应中不包含任何口令或密钥字段',
  properties: {
    id: { type: 'string', example: 'U1001' },
    username: { type: 'string', example: 't1001' },
    name: { type: 'string', example: '王砚秋' },
    email: { type: 'string', format: 'email', example: 'wangyq@example.com' },
    role: { type: 'string', enum: ['student', 'teacher', 'admin'] },
    status: { type: 'string', enum: ['active', 'inactive', 'locked'] },
    createdAt: { type: 'string', format: 'date-time' },
    updatedAt: { type: 'string', format: 'date-time' },
  },
}

function pageResult(itemSchema, description) {
  return {
    type: 'object',
    description,
    properties: {
      list: { type: 'array', items: itemSchema },
      total: { type: 'integer', description: '符合条件的记录总数' },
      page: { type: 'integer', description: '实际页码（越界时夹紧到最后一页）' },
      size: { type: 'integer', description: '实际每页条数' },
    },
  }
}

function okResponse(dataSchema, description = '成功') {
  return {
    description,
    content: {
      'application/json': {
        schema: { allOf: [envelopeSchema, { type: 'object', properties: { data: dataSchema } }] },
      },
    },
  }
}

const pageParams = [
  { name: 'page', in: 'query', schema: { type: 'integer', minimum: 1, default: 1 } },
  { name: 'size', in: 'query', schema: { type: 'integer', minimum: 1, maximum: 100, default: 10 } },
  { name: 'sort', in: 'query', schema: { type: 'string' }, description: '排序字段白名单，见各端点说明' },
]

const courseIdParam = {
  name: 'courseId',
  in: 'path',
  required: true,
  schema: { type: 'string' },
}

export const openApiDocument = {
  openapi: '3.0.3',
  info: {
    title: '课程学习与作业管理平台 API',
    version: '1.0.0',
    description: [
      '契约版本 v1.0.0，基础路径 /api/v1，请求与响应均为 application/json。',
      '',
      '统一返回信封：{ code, message, data, timestamp, requestId }；',
      '业务状态码：0 成功 / 10001 参数校验失败(400) / 10002 资源不存在(404) / 10003 方法不允许(405) /',
      '20001 未登录(401) / 20002 权限不足(403) / 30001 业务冲突(200) / 30002 规则不满足(200) /',
      '40001 请求过于频繁(429) / 50000 服务端错误(500)。',
      '',
      '认证方式：Bearer Token，登录后放在 Authorization 请求头中。',
      '详细字段规则见仓库中的 docs/api-contract-v1.md。',
    ].join('\n'),
  },
  servers: [{ url: 'http://localhost:3000', description: '本地 Mock 服务' }],
  tags: [
    { name: '认证' },
    { name: '课程' },
    { name: '作业' },
    { name: '选课' },
    { name: '统计' },
  ],
  components: {
    securitySchemes: {
      bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'UUID' },
    },
    schemas: {
      Envelope: envelopeSchema,
      User: userSchema,
      Course: courseSchema,
      CourseInput: courseInputSchema,
      Assignment: assignmentSchema,
      Enrollment: enrollmentSchema,
    },
  },
  paths: {
    '/api/v1/auth/login': {
      post: {
        tags: ['认证'],
        summary: '登录并获取访问令牌',
        description: '由第 1 章实现。口令只出现在请求体中，响应不会回传口令。',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['username', 'password'],
                properties: {
                  username: { type: 'string', example: 't1001' },
                  password: { type: 'string', example: 'Demo@1234' },
                },
              },
            },
          },
        },
        responses: {
          200: okResponse({
            type: 'object',
            properties: {
              token: { type: 'string' },
              expiresIn: { type: 'integer', example: 7200 },
              user: userSchema,
            },
          }),
          400: errorResponse,
          401: errorResponse,
          403: errorResponse,
        },
      },
    },
    '/api/v1/auth/logout': {
      post: {
        tags: ['认证'],
        summary: '退出登录，使当前令牌立即失效',
        security: [{ bearerAuth: [] }],
        responses: { 200: okResponse({ type: 'object', nullable: true }), 401: errorResponse },
      },
    },
    '/api/v1/auth/me': {
      get: {
        tags: ['认证'],
        summary: '获取当前登录用户',
        security: [{ bearerAuth: [] }],
        responses: { 200: okResponse(userSchema), 401: errorResponse },
      },
    },
    '/api/v1/courses': {
      get: {
        tags: ['课程'],
        summary: '分页查询课程列表',
        description:
          '默认排除 status=archived（软删除）的课程；显式传 status=archived 可查看回收站。排序白名单：createdAt,desc / createdAt,asc / credits,desc / enrolledCount,desc。',
        parameters: [
          { name: 'keyword', in: 'query', schema: { type: 'string', maxLength: 50 } },
          { name: 'term', in: 'query', schema: { type: 'string', pattern: '^\\d{4}-\\d{4}-[12]$' } },
          {
            name: 'category',
            in: 'query',
            schema: { type: 'string', enum: ['required', 'elective', 'general'] },
          },
          {
            name: 'status',
            in: 'query',
            schema: { type: 'string', enum: ['draft', 'open', 'closed', 'archived'] },
          },
          ...pageParams,
        ],
        responses: {
          200: okResponse(pageResult(courseSchema, '课程分页结果')),
          400: errorResponse,
        },
      },
      post: {
        tags: ['课程'],
        summary: '新建课程',
        description:
          '由第 2 章实现。需要 teacher 或 admin 角色；teacher 的 teacherName 必须与本人姓名一致，否则 403。code 全校唯一，重复返回 30001。',
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: { 'application/json': { schema: courseInputSchema } },
        },
        responses: {
          201: okResponse(courseSchema, '创建成功'),
          400: errorResponse,
          401: errorResponse,
          403: errorResponse,
        },
      },
    },
    '/api/v1/courses/{courseId}': {
      get: {
        tags: ['课程'],
        summary: '查询课程详情',
        parameters: [courseIdParam],
        responses: { 200: okResponse(courseSchema), 404: errorResponse },
      },
      put: {
        tags: ['课程'],
        summary: '全量更新课程',
        description: '字段与新建一致。容量不得小于当前已选人数，否则返回 30002。',
        security: [{ bearerAuth: [] }],
        parameters: [courseIdParam],
        requestBody: {
          required: true,
          content: { 'application/json': { schema: courseInputSchema } },
        },
        responses: {
          200: okResponse(courseSchema),
          400: errorResponse,
          401: errorResponse,
          403: errorResponse,
          404: errorResponse,
        },
      },
      delete: {
        tags: ['课程'],
        summary: '删除课程（软删除）',
        description:
          '执行软删除，status 变为 archived；若课程仍有未截止的已发布作业则返回 30002。成功返回 HTTP 200 + data:null（不使用 204，保证前端始终读到统一信封）。',
        security: [{ bearerAuth: [] }],
        parameters: [courseIdParam],
        responses: {
          200: okResponse({ type: 'object', nullable: true }),
          401: errorResponse,
          403: errorResponse,
          404: errorResponse,
        },
      },
    },
    '/api/v1/courses/{courseId}/status': {
      patch: {
        tags: ['课程'],
        summary: '变更课程状态',
        description:
          '状态迁移白名单：draft→open|archived，open→closed|archived，closed→open|archived，archived 为终态。目标状态与当前状态相同返回 30001，非法迁移返回 30002。',
        security: [{ bearerAuth: [] }],
        parameters: [courseIdParam],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['status'],
                properties: {
                  status: { type: 'string', enum: ['draft', 'open', 'closed', 'archived'] },
                },
              },
            },
          },
        },
        responses: {
          200: okResponse(courseSchema),
          400: errorResponse,
          401: errorResponse,
          403: errorResponse,
          404: errorResponse,
        },
      },
    },
    '/api/v1/courses/{courseId}/enrollments': {
      get: {
        tags: ['选课'],
        summary: '查询课程选课名单',
        description: '由第 3 章实现。需要 teacher 或 admin 角色。',
        security: [{ bearerAuth: [] }],
        parameters: [courseIdParam],
        responses: {
          200: okResponse({ type: 'array', items: enrollmentSchema }),
          401: errorResponse,
          403: errorResponse,
          404: errorResponse,
        },
      },
      post: {
        tags: ['选课'],
        summary: '学生选课',
        description:
          '学生只能为本人选课；课程必须为 open 状态且未满员，否则返回 30002；重复选课返回 30001。',
        security: [{ bearerAuth: [] }],
        parameters: [courseIdParam],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  studentId: {
                    type: 'string',
                    description: '缺省为当前登录用户；teacher/admin 可指定其他学生',
                  },
                },
              },
            },
          },
        },
        responses: {
          201: okResponse(enrollmentSchema, '选课成功'),
          401: errorResponse,
          403: errorResponse,
          404: errorResponse,
        },
      },
    },
    '/api/v1/enrollments/{enrollmentId}': {
      delete: {
        tags: ['选课'],
        summary: '退课',
        description: '学生只能退选本人的课程；非 enrolled 状态返回 30001。',
        security: [{ bearerAuth: [] }],
        parameters: [
          { name: 'enrollmentId', in: 'path', required: true, schema: { type: 'string' } },
        ],
        responses: {
          200: okResponse({ type: 'object', nullable: true }),
          401: errorResponse,
          403: errorResponse,
          404: errorResponse,
        },
      },
    },
    '/api/v1/assignments': {
      get: {
        tags: ['作业'],
        summary: '分页查询作业列表',
        description:
          '排序白名单：dueAt,asc（默认）/ dueAt,desc / publishAt,desc / createdAt,desc；同值时按 id,asc 兜底。',
        parameters: [
          { name: 'keyword', in: 'query', schema: { type: 'string', maxLength: 50 } },
          { name: 'courseId', in: 'query', schema: { type: 'string' } },
          {
            name: 'status',
            in: 'query',
            schema: { type: 'string', enum: ['draft', 'published', 'closed'] },
          },
          ...pageParams,
        ],
        responses: {
          200: okResponse(pageResult(assignmentSchema, '作业分页结果')),
          400: errorResponse,
        },
      },
      post: {
        tags: ['作业'],
        summary: '新建作业',
        description: '需要 teacher 或 admin 角色；courseId 必须指向已存在的课程，否则 404。',
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: { 'application/json': { schema: assignmentSchema } },
        },
        responses: {
          201: okResponse(assignmentSchema, '创建成功'),
          400: errorResponse,
          401: errorResponse,
          403: errorResponse,
          404: errorResponse,
        },
      },
    },
    '/api/v1/assignments/{assignmentId}': {
      get: {
        tags: ['作业'],
        summary: '查询作业详情',
        parameters: [
          { name: 'assignmentId', in: 'path', required: true, schema: { type: 'string' } },
        ],
        responses: { 200: okResponse(assignmentSchema), 404: errorResponse },
      },
      put: {
        tags: ['作业'],
        summary: '全量更新作业',
        description: '已截止（closed）的作业不允许修改，返回 30002。',
        security: [{ bearerAuth: [] }],
        parameters: [
          { name: 'assignmentId', in: 'path', required: true, schema: { type: 'string' } },
        ],
        requestBody: {
          required: true,
          content: { 'application/json': { schema: assignmentSchema } },
        },
        responses: {
          200: okResponse(assignmentSchema),
          400: errorResponse,
          401: errorResponse,
          403: errorResponse,
          404: errorResponse,
        },
      },
      delete: {
        tags: ['作业'],
        summary: '删除作业',
        description: '已有提交（submitCount > 0）的作业不允许删除，返回 30002。',
        security: [{ bearerAuth: [] }],
        parameters: [
          { name: 'assignmentId', in: 'path', required: true, schema: { type: 'string' } },
        ],
        responses: {
          200: okResponse({ type: 'object', nullable: true }),
          401: errorResponse,
          403: errorResponse,
          404: errorResponse,
        },
      },
    },
    '/api/v1/assignments/{assignmentId}/submissions': {
      get: {
        tags: ['作业'],
        summary: '查询作业提交列表',
        description: '由第 3 章实现。需要 teacher 或 admin 角色。',
        security: [{ bearerAuth: [] }],
        parameters: [
          { name: 'assignmentId', in: 'path', required: true, schema: { type: 'string' } },
          ...pageParams,
        ],
        responses: {
          200: okResponse(pageResult({ type: 'object' }, '提交分页结果')),
          401: errorResponse,
          403: errorResponse,
          404: errorResponse,
        },
      },
    },
    '/api/v1/statistics/overview': {
      get: {
        tags: ['统计'],
        summary: '获取统计概览',
        description: '由第 4 章实现。需要登录。统计口径：不含 archived 课程的课程数与学分合计。',
        security: [{ bearerAuth: [] }],
        responses: {
          200: okResponse({
            type: 'object',
            properties: {
              courseTotal: { type: 'integer' },
              openTotal: { type: 'integer' },
              creditTotal: { type: 'number' },
              assignmentTotal: { type: 'integer' },
              generatedAt: { type: 'string', format: 'date-time' },
            },
          }),
          401: errorResponse,
        },
      },
    },
  },
}
