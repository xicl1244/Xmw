/**
 * Mock 后端服务：严格按 docs/api-contract-v1.md 实现，用于前端联调与契约自检。
 * 启动：npm run server  （默认 http://localhost:3000，Swagger UI：/api-docs）
 */
import crypto from 'node:crypto'
import cors from 'cors'
import express from 'express'
import swaggerUi from 'swagger-ui-express'
import { CODE, HTTP_STATUS_OF_CODE } from './codes.js'
import { openApiDocument } from './openapi.js'
import { createDatabase } from './seed.js'

const API_PREFIX = '/api/v1'
const portFlagIndex = process.argv.indexOf('--port')
const cliPort = portFlagIndex >= 0 ? process.argv[portFlagIndex + 1] : undefined
const PORT = Number(cliPort ?? process.env.MOCK_PORT ?? 3000)

const db = createDatabase()
/** token → { userId, expiresAt } */
const sessions = new Map()

const COURSE_CATEGORIES = ['required', 'elective', 'general']
const COURSE_STATUSES = ['draft', 'open', 'closed', 'archived']
const ASSIGNMENT_STATUSES = ['draft', 'published', 'closed']
const TERM_PATTERN = /^\d{4}-\d{4}-[12]$/
const CODE_PATTERN = /^[A-Z]{2}\d{4}$/
const COURSE_SORTS = ['createdAt,desc', 'createdAt,asc', 'credits,desc', 'enrolledCount,desc']
const ASSIGNMENT_SORTS = ['dueAt,asc', 'dueAt,desc', 'publishAt,desc', 'createdAt,desc']
/** 课程状态迁移表：archived 是终态，只能通过"恢复"接口（后续章节）处理 */
const COURSE_STATUS_TRANSITIONS = {
  draft: ['open', 'archived'],
  open: ['closed', 'archived'],
  closed: ['open', 'archived'],
  archived: [],
}

const app = express()
app.use(cors())
app.use(express.json({ limit: '64kb' }))

app.use((req, res, next) => {
  res.locals.requestId = crypto.randomUUID()
  res.setHeader('X-Request-Id', res.locals.requestId)
  next()
})

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(openApiDocument))
app.get('/api-docs.json', (_req, res) => res.json(openApiDocument))

/* =========================================================================
 * 统一返回信封
 * ========================================================================= */

function nowIso() {
  return new Date().toISOString()
}

function sendOk(res, data, message = 'OK', httpStatus = 200) {
  res.status(httpStatus).json({
    code: CODE.SUCCESS,
    message,
    data,
    timestamp: nowIso(),
    requestId: res.locals.requestId,
  })
}

function sendError(res, code, message, data = null) {
  res.status(HTTP_STATUS_OF_CODE[code] ?? 500).json({
    code,
    message,
    data,
    timestamp: nowIso(),
    requestId: res.locals.requestId,
  })
}

/** message 拼接规则：`参数校验失败：字段名 原因；…`，超过 5 条时追加"等 N 项" */
function sendValidationErrors(res, errors) {
  const head = errors
    .slice(0, 5)
    .map((item) => `${item.field} ${item.message}`)
    .join('；')
  const rest = errors.length > 5 ? `等 ${errors.length} 项` : ''
  sendError(res, CODE.PARAM_INVALID, `参数校验失败：${head}${rest}`, { errors })
}

/* =========================================================================
 * 通用工具
 * ========================================================================= */

function parsePagination(query, allowedSorts, defaultSort) {
  const errors = []

  let page = Number(query.page ?? 1)
  if (!Number.isInteger(page) || page < 1) {
    errors.push({ field: 'page', message: '必须是大于等于 1 的整数' })
    page = 1
  }

  let size = Number(query.size ?? 10)
  if (!Number.isInteger(size) || size < 1 || size > 100) {
    errors.push({ field: 'size', message: '必须是 1~100 之间的整数' })
    size = 10
  }

  const sort = typeof query.sort === 'string' && query.sort !== '' ? query.sort : defaultSort
  if (!allowedSorts.includes(sort)) {
    errors.push({ field: 'sort', message: `只支持 ${allowedSorts.join(' / ')}` })
  }

  return { page, size, sort, errors }
}

function readString(value) {
  return typeof value === 'string' ? value.trim() : ''
}

function sortItems(items, sort) {
  const [field, direction] = sort.split(',')
  const factor = direction === 'asc' ? 1 : -1
  return [...items].sort((left, right) => {
    const a = left[field]
    const b = right[field]
    if (a === b) {
      return left.id < right.id ? -1 : 1
    }
    return a > b ? factor : -factor
  })
}

/** 页码越界时返回最后一页，并把实际页码回写到响应里 */
function paginate(items, page, size) {
  const total = items.length
  const totalPages = Math.max(1, Math.ceil(total / size))
  const safePage = Math.min(page, totalPages)
  const start = (safePage - 1) * size
  return { list: items.slice(start, start + size), total, page: safePage, size }
}

/* =========================================================================
 * 序列化（响应中绝不含口令等敏感字段）
 * ========================================================================= */

function serializeUser(user) {
  const { password, ...rest } = user
  return rest
}

function activeEnrollmentCount(courseId) {
  return db.enrollments.filter(
    (item) => item.courseId === courseId && item.status !== 'dropped',
  ).length
}

function serializeCourse(course) {
  const { enrolledBase, ...rest } = course
  return { ...rest, enrolledCount: enrolledBase + activeEnrollmentCount(course.id) }
}

function serializeEnrollment(enrollment) {
  const student = db.users.find((user) => user.id === enrollment.studentId)
  return { ...enrollment, studentName: student ? student.name : '未知学生' }
}

/* =========================================================================
 * 认证与权限
 * ========================================================================= */

function readSession(req) {
  const header = req.header('authorization') ?? ''
  const matched = /^Bearer (.+)$/.exec(header)
  if (!matched) {
    return null
  }
  const session = sessions.get(matched[1])
  if (!session || session.expiresAt < Date.now()) {
    return null
  }
  return session
}

function authenticate(req, res, next) {
  const session = readSession(req)
  if (!session) {
    sendError(res, CODE.UNAUTHENTICATED, '未提供访问令牌或令牌已过期，请重新登录')
    return
  }
  const user = db.users.find((item) => item.id === session.userId)
  if (!user) {
    sendError(res, CODE.UNAUTHENTICATED, '令牌对应的用户不存在')
    return
  }
  req.user = user
  next()
}

function requireRole(roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      sendError(res, CODE.FORBIDDEN, `该操作需要 ${roles.join(' 或 ')} 角色，当前角色为 ${req.user?.role ?? 'guest'}`)
      return
    }
    next()
  }
}

/** 教师只能操作"任课教师为本人"的课程，admin 不受限制 */
function canWriteCourse(course, user) {
  return user.role === 'admin' || course.teacherName === user.name
}

/* =========================================================================
 * 参数校验
 * ========================================================================= */

function validateCourseBody(body) {
  const errors = []
  const payload = body && typeof body === 'object' ? body : {}

  const code = readString(payload.code).toUpperCase()
  if (!code) {
    errors.push({ field: 'code', message: '不能为空' })
  } else if (!CODE_PATTERN.test(code)) {
    errors.push({ field: 'code', message: '必须是 2 位大写字母 + 4 位数字，例如 CS1001' })
  }

  const title = readString(payload.title)
  if (title.length < 2 || title.length > 60) {
    errors.push({ field: 'title', message: '长度必须在 2~60 个字符之间' })
  }

  const teacherName = readString(payload.teacherName)
  if (teacherName.length < 1 || teacherName.length > 20) {
    errors.push({ field: 'teacherName', message: '长度必须在 1~20 个字符之间' })
  }

  const term = readString(payload.term)
  if (!TERM_PATTERN.test(term)) {
    errors.push({ field: 'term', message: '格式必须形如 2026-2027-1（末位只能是 1 或 2）' })
  }

  if (!COURSE_CATEGORIES.includes(payload.category)) {
    errors.push({ field: 'category', message: `必须是 ${COURSE_CATEGORIES.join(' / ')} 之一` })
  }

  const credits = Number(payload.credits)
  if (!Number.isFinite(credits) || credits < 0.5 || credits > 10) {
    errors.push({ field: 'credits', message: '必须在 0.5~10 之间' })
  } else if (Math.round(credits * 2) !== credits * 2) {
    errors.push({ field: 'credits', message: '必须是 0.5 的整数倍' })
  }

  const capacity = Number(payload.capacity)
  if (!Number.isInteger(capacity) || capacity < 1 || capacity > 300) {
    errors.push({ field: 'capacity', message: '必须是 1~300 之间的整数' })
  }

  const status = payload.status === undefined || payload.status === '' ? 'draft' : payload.status
  if (!COURSE_STATUSES.includes(status)) {
    errors.push({ field: 'status', message: `必须是 ${COURSE_STATUSES.join(' / ')} 之一` })
  }

  if (payload.description !== undefined && payload.description !== null) {
    if (typeof payload.description !== 'string' || payload.description.length > 200) {
      errors.push({ field: 'description', message: '必须是字符串且长度不超过 200 个字符' })
    }
  }

  return {
    errors,
    value: {
      code,
      title,
      teacherName,
      term,
      category: payload.category,
      credits: Number(payload.credits),
      capacity: Number(payload.capacity),
      status,
      description:
        payload.description === undefined || payload.description === null
          ? null
          : String(payload.description).trim(),
    },
  }
}

function validateAssignmentBody(body, { requireCourse = true } = {}) {
  const errors = []
  const payload = body && typeof body === 'object' ? body : {}

  const courseId = readString(payload.courseId)
  if (requireCourse && !courseId) {
    errors.push({ field: 'courseId', message: '不能为空' })
  }

  const title = readString(payload.title)
  if (title.length < 2 || title.length > 60) {
    errors.push({ field: 'title', message: '长度必须在 2~60 个字符之间' })
  }

  const publishAt = Date.parse(readString(payload.publishAt))
  if (Number.isNaN(publishAt)) {
    errors.push({ field: 'publishAt', message: '必须是 ISO 8601 时间字符串，例如 2026-09-16T02:00:00.000Z' })
  }

  const dueAt = Date.parse(readString(payload.dueAt))
  if (Number.isNaN(dueAt)) {
    errors.push({ field: 'dueAt', message: '必须是 ISO 8601 时间字符串，例如 2026-09-23T02:00:00.000Z' })
  } else if (!Number.isNaN(publishAt) && dueAt <= publishAt) {
    errors.push({ field: 'dueAt', message: '必须晚于 publishAt' })
  }

  const maxScore = Number(payload.maxScore)
  if (!Number.isInteger(maxScore) || maxScore < 1 || maxScore > 100) {
    errors.push({ field: 'maxScore', message: '必须是 1~100 之间的整数' })
  }

  const status = payload.status === undefined || payload.status === '' ? 'draft' : payload.status
  if (!ASSIGNMENT_STATUSES.includes(status)) {
    errors.push({ field: 'status', message: `必须是 ${ASSIGNMENT_STATUSES.join(' / ')} 之一` })
  }

  if (payload.description !== undefined && payload.description !== null) {
    if (typeof payload.description !== 'string' || payload.description.length > 500) {
      errors.push({ field: 'description', message: '必须是字符串且长度不超过 500 个字符' })
    }
  }

  return {
    errors,
    value: {
      courseId,
      title,
      description:
        payload.description === undefined || payload.description === null
          ? null
          : String(payload.description).trim(),
      publishAt: Number.isNaN(publishAt) ? null : new Date(publishAt).toISOString(),
      dueAt: Number.isNaN(dueAt) ? null : new Date(dueAt).toISOString(),
      maxScore: Number(payload.maxScore),
      status,
    },
  }
}

/* =========================================================================
 * 认证端点
 * ========================================================================= */

app.post(`${API_PREFIX}/auth/login`, (req, res) => {
  const errors = []
  const username = readString(req.body?.username)
  const password = typeof req.body?.password === 'string' ? req.body.password : ''
  if (!username) {
    errors.push({ field: 'username', message: '不能为空' })
  }
  if (!password) {
    errors.push({ field: 'password', message: '不能为空' })
  }
  if (errors.length > 0) {
    sendValidationErrors(res, errors)
    return
  }

  const user = db.users.find((item) => item.username === username)
  if (!user || user.password !== password) {
    sendError(res, CODE.UNAUTHENTICATED, '用户名或口令错误')
    return
  }
  if (user.status !== 'active') {
    sendError(res, CODE.FORBIDDEN, `账号状态为 ${user.status}，无法登录`)
    return
  }

  const token = crypto.randomUUID()
  const expiresIn = 7200
  sessions.set(token, { userId: user.id, expiresAt: Date.now() + expiresIn * 1000 })
  sendOk(res, { token, expiresIn, user: serializeUser(user) })
})

app.post(`${API_PREFIX}/auth/logout`, authenticate, (req, res) => {
  const header = req.header('authorization') ?? ''
  const matched = /^Bearer (.+)$/.exec(header)
  if (matched) {
    sessions.delete(matched[1])
  }
  sendOk(res, null, '已退出登录')
})

app.get(`${API_PREFIX}/auth/me`, authenticate, (req, res) => {
  sendOk(res, serializeUser(req.user))
})

/* =========================================================================
 * 课程端点
 * ========================================================================= */

app.get(`${API_PREFIX}/courses`, (req, res) => {
  const pagination = parsePagination(req.query, COURSE_SORTS, 'createdAt,desc')
  const errors = [...pagination.errors]

  const keyword = readString(req.query.keyword)
  const term = readString(req.query.term)
  const category = readString(req.query.category)
  const status = readString(req.query.status)

  if (keyword.length > 50) {
    errors.push({ field: 'keyword', message: '长度不能超过 50 个字符' })
  }
  if (term !== '' && !TERM_PATTERN.test(term)) {
    errors.push({ field: 'term', message: '格式必须形如 2026-2027-1' })
  }
  if (category !== '' && !COURSE_CATEGORIES.includes(category)) {
    errors.push({ field: 'category', message: `必须是 ${COURSE_CATEGORIES.join(' / ')} 之一` })
  }
  if (status !== '' && !COURSE_STATUSES.includes(status)) {
    errors.push({ field: 'status', message: `必须是 ${COURSE_STATUSES.join(' / ')} 之一` })
  }
  if (errors.length > 0) {
    sendValidationErrors(res, errors)
    return
  }

  let items = db.courses.map(serializeCourse)
  // 默认不返回已归档（软删除）课程；显式查询 status=archived 时用于回收站视图
  items = status === '' ? items.filter((item) => item.status !== 'archived') : items.filter((item) => item.status === status)
  if (term !== '') {
    items = items.filter((item) => item.term === term)
  }
  if (category !== '') {
    items = items.filter((item) => item.category === category)
  }
  if (keyword !== '') {
    const lower = keyword.toLowerCase()
    items = items.filter(
      (item) =>
        item.title.toLowerCase().includes(lower) ||
        item.code.toLowerCase().includes(lower) ||
        item.teacherName.toLowerCase().includes(lower),
    )
  }

  sendOk(res, paginate(sortItems(items, pagination.sort), pagination.page, pagination.size))
})

app.get(`${API_PREFIX}/courses/:courseId`, (req, res) => {
  const course = db.courses.find((item) => item.id === req.params.courseId)
  if (!course) {
    sendError(res, CODE.RESOURCE_NOT_FOUND, `课程不存在：${req.params.courseId}`)
    return
  }
  sendOk(res, serializeCourse(course))
})

app.post(`${API_PREFIX}/courses`, authenticate, requireRole(['teacher', 'admin']), (req, res) => {
  const { errors, value } = validateCourseBody(req.body)
  if (errors.length > 0) {
    sendValidationErrors(res, errors)
    return
  }
  if (req.user.role === 'teacher' && value.teacherName !== req.user.name) {
    sendError(res, CODE.FORBIDDEN, `教师只能创建任课教师为本人（${req.user.name}）的课程`)
    return
  }
  const duplicated = db.courses.find((item) => item.code === value.code)
  if (duplicated) {
    sendError(res, CODE.BUSINESS_CONFLICT, `课程代码 ${value.code} 已存在（课程：${duplicated.title}）`)
    return
  }

  const created = {
    id: `C${db.sequences.course++}`,
    ...value,
    enrolledBase: 0,
    createdAt: nowIso(),
    updatedAt: nowIso(),
  }
  db.courses.push(created)
  sendOk(res, serializeCourse(created), '课程创建成功', 201)
})

app.put(`${API_PREFIX}/courses/:courseId`, authenticate, requireRole(['teacher', 'admin']), (req, res) => {
  const course = db.courses.find((item) => item.id === req.params.courseId)
  if (!course) {
    sendError(res, CODE.RESOURCE_NOT_FOUND, `课程不存在：${req.params.courseId}`)
    return
  }
  if (!canWriteCourse(course, req.user)) {
    sendError(res, CODE.FORBIDDEN, `课程「${course.title}」的任课教师是 ${course.teacherName}，当前用户无权修改`)
    return
  }

  const { errors, value } = validateCourseBody(req.body)
  if (errors.length > 0) {
    sendValidationErrors(res, errors)
    return
  }

  const duplicated = db.courses.find((item) => item.code === value.code && item.id !== course.id)
  if (duplicated) {
    sendError(res, CODE.BUSINESS_CONFLICT, `课程代码 ${value.code} 已被课程「${duplicated.title}」占用`)
    return
  }

  const enrolledCount = serializeCourse(course).enrolledCount
  if (value.capacity < enrolledCount) {
    sendError(
      res,
      CODE.RULE_VIOLATION,
      `容量（${value.capacity}）不能小于当前已选人数（${enrolledCount}）`,
    )
    return
  }

  Object.assign(course, value, { updatedAt: nowIso() })
  sendOk(res, serializeCourse(course), '课程更新成功')
})

app.patch(`${API_PREFIX}/courses/:courseId/status`, authenticate, requireRole(['teacher', 'admin']), (req, res) => {
  const course = db.courses.find((item) => item.id === req.params.courseId)
  if (!course) {
    sendError(res, CODE.RESOURCE_NOT_FOUND, `课程不存在：${req.params.courseId}`)
    return
  }
  if (!canWriteCourse(course, req.user)) {
    sendError(res, CODE.FORBIDDEN, `课程「${course.title}」的任课教师是 ${course.teacherName}，当前用户无权修改`)
    return
  }

  const nextStatus = readString(req.body?.status)
  if (!COURSE_STATUSES.includes(nextStatus)) {
    sendValidationErrors(res, [
      { field: 'status', message: `必须是 ${COURSE_STATUSES.join(' / ')} 之一` },
    ])
    return
  }
  if (course.status === nextStatus) {
    sendError(res, CODE.BUSINESS_CONFLICT, `课程当前已经是 ${nextStatus} 状态`)
    return
  }
  if (!COURSE_STATUS_TRANSITIONS[course.status].includes(nextStatus)) {
    sendError(
      res,
      CODE.RULE_VIOLATION,
      `不允许从 ${course.status} 变更到 ${nextStatus}，允许的目标状态：${
        COURSE_STATUS_TRANSITIONS[course.status].join(' / ') || '（无，archived 是终态）'
      }`,
    )
    return
  }

  course.status = nextStatus
  course.updatedAt = nowIso()
  sendOk(res, serializeCourse(course), '课程状态更新成功')
})

app.delete(`${API_PREFIX}/courses/:courseId`, authenticate, requireRole(['teacher', 'admin']), (req, res) => {
  const course = db.courses.find((item) => item.id === req.params.courseId)
  if (!course) {
    sendError(res, CODE.RESOURCE_NOT_FOUND, `课程不存在：${req.params.courseId}`)
    return
  }
  if (!canWriteCourse(course, req.user)) {
    sendError(res, CODE.FORBIDDEN, `课程「${course.title}」的任课教师是 ${course.teacherName}，当前用户无权删除`)
    return
  }

  const pendingAssignments = db.assignments.filter(
    (item) =>
      item.courseId === course.id && item.status === 'published' && Date.parse(item.dueAt) > Date.now(),
  )
  if (pendingAssignments.length > 0) {
    sendError(
      res,
      CODE.RULE_VIOLATION,
      `该课程还有 ${pendingAssignments.length} 个未截止的已发布作业，请先关闭作业后再删除课程`,
    )
    return
  }

  course.status = 'archived'
  course.updatedAt = nowIso()
  sendOk(res, null, '课程已删除（软删除，status=archived）')
})

/* =========================================================================
 * 选课端点
 * ========================================================================= */

app.get(`${API_PREFIX}/courses/:courseId/enrollments`, authenticate, requireRole(['teacher', 'admin']), (req, res) => {
  const course = db.courses.find((item) => item.id === req.params.courseId)
  if (!course) {
    sendError(res, CODE.RESOURCE_NOT_FOUND, `课程不存在：${req.params.courseId}`)
    return
  }
  const items = db.enrollments
    .filter((item) => item.courseId === course.id)
    .map(serializeEnrollment)
  sendOk(res, sortItems(items, 'createdAt,asc'))
})

app.post(`${API_PREFIX}/courses/:courseId/enrollments`, authenticate, (req, res) => {
  const course = db.courses.find((item) => item.id === req.params.courseId)
  if (!course) {
    sendError(res, CODE.RESOURCE_NOT_FOUND, `课程不存在：${req.params.courseId}`)
    return
  }

  const requestedStudentId = readString(req.body?.studentId)
  const studentId = requestedStudentId === '' ? req.user.id : requestedStudentId

  if (req.user.role === 'student' && studentId !== req.user.id) {
    sendError(res, CODE.FORBIDDEN, '学生只能为本人选课')
    return
  }
  const student = db.users.find((item) => item.id === studentId)
  if (!student) {
    sendError(res, CODE.RESOURCE_NOT_FOUND, `学生不存在：${studentId}`)
    return
  }

  if (course.status !== 'open') {
    sendError(res, CODE.RULE_VIOLATION, `课程当前状态为 ${course.status}，只有 open 状态的课程可选`)
    return
  }
  const enrolledCount = serializeCourse(course).enrolledCount
  if (enrolledCount >= course.capacity) {
    sendError(res, CODE.RULE_VIOLATION, `课程容量已满（${enrolledCount}/${course.capacity}），无法选课`)
    return
  }
  const duplicated = db.enrollments.find(
    (item) => item.courseId === course.id && item.studentId === studentId && item.status !== 'dropped',
  )
  if (duplicated) {
    sendError(res, CODE.BUSINESS_CONFLICT, `学生 ${student.name} 已在课程「${course.title}」中，不能重复选课`)
    return
  }

  const created = {
    id: `E${db.sequences.enrollment++}`,
    courseId: course.id,
    studentId,
    status: 'enrolled',
    score: null,
    createdAt: nowIso(),
  }
  db.enrollments.push(created)
  sendOk(res, serializeEnrollment(created), '选课成功', 201)
})

app.delete(`${API_PREFIX}/enrollments/:enrollmentId`, authenticate, (req, res) => {
  const enrollment = db.enrollments.find((item) => item.id === req.params.enrollmentId)
  if (!enrollment) {
    sendError(res, CODE.RESOURCE_NOT_FOUND, `选课记录不存在：${req.params.enrollmentId}`)
    return
  }

  const isOwner = enrollment.studentId === req.user.id
  if (!isOwner && req.user.role === 'student') {
    sendError(res, CODE.FORBIDDEN, '学生只能退选本人的课程')
    return
  }
  if (enrollment.status !== 'enrolled') {
    sendError(res, CODE.BUSINESS_CONFLICT, `当前选课状态为 ${enrollment.status}，只有 enrolled 状态可以退课`)
    return
  }

  enrollment.status = 'dropped'
  sendOk(res, null, '退课成功')
})

/* =========================================================================
 * 作业端点
 * ========================================================================= */

app.get(`${API_PREFIX}/assignments`, (req, res) => {
  const pagination = parsePagination(req.query, ASSIGNMENT_SORTS, 'dueAt,asc')
  const errors = [...pagination.errors]

  const keyword = readString(req.query.keyword)
  const courseId = readString(req.query.courseId)
  const status = readString(req.query.status)

  if (keyword.length > 50) {
    errors.push({ field: 'keyword', message: '长度不能超过 50 个字符' })
  }
  if (status !== '' && !ASSIGNMENT_STATUSES.includes(status)) {
    errors.push({ field: 'status', message: `必须是 ${ASSIGNMENT_STATUSES.join(' / ')} 之一` })
  }
  if (errors.length > 0) {
    sendValidationErrors(res, errors)
    return
  }

  let items = [...db.assignments]
  if (courseId !== '') {
    items = items.filter((item) => item.courseId === courseId)
  }
  if (status !== '') {
    items = items.filter((item) => item.status === status)
  }
  if (keyword !== '') {
    const lower = keyword.toLowerCase()
    items = items.filter((item) => item.title.toLowerCase().includes(lower))
  }

  sendOk(res, paginate(sortItems(items, pagination.sort), pagination.page, pagination.size))
})

app.get(`${API_PREFIX}/assignments/:assignmentId`, (req, res) => {
  const assignment = db.assignments.find((item) => item.id === req.params.assignmentId)
  if (!assignment) {
    sendError(res, CODE.RESOURCE_NOT_FOUND, `作业不存在：${req.params.assignmentId}`)
    return
  }
  sendOk(res, assignment)
})

app.get(
  `${API_PREFIX}/assignments/:assignmentId/submissions`,
  authenticate,
  requireRole(['teacher', 'admin']),
  (req, res) => {
    const assignment = db.assignments.find((item) => item.id === req.params.assignmentId)
    if (!assignment) {
      sendError(res, CODE.RESOURCE_NOT_FOUND, `作业不存在：${req.params.assignmentId}`)
      return
    }
    // Mock 中提交记录由 submitCount 汇总表示，这里按契约返回空列表 + total
    sendOk(res, { list: [], total: assignment.submitCount, page: 1, size: 10 })
  },
)

app.post(`${API_PREFIX}/assignments`, authenticate, requireRole(['teacher', 'admin']), (req, res) => {
  const { errors, value } = validateAssignmentBody(req.body)
  if (errors.length > 0) {
    sendValidationErrors(res, errors)
    return
  }
  const course = db.courses.find((item) => item.id === value.courseId)
  if (!course) {
    sendError(res, CODE.RESOURCE_NOT_FOUND, `courseId 对应的课程不存在：${value.courseId}`)
    return
  }

  const created = {
    id: `A${db.sequences.assignment++}`,
    ...value,
    submitCount: 0,
    createdAt: nowIso(),
    updatedAt: nowIso(),
  }
  db.assignments.push(created)
  sendOk(res, created, '作业创建成功', 201)
})

app.put(`${API_PREFIX}/assignments/:assignmentId`, authenticate, requireRole(['teacher', 'admin']), (req, res) => {
  const assignment = db.assignments.find((item) => item.id === req.params.assignmentId)
  if (!assignment) {
    sendError(res, CODE.RESOURCE_NOT_FOUND, `作业不存在：${req.params.assignmentId}`)
    return
  }
  if (assignment.status === 'closed') {
    sendError(res, CODE.RULE_VIOLATION, '已截止（closed）的作业不允许再修改')
    return
  }

  const { errors, value } = validateAssignmentBody(req.body)
  if (errors.length > 0) {
    sendValidationErrors(res, errors)
    return
  }
  const course = db.courses.find((item) => item.id === value.courseId)
  if (!course) {
    sendError(res, CODE.RESOURCE_NOT_FOUND, `courseId 对应的课程不存在：${value.courseId}`)
    return
  }

  Object.assign(assignment, value, { updatedAt: nowIso() })
  sendOk(res, assignment, '作业更新成功')
})

app.delete(`${API_PREFIX}/assignments/:assignmentId`, authenticate, requireRole(['teacher', 'admin']), (req, res) => {
  const index = db.assignments.findIndex((item) => item.id === req.params.assignmentId)
  if (index === -1) {
    sendError(res, CODE.RESOURCE_NOT_FOUND, `作业不存在：${req.params.assignmentId}`)
    return
  }
  const assignment = db.assignments[index]
  if (assignment.submitCount > 0) {
    sendError(res, CODE.RULE_VIOLATION, `该作业已有 ${assignment.submitCount} 份提交，不能删除`)
    return
  }

  db.assignments.splice(index, 1)
  sendOk(res, null, '作业已删除')
})

/* =========================================================================
 * 统计端点
 * ========================================================================= */

app.get(`${API_PREFIX}/statistics/overview`, authenticate, (_req, res) => {
  const visibleCourses = db.courses.filter((item) => item.status !== 'archived')
  sendOk(res, {
    courseTotal: visibleCourses.length,
    openTotal: visibleCourses.filter((item) => item.status === 'open').length,
    creditTotal: visibleCourses.reduce((sum, item) => sum + item.credits, 0),
    assignmentTotal: db.assignments.length,
    generatedAt: nowIso(),
  })
})

/* =========================================================================
 * 兜底与错误处理
 * ========================================================================= */

app.use(API_PREFIX, (req, res) => {
  sendError(res, CODE.RESOURCE_NOT_FOUND, `接口不存在：${req.method} ${req.originalUrl}`)
})

app.use((error, _req, res, _next) => {
  if (error instanceof SyntaxError) {
    sendError(res, CODE.PARAM_INVALID, '请求体不是合法的 JSON')
    return
  }
  console.error('[mock] 未预期的服务端错误：', error)
  sendError(res, CODE.INTERNAL_ERROR, '服务端内部错误，请稍后重试')
})

app.listen(PORT, () => {
  console.log(`[mock] 契约 Mock 服务已启动：http://localhost:${PORT}${API_PREFIX}`)
  console.log(`[mock] Swagger UI：http://localhost:${PORT}/api-docs`)
  console.log(`[mock] OpenAPI JSON：http://localhost:${PORT}/api-docs.json`)
  console.log('[mock] 演示账号：t1001 / s2026001 / admin，口令统一为 Demo@1234')
})
