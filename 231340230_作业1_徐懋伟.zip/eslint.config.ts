import js from '@eslint/js'
import pluginVue from 'eslint-plugin-vue'
import { defineConfigWithVueTs, vueTsConfigs } from '@vue/eslint-config-typescript'
import skipFormatting from '@vue/eslint-config-prettier/skip-formatting'

const nodeGlobals = {
  console: 'readonly',
  process: 'readonly',
  fetch: 'readonly',
  setTimeout: 'readonly',
  clearTimeout: 'readonly',
  URL: 'readonly',
  URLSearchParams: 'readonly',
} as const

export default defineConfigWithVueTs(
  {
    name: 'app/files-to-lint',
    files: ['**/*.{ts,mts,tsx,vue,js,mjs}'],
  },
  {
    name: 'app/files-to-ignore',
    ignores: ['**/dist/**', '**/dist-ssr/**', '**/coverage/**', '**/node_modules/**'],
  },
  js.configs.recommended,
  pluginVue.configs['flat/essential'],
  vueTsConfigs.recommended,
  {
    name: 'app/node-scripts',
    files: ['server/**/*.js', 'scripts/**/*.mjs'],
    languageOptions: {
      globals: nodeGlobals,
    },
  },
  {
    name: 'app/rules',
    rules: {
      // 允许用下划线前缀标记"有意不使用的参数"，并允许解构剔除敏感字段
      'no-unused-vars': [
        'error',
        { argsIgnorePattern: '^_', varsIgnorePattern: '^_', ignoreRestSiblings: true },
      ],
      // TS 版本的同名规则，覆盖 .ts / .vue，同时兼容解构剔除敏感字段的写法
      '@typescript-eslint/no-unused-vars': [
        'error',
        {
          argsIgnorePattern: '^_',
          varsIgnorePattern: '^_',
          ignoreRestSiblings: true,
          caughtErrors: 'none',
        },
      ],
      // App.vue 是根组件，沿用脚手架惯例不计入多词组件名约束
      'vue/multi-word-component-names': ['error', { ignores: ['App'] }],
      // 展示组件必须显式声明 events，未声明的事件一律报错
      'vue/require-explicit-emits': 'error',
      'vue/component-name-in-template-casing': ['error', 'PascalCase'],
      'vue/define-emits-declaration': ['error', 'type-based'],
      'vue/define-props-declaration': ['error', 'type-based'],
      'vue/no-unused-refs': 'error',
      'vue/eqeqeq': 'error',
      'no-console': 'off',
    },
  },
  skipFormatting,
)
