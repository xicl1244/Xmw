<script setup lang="ts">
withDefaults(
  defineProps<{
    /** 主标题，说明"当前没有什么" */
    title: string
    /** 补充说明，提示用户可以怎么做 */
    description?: string
    /** 行动按钮文案，为空时不渲染按钮 */
    actionText?: string
  }>(),
  { description: '', actionText: '' },
)

const emit = defineEmits<{
  /** 点击行动按钮，父组件负责清空查询条件或打开新建表单 */
  action: []
}>()
</script>

<template>
  <div class="empty-state">
    <p class="empty-state__symbol" aria-hidden="true">🗂</p>
    <h3 class="empty-state__title">{{ title }}</h3>
    <p v-if="description" class="empty-state__desc">{{ description }}</p>
    <button v-if="actionText" type="button" class="btn btn--primary" @click="emit('action')">
      {{ actionText }}
    </button>
  </div>
</template>

<style scoped>
.empty-state {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  align-items: center;
  padding: var(--space-6) var(--space-4);
  border: 1px dashed var(--color-border-strong);
  border-radius: var(--radius-lg);
  background: var(--color-surface-muted);
  text-align: center;
}

.empty-state__symbol {
  font-size: 30px;
  line-height: 1;
}

.empty-state__title {
  font-size: 16px;
}

.empty-state__desc {
  max-width: 42ch;
  color: var(--color-text-muted);
  font-size: 14px;
}
</style>
