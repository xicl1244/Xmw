<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, ref, watch } from 'vue'
import CourseCard from './CourseCard.vue'
import StatusTag from './StatusTag.vue'
import { useCourseStore } from '@/stores/course'
import type { Course, CourseStatus } from '@/types/course'

const props = defineProps<{
  /** 抽屉是否展开 */
  open: boolean
  /** 当前查看的课程 id；为 null 时抽屉内只显示空态 */
  courseId: string | null
}>()

const emit = defineEmits<{
  /** 关闭抽屉 */
  'update:open': [value: boolean]
  /** 在抽屉里点击"编辑"，把课程抛给父组件打开表单 */
  edit: [course: Course]
  /** 在抽屉里点击"删除"，把课程抛给父组件做二次确认 */
  remove: [course: Course]
  /** 在抽屉里点击状态标签，父组件按状态筛选列表 */
  'filter-status': [status: CourseStatus]
}>()

const courseStore = useCourseStore()
const closeButton = ref<HTMLButtonElement | null>(null)
/** 记录打开抽屉前的焦点元素，关闭后把焦点还回去，键盘用户不会"丢失光标" */
let lastFocused: HTMLElement | null = null

const course = computed(() => courseStore.detail)
const enrollments = computed(() => courseStore.enrollments)

const enrolledStudents = computed(
  () => enrollments.value.filter((item) => item.status !== 'dropped').length,
)

function formatDateTime(value: string): string {
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) {
    return value
  }
  return date.toLocaleString('zh-CN', { hour12: false })
}

function handleFilterStatus(status: string): void {
  emit('filter-status', status as CourseStatus)
}

function close(): void {
  emit('update:open', false)
}

function onKeydown(event: KeyboardEvent): void {
  if (event.key === 'Escape') {
    close()
  }
}

watch(
  () => [props.open, props.courseId] as const,
  ([open, courseId]) => {
    if (!open) {
      window.removeEventListener('keydown', onKeydown)
      lastFocused?.focus()
      lastFocused = null
      return
    }
    lastFocused = document.activeElement instanceof HTMLElement ? document.activeElement : null
    window.addEventListener('keydown', onKeydown)
    nextTick(() => closeButton.value?.focus())
    if (courseId) {
      void courseStore.fetchDetail(courseId)
      void courseStore.fetchEnrollments(courseId)
    }
  },
  { immediate: true },
)

onBeforeUnmount(() => {
  window.removeEventListener('keydown', onKeydown)
})
</script>

<template>
  <div v-if="open" class="drawer-backdrop" @click.self="close">
    <aside
      class="drawer"
      role="dialog"
      aria-labelledby="course-detail-title"
      aria-describedby="course-detail-desc"
    >
      <header class="drawer__head">
        <div>
          <h2 id="course-detail-title">课程详情</h2>
          <p id="course-detail-desc" class="drawer__desc">
            数据来源：<code>GET /api/v1/courses/{courseId}</code> 与
            <code>GET /api/v1/courses/{courseId}/enrollments</code>
          </p>
        </div>
        <button
          ref="closeButton"
          type="button"
          class="btn btn--ghost"
          aria-label="关闭课程详情"
          @click="close"
        >
          ✕
        </button>
      </header>

      <div class="drawer__body stack">
        <div v-if="courseStore.detailLoading" class="skeleton-stack" aria-live="polite">
          <p class="sr-only">课程详情加载中</p>
          <div class="skeleton"></div>
          <div class="skeleton"></div>
        </div>

        <p v-else-if="courseStore.error" class="alert alert--error" role="alert">
          <span class="alert__icon" aria-hidden="true">!</span>
          <span>{{ courseStore.error }}</span>
        </p>

        <template v-else-if="course">
          <CourseCard :course="course" dense selected @edit="emit('edit', $event)" @remove="emit('remove', $event)" />

          <section class="stack">
            <h3>选课名单（{{ enrolledStudents }} 人在修）</h3>
            <div v-if="enrollments.length > 0" class="table-wrap">
              <table class="data-table">
                <caption>
                  选课状态由 <code>Enrollment.status</code> 提供，只显示前 8 条
                </caption>
                <thead>
                  <tr>
                    <th scope="col">学号</th>
                    <th scope="col">姓名</th>
                    <th scope="col">状态</th>
                    <th scope="col">成绩</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="item in enrollments.slice(0, 8)" :key="item.id">
                    <td>{{ item.studentId }}</td>
                    <td>{{ item.studentName }}</td>
                    <td><StatusTag :value="item.status" domain="enrollment" /></td>
                    <td class="data-table__num">{{ item.score ?? '—' }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <p v-else class="drawer__muted">该课程暂无选课记录。</p>
          </section>

          <section class="stack">
            <h3>基础信息</h3>
            <dl class="meta-list">
              <div>
                <dt>课程 ID</dt>
                <dd>{{ course.id }}</dd>
              </div>
              <div>
                <dt>创建时间</dt>
                <dd>{{ formatDateTime(course.createdAt) }}</dd>
              </div>
              <div>
                <dt>最近更新</dt>
                <dd>{{ formatDateTime(course.updatedAt) }}</dd>
              </div>
              <div>
                <dt>当前状态</dt>
                <dd><StatusTag :value="course.status" domain="course" clickable @select="handleFilterStatus" /></dd>
              </div>
            </dl>
          </section>
        </template>
      </div>
    </aside>
  </div>
</template>

<style scoped>
.drawer-backdrop {
  position: fixed;
  inset: 0;
  z-index: 20;
  display: flex;
  justify-content: flex-end;
  background: rgba(16, 26, 48, 0.36);
}

.drawer {
  display: flex;
  flex-direction: column;
  width: min(520px, 100%);
  height: 100%;
  overflow-y: auto;
  background: var(--color-surface);
  box-shadow: var(--shadow-md);
}

.drawer__head {
  position: sticky;
  top: 0;
  display: flex;
  gap: var(--space-3);
  align-items: flex-start;
  justify-content: space-between;
  padding: var(--space-4) var(--space-5);
  border-bottom: 1px solid var(--color-border);
  background: var(--color-surface);
}

.drawer__desc {
  margin-top: 4px;
  color: var(--color-text-muted);
  font-size: 13px;
}

.drawer__body {
  padding: var(--space-5);
}

.drawer__muted {
  color: var(--color-text-muted);
  font-size: 14px;
}

.meta-list {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
  gap: var(--space-3);
  margin: 0;
}

.meta-list dt {
  color: var(--color-text-muted);
  font-size: 13px;
}

.meta-list dd {
  margin: 0;
  font-size: 14px;
}
</style>
