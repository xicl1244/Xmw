<script setup lang="ts">
import { computed } from 'vue'

/** 状态所属的业务域 */
type StatusDomain = 'course' | 'assignment' | 'enrollment' | 'user'
/** 视觉基调：仅决定颜色，语义由 label 文本承担 */
type TagTone = 'neutral' | 'success' | 'info' | 'warning' | 'danger' | 'muted'

interface StatusMeta {
  label: string
  tone: TagTone
  /** 符号与文字同时出现，保证"状态区分不只依赖颜色" */
  symbol: string
}

/** 枚举值 → 中文标签的映射表，枚举本身一律使用英文小写 */
const STATUS_DICTIONARY: Record<StatusDomain, Record<string, StatusMeta>> = {
  course: {
    draft: { label: '草稿', tone: 'neutral', symbol: '✎' },
    open: { label: '进行中', tone: 'success', symbol: '▶' },
    closed: { label: '已结课', tone: 'info', symbol: '■' },
    archived: { label: '已归档', tone: 'muted', symbol: '▤' },
  },
  assignment: {
    draft: { label: '未发布', tone: 'neutral', symbol: '✎' },
    published: { label: '已发布', tone: 'success', symbol: '▶' },
    closed: { label: '已截止', tone: 'info', symbol: '■' },
  },
  enrollment: {
    enrolled: { label: '在修', tone: 'success', symbol: '▶' },
    dropped: { label: '已退课', tone: 'muted', symbol: '✕' },
    completed: { label: '已完成', tone: 'info', symbol: '✓' },
  },
  user: {
    active: { label: '正常', tone: 'success', symbol: '✓' },
    inactive: { label: '停用', tone: 'muted', symbol: '■' },
    locked: { label: '已锁定', tone: 'danger', symbol: '✕' },
  },
}

const props = withDefaults(
  defineProps<{
    /** 后端返回的英文枚举值 */
    value: string
    /** 状态所属业务域，决定查哪张映射表 */
    domain: StatusDomain
    /** 是否可点击：点击后把 value 作为筛选条件抛给父组件 */
    clickable?: boolean
  }>(),
  { clickable: false },
)

const emit = defineEmits<{
  /** 用户点击标签，父组件据此按该状态筛选列表 */
  select: [value: string]
}>()

const meta = computed<StatusMeta>(
  () =>
    STATUS_DICTIONARY[props.domain][props.value] ?? {
      label: props.value,
      tone: 'neutral',
      symbol: '？',
    },
)

const toneClass = computed(() => `tag--${meta.value.tone}`)
</script>

<template>
  <button
    v-if="clickable"
    type="button"
    class="tag tag--action"
    :class="toneClass"
    :title="`按「${meta.label}」筛选`"
    @click="emit('select', value)"
  >
    <span class="tag__symbol" aria-hidden="true">{{ meta.symbol }}</span>
    <span>{{ meta.label }}</span>
  </button>
  <span v-else class="tag" :class="toneClass">
    <span class="tag__symbol" aria-hidden="true">{{ meta.symbol }}</span>
    <span>{{ meta.label }}</span>
  </span>
</template>

<style scoped>
.tag {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 2px 10px;
  border: 1px solid transparent;
  border-radius: var(--radius-pill);
  font-size: 12px;
  line-height: 1.6;
  white-space: nowrap;
}

.tag--action {
  cursor: pointer;
  font: inherit;
  font-size: 12px;
}

.tag--action:hover {
  filter: brightness(0.96);
}

.tag__symbol {
  font-size: 11px;
}

.tag--neutral {
  border-color: var(--color-border-strong);
  background: var(--color-surface-muted);
  color: var(--color-text-muted);
}

.tag--success {
  border-color: #bfe3d1;
  background: var(--color-success-soft);
  color: var(--color-success);
}

.tag--info {
  border-color: #c5daf6;
  background: var(--color-info-soft);
  color: var(--color-info);
}

.tag--warning {
  border-color: #eed9ac;
  background: var(--color-warning-soft);
  color: var(--color-warning);
}

.tag--danger {
  border-color: #f0c8c4;
  background: var(--color-danger-soft);
  color: var(--color-danger);
}

.tag--muted {
  border-color: var(--color-border);
  background: #eef1f7;
  color: #6b7691;
}
</style>
