<script setup lang="ts">
import { computed } from 'vue'
import { PAGE_SIZE_OPTIONS } from '@/types/api'

const props = withDefaults(
  defineProps<{
    /** 当前页码，从 1 开始 */
    page: number
    /** 每页条数 */
    size: number
    /** 记录总数，由服务端的 total 字段提供 */
    total: number
    /** 加载中禁用翻页，避免连点产生乱序响应 */
    disabled?: boolean
    /** 每页条数可选项 */
    pageSizes?: readonly number[]
  }>(),
  { disabled: false, pageSizes: () => [...PAGE_SIZE_OPTIONS] },
)

const emit = defineEmits<{
  /** 页码或每页条数变化，两个值一起抛出，避免父组件分两次更新 */
  change: [page: number, size: number]
}>()

const totalPages = computed(() => Math.max(1, Math.ceil(props.total / Math.max(1, props.size))))

const rangeText = computed(() => {
  if (props.total === 0) {
    return '共 0 条'
  }
  const start = (props.page - 1) * props.size + 1
  const end = Math.min(props.page * props.size, props.total)
  return `第 ${start}-${end} 条 / 共 ${props.total} 条`
})

/** 页码窗口：最多显示 5 个页码，避免课程很多时分页器撑满一行 */
const pageItems = computed<number[]>(() => {
  const windowSize = 5
  const last = totalPages.value
  if (last <= windowSize) {
    return Array.from({ length: last }, (_, index) => index + 1)
  }
  const half = Math.floor(windowSize / 2)
  let start = Math.max(1, props.page - half)
  const end = Math.min(last, start + windowSize - 1)
  start = Math.max(1, end - windowSize + 1)
  return Array.from({ length: end - start + 1 }, (_, index) => start + index)
})

function goTo(nextPage: number): void {
  if (props.disabled || nextPage < 1 || nextPage > totalPages.value || nextPage === props.page) {
    return
  }
  emit('change', nextPage, props.size)
}

function onSizeChange(event: Event): void {
  const target = event.target as HTMLSelectElement
  const nextSize = Number(target.value)
  if (Number.isFinite(nextSize)) {
    emit('change', 1, nextSize)
  }
}
</script>

<template>
  <nav class="pagination" aria-label="分页导航">
    <p class="pagination__summary" aria-live="polite">{{ rangeText }}</p>

    <div class="pagination__controls">
      <button
        type="button"
        class="btn btn--sm"
        :disabled="disabled || page <= 1"
        aria-label="上一页"
        @click="goTo(page - 1)"
      >
        上一页
      </button>

      <ul class="pagination__pages">
        <li v-for="item in pageItems" :key="item">
          <button
            type="button"
            class="btn btn--sm"
            :class="{ 'btn--primary': item === page }"
            :aria-current="item === page ? 'page' : undefined"
            :disabled="disabled"
            @click="goTo(item)"
          >
            <span class="sr-only">第</span>{{ item }}<span class="sr-only">页</span>
          </button>
        </li>
      </ul>

      <button
        type="button"
        class="btn btn--sm"
        :disabled="disabled || page >= totalPages"
        aria-label="下一页"
        @click="goTo(page + 1)"
      >
        下一页
      </button>

      <span class="pagination__size">
        <label class="field__label" for="pagination-size">每页</label>
        <select
          id="pagination-size"
          class="select select--inline"
          :value="String(size)"
          :disabled="disabled"
          @change="onSizeChange"
        >
          <option v-for="option in pageSizes" :key="option" :value="String(option)">
            {{ option }}
          </option>
        </select>
        <span class="field__label">条</span>
      </span>
    </div>
  </nav>
</template>

<style scoped>
.pagination {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-3);
  align-items: center;
  justify-content: space-between;
  margin-top: var(--space-4);
}

.pagination__summary {
  color: var(--color-text-muted);
  font-size: 13px;
  font-variant-numeric: tabular-nums;
}

.pagination__controls {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-2);
  align-items: center;
}

.pagination__pages {
  display: flex;
  gap: var(--space-1);
  margin: 0;
  padding: 0;
  list-style: none;
}

.pagination__size {
  display: inline-flex;
  gap: 6px;
  align-items: center;
}

.select--inline {
  width: auto;
  min-height: 32px;
  padding: 2px var(--space-2);
}
</style>
