<script setup lang="ts">
type StatTone = 'default' | 'primary' | 'success' | 'warning'

const props = withDefaults(
  defineProps<{
    /** 指标名称，例如"课程总数" */
    label: string
    /** 指标数值，统计口径由父组件决定 */
    value: number | string
    /** 数值单位，例如"门""人""分" */
    unit?: string
    /** 补充说明，用来说明统计口径 */
    hint?: string
    /** 视觉强调色，仅影响颜色，不承载语义 */
    tone?: StatTone
    /** 是否可点击；为 true 时渲染成 button 并抛出 select 事件 */
    clickable?: boolean
    /** 点击后回传给父组件的筛选键，默认回传 label */
    filterKey?: string
  }>(),
  { unit: '', hint: '', tone: 'default', clickable: false, filterKey: '' },
)

const emit = defineEmits<{
  /** 用户点击统计卡，父组件据此设置查询条件或跳转页面 */
  select: [filterKey: string]
}>()

function handleSelect(): void {
  if (!props.clickable) {
    return
  }
  emit('select', props.filterKey || props.label)
}
</script>

<template>
  <component
    :is="clickable ? 'button' : 'div'"
    class="stat-card"
    :class="[`stat-card--${tone}`, { 'stat-card--clickable': clickable }]"
    :type="clickable ? 'button' : undefined"
    @click="handleSelect"
  >
    <span class="stat-card__label">{{ label }}</span>
    <span class="stat-card__value">
      {{ value }}<span v-if="unit" class="stat-card__unit">{{ unit }}</span>
    </span>
    <span v-if="hint" class="stat-card__hint">{{ hint }}</span>
  </component>
</template>

<style scoped>
.stat-card {
  display: flex;
  flex: 1 1 180px;
  flex-direction: column;
  gap: 2px;
  padding: var(--space-3) var(--space-4);
  border: 1px solid var(--color-border);
  border-left: 4px solid var(--color-border-strong);
  border-radius: var(--radius-md);
  background: var(--color-surface);
  text-align: left;
  font: inherit;
}

.stat-card--clickable {
  cursor: pointer;
}

.stat-card--clickable:hover {
  border-color: var(--color-primary);
  border-left-color: var(--color-primary);
}

.stat-card--primary {
  border-left-color: var(--color-primary);
}

.stat-card--success {
  border-left-color: var(--color-success);
}

.stat-card--warning {
  border-left-color: var(--color-warning);
}

.stat-card__label {
  color: var(--color-text-muted);
  font-size: 13px;
}

.stat-card__value {
  color: var(--color-text);
  font-size: 24px;
  font-weight: 700;
  font-variant-numeric: tabular-nums;
  line-height: 1.35;
}

.stat-card__unit {
  margin-left: 2px;
  font-size: 13px;
  font-weight: 500;
  color: var(--color-text-muted);
}

.stat-card__hint {
  color: var(--color-text-muted);
  font-size: 12px;
}
</style>
