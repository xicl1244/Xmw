<script setup lang="ts">
import { computed } from 'vue'
import StatusTag from './StatusTag.vue'
import type { Course, CourseCategory, CourseStatus } from '@/types/course'

const props = withDefaults(
  defineProps<{
    /** 课程对象，字段见接口契约 Course */
    course: Course
    /** 是否显示管理类操作按钮（编辑 / 删除） */
    canManage?: boolean
    /** 紧凑模式：详情抽屉中使用，隐藏简介与容量条 */
    dense?: boolean
    /** 是否处于选中态（详情抽屉当前打开的课程） */
    selected?: boolean
  }>(),
  { canManage: false, dense: false, selected: false },
)

const emit = defineEmits<{
  /** 点击"查看详情"，只抛 id，父组件决定打开抽屉还是跳转路由 */
  view: [courseId: string]
  /** 点击"编辑"，抛完整对象，父组件用它回填表单 */
  edit: [course: Course]
  /** 点击"删除"，抛完整对象，父组件据此弹出二次确认 */
  remove: [course: Course]
  /** 点击状态标签，按该状态筛选列表 */
  'filter-status': [status: CourseStatus]
}>()

const CATEGORY_LABELS: Record<CourseCategory, string> = {
  required: '必修',
  elective: '选修',
  general: '通识',
}

const categoryLabel = computed(() => CATEGORY_LABELS[props.course.category])

const capacityText = computed(() => `${props.course.enrolledCount}/${props.course.capacity} 人`)

/** 选课进度百分比，容量为 0 时按 0% 处理，避免除零 */
const capacityPercent = computed(() => {
  if (props.course.capacity <= 0) {
    return '0%'
  }
  const ratio = props.course.enrolledCount / props.course.capacity
  return `${Math.min(100, Math.round(ratio * 100))}%`
})

const isFull = computed(() => props.course.enrolledCount >= props.course.capacity)

const progressText = computed(() =>
  isFull.value ? `选课进度 ${capacityText.value}（已满）` : `选课进度 ${capacityText.value}`,
)

/** 状态标签的 select 事件载荷是字符串，这里收窄成 CourseStatus 再向上抛 */
function handleFilterStatus(status: string): void {
  emit('filter-status', status as CourseStatus)
}
</script>

<template>
  <article
    class="course-card"
    :class="{ 'course-card--dense': dense, 'course-card--selected': selected }"
    :aria-label="`课程卡片：${course.title}`"
  >
    <header class="course-card__head">
      <div class="course-card__heading">
        <h3 class="course-card__title">{{ course.title }}</h3>
        <p class="course-card__sub">
          <code>{{ course.code }}</code>
          <span aria-hidden="true">·</span>
          <span>{{ course.term }}</span>
        </p>
      </div>
      <StatusTag
        :value="course.status"
        domain="course"
        clickable
        @select="handleFilterStatus"
      />
    </header>

    <dl class="course-card__facts">
      <div class="course-card__fact">
        <dt>任课教师</dt>
        <dd>{{ course.teacherName }}</dd>
      </div>
      <div class="course-card__fact">
        <dt>类别</dt>
        <dd>{{ categoryLabel }}</dd>
      </div>
      <div class="course-card__fact">
        <dt>学分</dt>
        <dd>{{ course.credits }}</dd>
      </div>
      <div class="course-card__fact">
        <dt>已选</dt>
        <dd>{{ capacityText }}</dd>
      </div>
    </dl>

    <p v-if="!dense" class="course-card__desc">
      {{ course.description ?? '暂无课程简介' }}
    </p>

    <div v-if="!dense" class="course-card__capacity">
      <div class="progress" role="img" :aria-label="progressText">
        <span class="progress__bar" :style="{ width: capacityPercent }"></span>
      </div>
      <span class="course-card__capacity-text">{{ capacityText }}</span>
    </div>

    <footer class="course-card__actions">
      <button type="button" class="btn btn--sm" @click="emit('view', course.id)">查看详情</button>
      <template v-if="canManage">
        <button type="button" class="btn btn--sm" @click="emit('edit', course)">编辑</button>
        <button type="button" class="btn btn--sm btn--danger" @click="emit('remove', course)">
          删除
        </button>
      </template>
    </footer>
  </article>
</template>

<style scoped>
.course-card {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
  padding: var(--space-4);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-lg);
  background: var(--color-surface);
  box-shadow: var(--shadow-sm);
}

.course-card--selected {
  border-color: var(--color-primary);
}

.course-card--dense {
  box-shadow: none;
}

.course-card__head {
  display: flex;
  gap: var(--space-3);
  align-items: flex-start;
  justify-content: space-between;
}

.course-card__heading {
  min-width: 0;
}

.course-card__title {
  font-size: 17px;
}

.course-card__sub {
  display: flex;
  gap: 6px;
  align-items: center;
  margin-top: 4px;
  color: var(--color-text-muted);
  font-size: 13px;
}

.course-card__facts {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(90px, 1fr));
  gap: var(--space-2) var(--space-3);
  margin: 0;
  padding: var(--space-3);
  border-radius: var(--radius-md);
  background: var(--color-surface-muted);
}

.course-card__fact dt {
  color: var(--color-text-muted);
  font-size: 12px;
}

.course-card__fact dd {
  margin: 0;
  font-size: 14px;
  font-weight: 600;
}

.course-card__desc {
  color: var(--color-text-muted);
  font-size: 14px;
}

.course-card__capacity {
  display: flex;
  gap: var(--space-3);
  align-items: center;
  font-size: 13px;
  color: var(--color-text-muted);
}

.progress {
  flex: 1;
  height: 8px;
  overflow: hidden;
  border-radius: var(--radius-pill);
  background: #e6ebf5;
}

.progress__bar {
  display: block;
  height: 100%;
  border-radius: var(--radius-pill);
  background: var(--color-primary);
}

.course-card__capacity-text {
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}

.course-card__actions {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-2);
  padding-top: var(--space-2);
  border-top: 1px dashed var(--color-border);
}
</style>
