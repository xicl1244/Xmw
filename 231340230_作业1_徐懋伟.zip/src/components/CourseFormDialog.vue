<script setup lang="ts">
import { computed, nextTick, ref, watch } from 'vue'
import { ApiError } from '@/services/api'
import { useAuthStore } from '@/stores/auth'
import { useCourseStore } from '@/stores/course'
import type { Course, CourseCategory, CourseStatus, CreateCoursePayload } from '@/types/course'

const props = defineProps<{
  /** 是否显示对话框 */
  open: boolean
  /** 传入课程表示编辑，传入 null 表示新建 */
  course: Course | null
}>()

const emit = defineEmits<{
  /** 关闭对话框（点击取消、按 Esc、保存成功后） */
  'update:open': [value: boolean]
  /** 保存成功，把服务端返回的课程对象抛给父组件 */
  saved: [course: Course]
}>()

const courseStore = useCourseStore()
const authStore = useAuthStore()

interface CourseFormState {
  code: string
  title: string
  teacherName: string
  term: string
  category: CourseCategory
  credits: string
  capacity: string
  status: CourseStatus
  description: string
}

type FormErrors = Partial<Record<keyof CourseFormState, string>>

const CODE_PATTERN = /^[A-Z]{2}\d{4}$/
const TERM_PATTERN = /^\d{4}-\d{4}-[12]$/

const CATEGORY_OPTIONS: { value: CourseCategory; label: string }[] = [
  { value: 'required', label: '必修' },
  { value: 'elective', label: '选修' },
  { value: 'general', label: '通识' },
]

const STATUS_OPTIONS: { value: CourseStatus; label: string }[] = [
  { value: 'draft', label: '草稿' },
  { value: 'open', label: '进行中' },
  { value: 'closed', label: '已结课' },
  { value: 'archived', label: '已归档' },
]

function createEmptyForm(): CourseFormState {
  return {
    code: '',
    title: '',
    teacherName: '',
    term: '2026-2027-1',
    category: 'required',
    credits: '3',
    capacity: '40',
    status: 'draft',
    description: '',
  }
}

function toFormState(course: Course): CourseFormState {
  return {
    code: course.code,
    title: course.title,
    teacherName: course.teacherName,
    term: course.term,
    category: course.category,
    credits: String(course.credits),
    capacity: String(course.capacity),
    status: course.status,
    description: course.description ?? '',
  }
}

const form = ref<CourseFormState>(createEmptyForm())
const errors = ref<FormErrors>({})
const submitError = ref<string | null>(null)
const submitting = ref(false)
const codeInput = ref<HTMLInputElement | null>(null)

const isEdit = computed(() => props.course !== null)
const dialogTitle = computed(() => (isEdit.value ? `编辑课程：${props.course?.title ?? ''}` : '新增课程'))

watch(
  () => props.open,
  (open) => {
    if (!open) {
      return
    }
    form.value = props.course ? toFormState(props.course) : createEmptyForm()
    errors.value = {}
    submitError.value = null
    nextTick(() => codeInput.value?.focus())
  },
)

/**
 * 前端校验规则与 docs/api-contract-v1.md 的"校验规则"列保持一致。
 * 前端校验只是"提前反馈"，服务端仍会重做一遍校验并返回 10001。
 */
function validate(state: CourseFormState): FormErrors {
  const next: FormErrors = {}

  if (!state.code.trim()) {
    next.code = '课程代码不能为空'
  } else if (!CODE_PATTERN.test(state.code.trim())) {
    next.code = '课程代码必须为 2 位大写字母 + 4 位数字，例如 CS1001'
  }

  const title = state.title.trim()
  if (title.length < 2 || title.length > 60) {
    next.title = '课程名称长度需在 2~60 个字符之间'
  }

  const teacherName = state.teacherName.trim()
  if (teacherName.length < 1 || teacherName.length > 20) {
    next.teacherName = '任课教师姓名长度需在 1~20 个字符之间'
  }

  if (!TERM_PATTERN.test(state.term.trim())) {
    next.term = '学年学期格式形如 2026-2027-1（末位只能是 1 或 2）'
  }

  const credits = Number(state.credits)
  if (!Number.isFinite(credits) || credits < 0.5 || credits > 10) {
    next.credits = '学分必须在 0.5 ~ 10 之间'
  } else if (Math.round(credits * 2) !== credits * 2) {
    next.credits = '学分必须是 0.5 的整数倍'
  }

  const capacity = Number(state.capacity)
  if (!Number.isInteger(capacity) || capacity < 1 || capacity > 300) {
    next.capacity = '容量必须是 1 ~ 300 的整数'
  }

  const description = state.description.trim()
  if (description.length > 200) {
    next.description = '课程简介最多 200 个字符'
  }

  return next
}

function buildPayload(state: CourseFormState): CreateCoursePayload {
  const description = state.description.trim()
  return {
    code: state.code.trim().toUpperCase(),
    title: state.title.trim(),
    teacherName: state.teacherName.trim(),
    term: state.term.trim(),
    category: state.category,
    credits: Number(state.credits),
    capacity: Number(state.capacity),
    status: state.status,
    description: description === '' ? null : description,
  }
}

/** 把服务端 10001 的逐字段错误回填到表单上，用户不用自己猜哪个字段错了 */
function applyServerErrors(error: unknown): void {
  if (!(error instanceof ApiError)) {
    submitError.value = '保存失败，请稍后重试'
    return
  }
  submitError.value = `${error.message}（业务码 ${error.code}）`
  if (error.code !== 10001 || error.errors.length === 0) {
    return
  }
  const next: FormErrors = {}
  for (const item of error.errors) {
    const field = item.field as keyof CourseFormState
    if (field in form.value) {
      next[field] = item.message
    }
  }
  errors.value = { ...errors.value, ...next }
}

async function submit(): Promise<void> {
  if (submitting.value) {
    return
  }
  if (!authStore.canManageCourse) {
    submitError.value = '当前身份没有维护课程的权限（需要 teacher 或 admin 角色）'
    return
  }

  const nextErrors = validate(form.value)
  errors.value = nextErrors
  if (Object.keys(nextErrors).length > 0) {
    submitError.value = '表单填写有误，请检查标红的字段'
    return
  }

  submitting.value = true
  submitError.value = null
  try {
    const payload = buildPayload(form.value)
    const saved =
      props.course === null
        ? await courseStore.createCourse(payload)
        : await courseStore.updateCourse(props.course.id, payload)
    emit('saved', saved)
    emit('update:open', false)
  } catch (error) {
    applyServerErrors(error)
  } finally {
    submitting.value = false
  }
}

function close(): void {
  if (submitting.value) {
    return
  }
  emit('update:open', false)
}
</script>

<template>
  <div v-if="open" class="dialog-backdrop" @click.self="close">
    <section
      class="dialog"
      role="dialog"
      aria-modal="true"
      aria-labelledby="course-form-title"
      @keydown.esc="close"
    >
      <header class="dialog__head">
        <h2 id="course-form-title">{{ dialogTitle }}</h2>
        <button type="button" class="btn btn--ghost" aria-label="关闭课程表单" @click="close">✕</button>
      </header>

      <form class="dialog__body stack" novalidate @submit.prevent="submit">
        <p v-if="submitError" class="alert alert--error" role="alert">
          <span class="alert__icon" aria-hidden="true">!</span>
          <span>{{ submitError }}</span>
        </p>

        <div class="grid-2">
          <div class="field">
            <label class="field__label" for="course-code">
              课程代码 <span class="field__required" aria-hidden="true">*</span>
            </label>
            <input
              id="course-code"
              ref="codeInput"
              v-model="form.code"
              class="input"
              type="text"
              name="code"
              placeholder="例如 CS1001"
              :aria-invalid="Boolean(errors.code)"
              :aria-describedby="errors.code ? 'course-code-error' : undefined"
            />
            <p v-if="errors.code" id="course-code-error" class="field__error">{{ errors.code }}</p>
          </div>

          <div class="field">
            <label class="field__label" for="course-title">
              课程名称 <span class="field__required" aria-hidden="true">*</span>
            </label>
            <input
              id="course-title"
              v-model="form.title"
              class="input"
              type="text"
              name="title"
              :aria-invalid="Boolean(errors.title)"
              :aria-describedby="errors.title ? 'course-title-error' : undefined"
            />
            <p v-if="errors.title" id="course-title-error" class="field__error">
              {{ errors.title }}
            </p>
          </div>

          <div class="field">
            <label class="field__label" for="course-teacher">
              任课教师 <span class="field__required" aria-hidden="true">*</span>
            </label>
            <input
              id="course-teacher"
              v-model="form.teacherName"
              class="input"
              type="text"
              name="teacherName"
              :aria-invalid="Boolean(errors.teacherName)"
            />
            <p v-if="errors.teacherName" class="field__error">{{ errors.teacherName }}</p>
          </div>

          <div class="field">
            <label class="field__label" for="course-term">
              学年学期 <span class="field__required" aria-hidden="true">*</span>
            </label>
            <input
              id="course-term"
              v-model="form.term"
              class="input"
              type="text"
              name="term"
              placeholder="2026-2027-1"
              :aria-invalid="Boolean(errors.term)"
            />
            <p v-if="errors.term" class="field__error">{{ errors.term }}</p>
          </div>

          <div class="field">
            <label class="field__label" for="course-category">
              课程类别 <span class="field__required" aria-hidden="true">*</span>
            </label>
            <select id="course-category" v-model="form.category" class="select" name="category">
              <option v-for="option in CATEGORY_OPTIONS" :key="option.value" :value="option.value">
                {{ option.label }}
              </option>
            </select>
          </div>

          <div class="field">
            <label class="field__label" for="course-status">
              课程状态 <span class="field__required" aria-hidden="true">*</span>
            </label>
            <select id="course-status" v-model="form.status" class="select" name="status">
              <option v-for="option in STATUS_OPTIONS" :key="option.value" :value="option.value">
                {{ option.label }}
              </option>
            </select>
          </div>

          <div class="field">
            <label class="field__label" for="course-credits">
              学分 <span class="field__required" aria-hidden="true">*</span>
            </label>
            <input
              id="course-credits"
              v-model="form.credits"
              class="input"
              type="number"
              name="credits"
              min="0.5"
              max="10"
              step="0.5"
              :aria-invalid="Boolean(errors.credits)"
            />
            <p v-if="errors.credits" class="field__error">{{ errors.credits }}</p>
          </div>

          <div class="field">
            <label class="field__label" for="course-capacity">
              容量 <span class="field__required" aria-hidden="true">*</span>
            </label>
            <input
              id="course-capacity"
              v-model="form.capacity"
              class="input"
              type="number"
              name="capacity"
              min="1"
              max="300"
              step="1"
              :aria-invalid="Boolean(errors.capacity)"
            />
            <p v-if="errors.capacity" class="field__error">{{ errors.capacity }}</p>
          </div>
        </div>

        <div class="field">
          <label class="field__label" for="course-description">课程简介（不超过 200 字）</label>
          <textarea
            id="course-description"
            v-model="form.description"
            class="textarea"
            name="description"
            maxlength="200"
            :aria-invalid="Boolean(errors.description)"
          ></textarea>
          <p v-if="errors.description" class="field__error">{{ errors.description }}</p>
        </div>

        <p class="dialog__note">
          <span aria-hidden="true">ⓘ</span>
          已选人数由服务端按选课记录统计，不在此处填写；
          <code>code</code> 在全校范围内唯一，重复时服务端返回业务码
          <code>30001</code>。
        </p>

        <footer class="dialog__foot">
          <button type="button" class="btn" :disabled="submitting" @click="close">取消</button>
          <button type="submit" class="btn btn--primary" :disabled="submitting">
            {{ submitting ? '保存中…' : '保存' }}
          </button>
        </footer>
      </form>
    </section>
  </div>
</template>

<style scoped>
.dialog-backdrop {
  position: fixed;
  inset: 0;
  z-index: 30;
  display: flex;
  align-items: flex-start;
  justify-content: center;
  padding: var(--space-5);
  overflow-y: auto;
  background: rgba(16, 26, 48, 0.42);
}

.dialog {
  width: min(760px, 100%);
  margin-top: var(--space-5);
  border-radius: var(--radius-lg);
  background: var(--color-surface);
  box-shadow: var(--shadow-md);
}

.dialog__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: var(--space-4) var(--space-5);
  border-bottom: 1px solid var(--color-border);
}

.dialog__body {
  padding: var(--space-5);
}

.grid-2 {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: var(--space-4);
}

.dialog__note {
  color: var(--color-text-muted);
  font-size: 13px;
}

.dialog__foot {
  display: flex;
  gap: var(--space-3);
  justify-content: flex-end;
  padding-top: var(--space-3);
  border-top: 1px solid var(--color-border);
}
</style>
