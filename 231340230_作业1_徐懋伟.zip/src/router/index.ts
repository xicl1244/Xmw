import { createRouter, createWebHistory, type RouteRecordRaw } from 'vue-router'

export const APP_TITLE = '课程学习与作业管理平台'

const routes: RouteRecordRaw[] = [
  {
    path: '/',
    name: 'dashboard',
    component: () => import('@/views/DashboardView.vue'),
    meta: { title: '概览' },
  },
  {
    path: '/courses',
    name: 'courses',
    component: () => import('@/views/CourseListView.vue'),
    meta: { title: '课程管理' },
  },
  {
    path: '/assignments',
    name: 'assignments',
    component: () => import('@/views/AssignmentListView.vue'),
    meta: { title: '作业管理' },
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'not-found',
    component: () => import('@/views/NotFoundView.vue'),
    meta: { title: '页面不存在' },
  },
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
  scrollBehavior: () => ({ top: 0 }),
})

router.afterEach((to) => {
  const title = typeof to.meta.title === 'string' ? to.meta.title : ''
  // 路由切换后同步文档标题，屏幕阅读器与浏览器标签页都能感知到页面变化
  document.title = title ? `${title} · ${APP_TITLE}` : APP_TITLE
})

export default router
