import axios, { AxiosError, type AxiosInstance, type AxiosRequestConfig } from 'axios'
import type { ApiEnvelope, FieldError } from '@/types/api'

/**
 * 统一的 API 错误对象。
 * 把「HTTP 状态 + 业务 code + 逐字段错误」三者合并成一个可判定的对象，
 * 页面只需要读 ApiError.code / ApiError.errors，不必再关心 axios 的细节。
 */
export class ApiError extends Error {
  /** 业务状态码，网络异常时为 -1 */
  readonly code: number
  /** HTTP 状态码，网络异常时为 null */
  readonly httpStatus: number | null
  /** 参数校验失败时的逐字段错误；其它情况为空数组 */
  readonly errors: FieldError[]

  constructor(code: number, message: string, httpStatus: number | null, errors: FieldError[] = []) {
    super(message)
    this.name = 'ApiError'
    this.code = code
    this.httpStatus = httpStatus
    this.errors = errors
  }
}

/** 网络层失败（断网、超时、Mock 服务未启动）使用 -1 */
export const NETWORK_ERROR_CODE = -1

const TOKEN_STORAGE_KEY = 'coursehub.access_token'

export function readToken(): string | null {
  return localStorage.getItem(TOKEN_STORAGE_KEY)
}

export function writeToken(token: string | null): void {
  if (token) {
    localStorage.setItem(TOKEN_STORAGE_KEY, token)
  } else {
    localStorage.removeItem(TOKEN_STORAGE_KEY)
  }
}

export const http: AxiosInstance = axios.create({
  // 由 Vite 代理转发到 http://localhost:3000/api/v1
  baseURL: '/api/v1',
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' },
})

http.interceptors.request.use((config) => {
  const token = readToken()
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

function toApiError(error: unknown): ApiError {
  if (error instanceof ApiError) {
    return error
  }
  if (error instanceof AxiosError) {
    const httpStatus = error.response?.status ?? null
    const envelope = error.response?.data as
      | (Partial<ApiEnvelope<{ errors?: FieldError[] }>> & { data?: { errors?: FieldError[] } })
      | undefined

    if (!httpStatus) {
      return new ApiError(
        NETWORK_ERROR_CODE,
        '无法连接后端服务，请确认已执行 npm run server 启动 Mock 服务',
        null,
      )
    }
    const code = typeof envelope?.code === 'number' ? envelope.code : httpStatus
    const message = envelope?.message || `请求失败（HTTP ${httpStatus}）`
    const errors = envelope?.data?.errors ?? []
    return new ApiError(code, message, httpStatus, errors)
  }
  return new ApiError(NETWORK_ERROR_CODE, '发生未知错误，请稍后重试', null)
}

/**
 * 发起请求并拆信封：
 * - 成功时直接返回 data 字段，页面拿到的就是业务数据；
 * - 失败时抛出 ApiError（含业务 code），由 store 统一写入 error 状态。
 */
export async function request<T>(config: AxiosRequestConfig): Promise<T> {
  try {
    const response = await http.request<ApiEnvelope<T>>(config)
    const envelope = response.data
    if (envelope.code !== 0) {
      throw new ApiError(envelope.code, envelope.message, response.status, [])
    }
    return envelope.data
  } catch (error) {
    throw toApiError(error)
  }
}
