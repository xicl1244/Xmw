import { request } from './api'
import type { LoginPayload, LoginResult, User } from '@/types/user'

export const authService = {
  login(payload: LoginPayload) {
    return request<LoginResult>({ url: '/auth/login', method: 'POST', data: payload })
  },
  logout() {
    return request<null>({ url: '/auth/logout', method: 'POST' })
  },
  me() {
    return request<User>({ url: '/auth/me', method: 'GET' })
  },
}
