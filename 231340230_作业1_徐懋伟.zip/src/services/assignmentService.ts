import { request } from './api'
import type { PageResult } from '@/types/api'
import type {
  Assignment,
  AssignmentListQuery,
  CreateAssignmentPayload,
  UpdateAssignmentPayload,
} from '@/types/assignment'

export const assignmentService = {
  list(query: AssignmentListQuery) {
    return request<PageResult<Assignment>>({ url: '/assignments', method: 'GET', params: query })
  },
  detail(assignmentId: string) {
    return request<Assignment>({ url: `/assignments/${assignmentId}`, method: 'GET' })
  },
  create(payload: CreateAssignmentPayload) {
    return request<Assignment>({ url: '/assignments', method: 'POST', data: payload })
  },
  update(assignmentId: string, payload: UpdateAssignmentPayload) {
    return request<Assignment>({ url: `/assignments/${assignmentId}`, method: 'PUT', data: payload })
  },
  remove(assignmentId: string) {
    return request<null>({ url: `/assignments/${assignmentId}`, method: 'DELETE' })
  },
}
