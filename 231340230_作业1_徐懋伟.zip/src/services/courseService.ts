import { request } from './api'
import type { PageResult } from '@/types/api'
import type {
  ChangeStatusPayload,
  Course,
  CourseListQuery,
  CourseStats,
  CreateCoursePayload,
  Enrollment,
  UpdateCoursePayload,
} from '@/types/course'

export const courseService = {
  list(query: CourseListQuery) {
    return request<PageResult<Course>>({ url: '/courses', method: 'GET', params: query })
  },
  detail(courseId: string) {
    return request<Course>({ url: `/courses/${courseId}`, method: 'GET' })
  },
  create(payload: CreateCoursePayload) {
    return request<Course>({ url: '/courses', method: 'POST', data: payload })
  },
  update(courseId: string, payload: UpdateCoursePayload) {
    return request<Course>({ url: `/courses/${courseId}`, method: 'PUT', data: payload })
  },
  changeStatus(courseId: string, payload: ChangeStatusPayload) {
    return request<Course>({
      url: `/courses/${courseId}/status`,
      method: 'PATCH',
      data: payload,
    })
  },
  remove(courseId: string) {
    return request<null>({ url: `/courses/${courseId}`, method: 'DELETE' })
  },
  enrollments(courseId: string) {
    return request<Enrollment[]>({ url: `/courses/${courseId}/enrollments`, method: 'GET' })
  },
  enroll(courseId: string, studentId: string) {
    return request<Enrollment>({
      url: `/courses/${courseId}/enrollments`,
      method: 'POST',
      data: { studentId },
    })
  },
  drop(enrollmentId: string) {
    return request<null>({ url: `/enrollments/${enrollmentId}`, method: 'DELETE' })
  },
  statistics() {
    return request<CourseStats>({ url: '/statistics/overview', method: 'GET' })
  },
}
