import { computed, ref } from 'vue'
import { defineStore } from 'pinia'
import { authService } from '@/services/authService'
import { readToken, writeToken } from '@/services/api'
import type { User, UserRole } from '@/types/user'

/** 演示账号：口令只存在于前端常量与请求体中，接口响应不会回传口令 */
export const DEMO_ACCOUNTS = [
  { username: 't1001', label: '教师 · 王砚秋', password: 'Demo@1234' },
  { username: 's2026001', label: '学生 · 张小北', password: 'Demo@1234' },
  { username: 'admin', label: '管理员 · 平台运维', password: 'Demo@1234' },
] as const

export const useAuthStore = defineStore('auth', () => {
  // 全局状态：登录令牌与当前用户，两者跨页面共享，必须放在 store
  const token = ref<string | null>(readToken())
  const currentUser = ref<User | null>(null)
  const loading = ref(false)
  const error = ref<string | null>(null)

  const isLoggedIn = computed(() => token.value !== null && currentUser.value !== null)
  const role = computed<UserRole | 'guest'>(() => currentUser.value?.role ?? 'guest')
  const isAdmin = computed(() => role.value === 'admin')
  /** 是否可以维护课程：教师与管理员 */
  const canManageCourse = computed(() => role.value === 'teacher' || role.value === 'admin')
  /** 是否可以维护作业：教师与管理员 */
  const canManageAssignment = computed(() => role.value === 'teacher' || role.value === 'admin')
  const displayName = computed(() => currentUser.value?.name ?? '未登录')

  async function login(username: string, password: string): Promise<void> {
    loading.value = true
    error.value = null
    try {
      const result = await authService.login({ username, password })
      token.value = result.token
      currentUser.value = result.user
      writeToken(result.token)
    } catch (err) {
      token.value = null
      currentUser.value = null
      writeToken(null)
      error.value = err instanceof Error ? err.message : '登录失败'
      throw err
    } finally {
      loading.value = false
    }
  }

  /** 切换演示身份：页面顶部的身份下拉框调用它 */
  async function loginAsDemo(username: string): Promise<void> {
    const account = DEMO_ACCOUNTS.find((item) => item.username === username)
    if (!account) {
      error.value = `未知的演示账号：${username}`
      return
    }
    await login(account.username, account.password)
  }

  async function logout(): Promise<void> {
    try {
      await authService.logout()
    } catch {
      // 登出失败不阻塞本地状态清理，令牌已在服务端失效或本就过期
    }
    token.value = null
    currentUser.value = null
    writeToken(null)
  }

  /** 刷新页面后用本地令牌换取当前用户信息 */
  async function restore(): Promise<void> {
    if (!token.value) {
      return
    }
    try {
      currentUser.value = await authService.me()
    } catch {
      token.value = null
      currentUser.value = null
      writeToken(null)
    }
  }

  return {
    token,
    currentUser,
    loading,
    error,
    isLoggedIn,
    role,
    isAdmin,
    canManageCourse,
    canManageAssignment,
    displayName,
    login,
    loginAsDemo,
    logout,
    restore,
  }
})
