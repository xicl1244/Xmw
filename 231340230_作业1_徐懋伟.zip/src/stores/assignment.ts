import { computed, ref } from 'vue'
import { defineStore } from 'pinia'
import { assignmentService } from '@/services/assignmentService'
import { DEFAULT_PAGE_SIZE, normalizePageSize } from '@/types/api'
import type { Assignment, AssignmentQuery } from '@/types/assignment'

export function createEmptyAssignmentQuery(): AssignmentQuery {
  return { keyword: '', courseId: '', status: '' }
}

/** 作业 store：与课程 store 保持同一套「查询条件 → 分页 → 列表」一致性规则 */
export const useAssignmentStore = defineStore('assignment', () => {
  const list = ref<Assignment[]>([])
  const total = ref(0)
  const page = ref(1)
  const size = ref(DEFAULT_PAGE_SIZE)
  const query = ref<AssignmentQuery>(createEmptyAssignmentQuery())
  const loading = ref(false)
  const error = ref<string | null>(null)

  const totalPages = computed(() => Math.max(1, Math.ceil(total.value / size.value)))
  const isEmpty = computed(() => !loading.value && list.value.length === 0)
  const hasActiveQuery = computed(
    () =>
      query.value.keyword.trim() !== '' ||
      query.value.courseId !== '' ||
      query.value.status !== '',
  )

  async function fetchList(): Promise<void> {
    loading.value = true
    error.value = null
    try {
      const result = await assignmentService.list({
        ...query.value,
        page: page.value,
        size: size.value,
        sort: 'dueAt,asc',
      })
      list.value = result.list
      total.value = result.total
      if (result.page !== page.value) {
        page.value = result.page
      }
      if (result.size !== size.value) {
        size.value = result.size
      }
    } catch (err) {
      error.value = err instanceof Error ? err.message : '作业列表加载失败'
      list.value = []
      total.value = 0
    } finally {
      loading.value = false
    }
  }

  async function applyQuery(patch: Partial<AssignmentQuery>): Promise<void> {
    query.value = { ...query.value, ...patch }
    page.value = 1
    await fetchList()
  }

  async function resetQuery(): Promise<void> {
    query.value = createEmptyAssignmentQuery()
    page.value = 1
    await fetchList()
  }

  async function setPage(nextPage: number): Promise<void> {
    if (nextPage < 1 || nextPage > totalPages.value || nextPage === page.value) {
      return
    }
    page.value = nextPage
    await fetchList()
  }

  async function setSize(nextSize: number): Promise<void> {
    size.value = normalizePageSize(nextSize)
    page.value = 1
    await fetchList()
  }

  async function removeAssignment(assignmentId: string): Promise<void> {
    await assignmentService.remove(assignmentId)
    if (list.value.length === 1 && page.value > 1) {
      page.value -= 1
    }
    await fetchList()
  }

  return {
    list,
    total,
    page,
    size,
    query,
    loading,
    error,
    totalPages,
    isEmpty,
    hasActiveQuery,
    fetchList,
    applyQuery,
    resetQuery,
    setPage,
    setSize,
    removeAssignment,
  }
})
