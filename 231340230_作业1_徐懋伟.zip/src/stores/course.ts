import { computed, ref } from 'vue'
import { defineStore } from 'pinia'
import { courseService } from '@/services/courseService'
import { DEFAULT_PAGE_SIZE, normalizePageSize } from '@/types/api'
import type {
  Course,
  CourseQuery,
  CourseStats,
  CreateCoursePayload,
  CourseStatus,
  Enrollment,
  UpdateCoursePayload,
} from '@/types/course'

export type CourseViewMode = 'card' | 'table'

/** 课程列表允许的排序白名单，避免把任意字符串透传给后端 */
export const COURSE_SORT_OPTIONS = [
  { value: 'createdAt,desc', label: '按创建时间（新→旧）' },
  { value: 'createdAt,asc', label: '按创建时间（旧→新）' },
  { value: 'credits,desc', label: '按学分（高→低）' },
  { value: 'enrolledCount,desc', label: '按已选人数（多→少）' },
] as const

const VIEW_MODE_KEY = 'coursehub.course.viewMode'

export function createEmptyCourseQuery(): CourseQuery {
  return { keyword: '', term: '', category: '', status: '' }
}

function readViewMode(): CourseViewMode {
  return localStorage.getItem(VIEW_MODE_KEY) === 'table' ? 'table' : 'card'
}

/**
 * 课程 store：承载「课程列表 + 查询条件 + 分页 + 详情 + 统计」这一组强耦合状态。
 * 约定：凡是会影响列表取数的规则（重置页码、页码回退）都写在 action 里，
 * 页面只负责表达「用户想做什么」，不负责「数据该怎么变」。
 */
export const useCourseStore = defineStore('course', () => {
  const list = ref<Course[]>([])
  const total = ref(0)
  const page = ref(1)
  const size = ref(DEFAULT_PAGE_SIZE)
  const query = ref<CourseQuery>(createEmptyCourseQuery())
  const sort = ref<string>(COURSE_SORT_OPTIONS[0].value)
  const loading = ref(false)
  const error = ref<string | null>(null)

  const detail = ref<Course | null>(null)
  const detailLoading = ref(false)
  const enrollments = ref<Enrollment[]>([])
  const stats = ref<CourseStats | null>(null)
  const viewMode = ref<CourseViewMode>(readViewMode())

  const totalPages = computed(() => Math.max(1, Math.ceil(total.value / size.value)))
  const isEmpty = computed(() => !loading.value && list.value.length === 0)
  const hasActiveQuery = computed(
    () =>
      query.value.keyword.trim() !== '' ||
      query.value.term !== '' ||
      query.value.category !== '' ||
      query.value.status !== '',
  )

  async function fetchList(): Promise<void> {
    loading.value = true
    error.value = null
    try {
      const result = await courseService.list({
        ...query.value,
        page: page.value,
        size: size.value,
        sort: sort.value,
      })
      list.value = result.list
      total.value = result.total
      // 服务端会按实际数据夹紧页码，前端同步回来，避免出现"分页器停留在越界页"
      if (result.page !== page.value) {
        page.value = result.page
      }
      if (result.size !== size.value) {
        size.value = result.size
      }
    } catch (err) {
      error.value = err instanceof Error ? err.message : '课程列表加载失败'
      list.value = []
      total.value = 0
    } finally {
      loading.value = false
    }
  }

  /** 修改查询条件：必须把页码重置回第 1 页，否则会停在越界页或跳过匹配结果 */
  async function applyQuery(patch: Partial<CourseQuery>): Promise<void> {
    query.value = { ...query.value, ...patch }
    page.value = 1
    await fetchList()
  }

  async function resetQuery(): Promise<void> {
    query.value = createEmptyCourseQuery()
    page.value = 1
    await fetchList()
  }

  async function setPage(nextPage: number): Promise<void> {
    if (nextPage < 1 || nextPage > totalPages.value || nextPage === page.value) {
      return
    }
    page.value = nextPage
    await fetchList()
  }

  async function setSize(nextSize: number): Promise<void> {
    size.value = normalizePageSize(nextSize)
    // 每页条数变化后，原来的页码大概率越界，统一回到第 1 页
    page.value = 1
    await fetchList()
  }

  async function setSort(nextSort: string): Promise<void> {
    sort.value = nextSort
    page.value = 1
    await fetchList()
  }

  async function fetchDetail(courseId: string): Promise<void> {
    detailLoading.value = true
    error.value = null
    try {
      detail.value = await courseService.detail(courseId)
    } catch (err) {
      detail.value = null
      error.value = err instanceof Error ? err.message : '课程详情加载失败'
    } finally {
      detailLoading.value = false
    }
  }

  async function fetchEnrollments(courseId: string): Promise<void> {
    try {
      enrollments.value = await courseService.enrollments(courseId)
    } catch {
      // 选课名单属于详情页的次要信息，失败时不覆盖课程详情本身的错误提示
      enrollments.value = []
    }
  }

  async function fetchStats(): Promise<void> {
    try {
      stats.value = await courseService.statistics()
    } catch (err) {
      error.value = err instanceof Error ? err.message : '统计信息加载失败'
    }
  }

  async function refreshAll(): Promise<void> {
    await Promise.all([fetchList(), fetchStats()])
  }

  async function createCourse(payload: CreateCoursePayload): Promise<Course> {
    const created = await courseService.create(payload)
    // 新课程按创建时间倒序排在最前，因此回到第 1 页才能让用户看到它
    page.value = 1
    await refreshAll()
    return created
  }

  async function updateCourse(courseId: string, payload: UpdateCoursePayload): Promise<Course> {
    const updated = await courseService.update(courseId, payload)
    await refreshAll()
    if (detail.value?.id === courseId) {
      detail.value = updated
    }
    return updated
  }

  async function changeStatus(courseId: string, status: CourseStatus): Promise<Course> {
    const updated = await courseService.changeStatus(courseId, { status })
    await refreshAll()
    if (detail.value?.id === courseId) {
      detail.value = updated
    }
    return updated
  }

  /**
   * 删除课程：如果删掉的是当前页最后一条，必须把页码回退一页再取数，
   * 否则会出现"空列表停在最后一页"的假象。
   */
  async function removeCourse(courseId: string): Promise<void> {
    await courseService.remove(courseId)
    const removedLastItemOnPage = list.value.length === 1 && page.value > 1
    if (removedLastItemOnPage) {
      page.value -= 1
    }
    if (detail.value?.id === courseId) {
      detail.value = null
      enrollments.value = []
    }
    await refreshAll()
  }

  function setViewMode(nextMode: CourseViewMode): void {
    viewMode.value = nextMode
    localStorage.setItem(VIEW_MODE_KEY, nextMode)
  }

  function toggleViewMode(): void {
    setViewMode(viewMode.value === 'card' ? 'table' : 'card')
  }

  return {
    list,
    total,
    page,
    size,
    query,
    sort,
    loading,
    error,
    detail,
    detailLoading,
    enrollments,
    stats,
    viewMode,
    totalPages,
    isEmpty,
    hasActiveQuery,
    fetchList,
    applyQuery,
    resetQuery,
    setPage,
    setSize,
    setSort,
    fetchDetail,
    fetchEnrollments,
    fetchStats,
    refreshAll,
    createCourse,
    updateCourse,
    changeStatus,
    removeCourse,
    setViewMode,
    toggleViewMode,
  }
})
