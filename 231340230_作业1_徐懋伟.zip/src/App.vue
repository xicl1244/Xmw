<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { RouterLink, RouterView } from 'vue-router'
import { APP_TITLE } from '@/router'
import { DEMO_ACCOUNTS, useAuthStore } from '@/stores/auth'
import type { UserRole } from '@/types/user'

const authStore = useAuthStore()
const identityError = ref<string | null>(null)
const switching = ref(false)

const NAV_ITEMS = [
  { to: '/', label: '概览' },
  { to: '/courses', label: '课程管理' },
  { to: '/assignments', label: '作业管理' },
]

const ROLE_LABELS: Record<UserRole | 'guest', string> = {
  student: '学生',
  teacher: '教师',
  admin: '管理员',
  guest: '访客',
}

const roleLabel = computed(() => ROLE_LABELS[authStore.role])
const currentUsername = computed(() => authStore.currentUser?.username ?? '')

/** 默认演示身份：教师，便于直接看到"新建/编辑/删除"按钮 */
const DEFAULT_DEMO_ACCOUNT = DEMO_ACCOUNTS.find((item) => item.username === 't1001')

async function switchIdentity(event: Event): Promise<void> {
  const target = event.target as HTMLSelectElement
  switching.value = true
  identityError.value = null
  try {
    await authStore.loginAsDemo(target.value)
  } catch {
    identityError.value = authStore.error ?? '切换身份失败'
  } finally {
    switching.value = false
  }
}

async function signOut(): Promise<void> {
  switching.value = true
  try {
    await authStore.logout()
  } finally {
    switching.value = false
  }
}

onMounted(async () => {
  // 刷新页面后先用本地令牌换取当前用户；没有令牌时自动以演示教师身份登录
  await authStore.restore()
  if (!authStore.isLoggedIn && DEFAULT_DEMO_ACCOUNT) {
    await authStore.login(DEFAULT_DEMO_ACCOUNT.username, DEFAULT_DEMO_ACCOUNT.password)
  }
})
</script>

<template>
  <a class="skip-link" href="#main-content">跳到主内容</a>

  <header class="app-header">
    <div class="app-header__inner">
      <RouterLink class="app-header__brand" to="/">
        <span class="app-header__logo" aria-hidden="true">📚</span>
        <span>{{ APP_TITLE }}</span>
      </RouterLink>

      <nav class="app-nav" aria-label="主导航">
        <RouterLink v-for="item in NAV_ITEMS" :key="item.to" class="app-nav__link" :to="item.to">
          {{ item.label }}
        </RouterLink>
      </nav>

      <div class="app-header__identity">
        <label class="field__label" for="identity-switcher">当前身份</label>
        <select
          id="identity-switcher"
          class="select select--compact"
          :value="currentUsername"
          :disabled="switching"
          @change="switchIdentity"
        >
          <option v-for="account in DEMO_ACCOUNTS" :key="account.username" :value="account.username">
            {{ account.label }}
          </option>
        </select>
        <p class="app-header__user" aria-live="polite">
          {{ authStore.displayName }}（{{ roleLabel }}）
        </p>
        <button type="button" class="btn btn--sm" :disabled="switching" @click="signOut">
          退出登录
        </button>
      </div>
    </div>

    <p v-if="identityError" class="app-header__error" role="alert">{{ identityError }}</p>
  </header>

  <main id="main-content" class="app-shell">
    <RouterView />
  </main>

  <footer class="app-footer">
    <p>
      接口契约版本 <code>v1.0.0</code> · 基础路径 <code>/api/v1</code> · 契约文档
      <code>docs/api-contract-v1.md</code> · Vue 3 + TypeScript + Pinia + Express Mock
    </p>
    <p class="app-footer__note">
      页面中的数据均为演示用的虚构示例数据（邮箱统一使用 example.com 域），不含任何真实个人信息。
    </p>
  </footer>
</template>

<style scoped>
.skip-link {
  position: absolute;
  top: -60px;
  left: var(--space-4);
  z-index: 50;
  padding: var(--space-2) var(--space-3);
  border-radius: var(--radius-md);
  background: var(--color-primary);
  color: #fff;
  font-size: 14px;
}

.skip-link:focus {
  top: var(--space-3);
}

.app-header {
  border-bottom: 1px solid var(--color-border);
  background: var(--color-surface);
  box-shadow: var(--shadow-sm);
}

.app-header__inner {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-4);
  align-items: center;
  justify-content: space-between;
  max-width: 1180px;
  margin: 0 auto;
  padding: var(--space-3) var(--space-5);
}

.app-header__brand {
  display: inline-flex;
  gap: var(--space-2);
  align-items: center;
  color: var(--color-text);
  font-size: 17px;
  font-weight: 700;
}

.app-header__brand:hover {
  text-decoration: none;
}

.app-header__logo {
  font-size: 20px;
}

.app-nav {
  display: flex;
  gap: var(--space-1);
}

.app-nav__link {
  padding: 6px var(--space-3);
  border-radius: var(--radius-md);
  color: var(--color-text-muted);
  font-size: 14px;
}

.app-nav__link:hover {
  background: var(--color-surface-muted);
  text-decoration: none;
}

.app-nav__link.router-link-exact-active {
  background: var(--color-primary-soft);
  color: var(--color-primary);
  font-weight: 600;
}

.app-header__identity {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-2);
  align-items: center;
}

.app-header__user {
  color: var(--color-text-muted);
  font-size: 13px;
}

.app-header__error {
  max-width: 1180px;
  margin: 0 auto var(--space-3);
  padding: 0 var(--space-5);
  color: var(--color-danger);
  font-size: 13px;
}

.select--compact {
  width: auto;
  min-height: 34px;
  padding: 2px var(--space-2);
  font-size: 13px;
}

.app-footer {
  max-width: 1180px;
  margin: 0 auto;
  padding: 0 var(--space-5) var(--space-6);
  color: var(--color-text-muted);
  font-size: 13px;
}

.app-footer__note {
  margin-top: var(--space-2);
}
</style>
