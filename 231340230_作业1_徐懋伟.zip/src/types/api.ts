/**
 * 统一返回信封类型定义。
 * 与 docs/api-contract-v1.md「2. 统一返回信封」一节一一对应。
 */

/** 业务状态码：0 表示业务成功，其余表示业务失败（详见 docs/api-contract-v1.md） */
export const BusinessCode = {
  /** 200 业务成功 */
  SUCCESS: 0,
  /** 400 参数校验失败 */
  PARAM_INVALID: 10001,
  /** 404 资源不存在 */
  RESOURCE_NOT_FOUND: 10002,
  /** 405 方法不允许 */
  METHOD_NOT_ALLOWED: 10003,
  /** 401 未登录或登录已过期 */
  UNAUTHENTICATED: 20001,
  /** 403 已登录但角色/数据权限不足 */
  FORBIDDEN: 20002,
  /** 200 业务冲突（唯一性冲突、状态冲突） */
  BUSINESS_CONFLICT: 30001,
  /** 200 业务规则不满足（容量已满、作业已截止等） */
  RULE_VIOLATION: 30002,
  /** 429 请求过于频繁 */
  RATE_LIMITED: 40001,
  /** 500 服务端内部错误 */
  INTERNAL_ERROR: 50000,
} as const

export type BusinessCodeValue = (typeof BusinessCode)[keyof typeof BusinessCode]

/** 逐字段的校验错误项 */
export interface FieldError {
  /** 出错字段的路径，请求体字段用字段名，路径参数用 params.xxx */
  field: string
  /** 该字段的错误原因，不含字段名 */
  message: string
}

/** 服务端统一返回信封 */
export interface ApiEnvelope<T> {
  code: number
  message: string
  data: T
  /** 服务端生成时间，ISO 8601 UTC 毫秒精度 */
  timestamp: string
  /** 请求追踪号，与响应头 X-Request-Id 一致 */
  requestId: string
}

/** 分页返回结构，被所有列表端点复用 */
export interface PageResult<T> {
  list: T[]
  total: number
  page: number
  size: number
}

/** 分页查询公共参数 */
export interface PageQuery {
  page?: number
  size?: number
  sort?: string
}

/** 列表页默认每页条数，前后端保持一致 */
export const DEFAULT_PAGE_SIZE = 10

/** 每页条数可选项 */
export const PAGE_SIZE_OPTIONS = [5, 10, 20, 50] as const

/** 分页参数白名单：size 允许 1~100 */
export function normalizePageSize(size: number): number {
  if (!Number.isInteger(size) || size < 1 || size > 100) {
    return DEFAULT_PAGE_SIZE
  }
  return size
}
