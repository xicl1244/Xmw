/** 用户与登录相关类型，对应契约「5. 数据字典 · User」 */

/** 角色：guest 表示未登录的浏览者，仅存在于前端 */
export type UserRole = 'student' | 'teacher' | 'admin'

export type UserStatus = 'active' | 'inactive' | 'locked'

export interface User {
  id: string
  username: string
  name: string
  /** 邮箱，响应中的示例数据一律使用 example.com 域 */
  email: string
  role: UserRole
  status: UserStatus
  createdAt: string
  updatedAt: string
}

export interface LoginPayload {
  username: string
  /** 口令仅出现在请求体中，任何响应都不得回传 */
  password: string
}

export interface LoginResult {
  token: string
  /** 访问令牌有效期（秒） */
  expiresIn: number
  user: User
}
