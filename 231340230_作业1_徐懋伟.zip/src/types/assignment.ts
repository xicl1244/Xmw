import type { PageQuery } from './api'

/** 作业实体，对应契约「5. 数据字典 · Assignment」 */

export type AssignmentStatus = 'draft' | 'published' | 'closed'

export interface Assignment {
  id: string
  courseId: string
  title: string
  description: string | null
  /** 发布时间，ISO 8601 UTC */
  publishAt: string
  /** 截止时间，必须晚于 publishAt */
  dueAt: string
  /** 满分，1 ~ 100 的整数 */
  maxScore: number
  status: AssignmentStatus
  /** 已提交份数，服务端生成，只读 */
  submitCount: number
  createdAt: string
  updatedAt: string
}

export interface CreateAssignmentPayload {
  courseId: string
  title: string
  description?: string | null
  publishAt: string
  dueAt: string
  maxScore: number
  status?: AssignmentStatus
}

export type UpdateAssignmentPayload = CreateAssignmentPayload

export interface AssignmentQuery {
  keyword: string
  courseId: string
  status: AssignmentStatus | ''
}

export type AssignmentListQuery = AssignmentQuery & PageQuery
