import type { PageQuery } from './api'

/** 课程实体，对应契约「5. 数据字典 · Course」 */

/** 课程类别，枚举值一律使用英文小写（状态类字段不得使用中文枚举） */
export type CourseCategory = 'required' | 'elective' | 'general'

/** 课程状态 */
export type CourseStatus = 'draft' | 'open' | 'closed' | 'archived'

export interface Course {
  id: string
  /** 课程代码，全校唯一，形如 CS1001 */
  code: string
  title: string
  teacherName: string
  /** 学年学期，形如 2026-2027-1 */
  term: string
  category: CourseCategory
  /** 学分，0.5 ~ 10，步长 0.5 */
  credits: number
  /** 容量，1 ~ 300 的整数 */
  capacity: number
  /** 已选人数，服务端生成，只读 */
  enrolledCount: number
  status: CourseStatus
  description: string | null
  createdAt: string
  updatedAt: string
}

/** 创建课程请求体，id / enrolledCount / createdAt / updatedAt 由服务端生成 */
export interface CreateCoursePayload {
  code: string
  title: string
  teacherName: string
  term: string
  category: CourseCategory
  credits: number
  capacity: number
  status?: CourseStatus
  description?: string | null
}

/** 全量更新请求体，字段与创建一致（PUT 语义） */
export type UpdateCoursePayload = CreateCoursePayload

export interface ChangeStatusPayload {
  status: CourseStatus
}

/** 课程列表查询条件 */
export interface CourseQuery {
  /** 关键字，匹配课程名/课程代码/任课教师，1 ~ 50 字符 */
  keyword: string
  /** 学年学期，空串表示不筛选 */
  term: string
  category: CourseCategory | ''
  status: CourseStatus | ''
}

export type CourseListQuery = CourseQuery & PageQuery

/** 列表页统计行使用的聚合结果 */
export interface CourseStats {
  courseTotal: number
  openTotal: number
  /** 未归档课程的学分合计 */
  creditTotal: number
  assignmentTotal: number
  /** 统计口径的生成时间 */
  generatedAt: string
}

/** 选课记录 */
export interface Enrollment {
  id: string
  courseId: string
  studentId: string
  studentName: string
  status: 'enrolled' | 'dropped' | 'completed'
  score: number | null
  createdAt: string
}
