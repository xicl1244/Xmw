<script setup lang="ts">
import EmptyState from '@/components/EmptyState.vue'
import { useRouter } from 'vue-router'

const router = useRouter()
</script>

<template>
  <div class="surface section">
    <EmptyState
      title="页面不存在"
      description="你访问的地址没有对应的组件。请通过顶部导航回到概览或课程管理页。"
      action-text="回到概览"
      @action="router.push('/')"
    />
  </div>
</template>
