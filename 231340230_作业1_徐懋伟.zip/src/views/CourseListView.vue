<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import AppPagination from '@/components/AppPagination.vue'
import AppStatCard from '@/components/AppStatCard.vue'
import CourseCard from '@/components/CourseCard.vue'
import CourseDetailDrawer from '@/components/CourseDetailDrawer.vue'
import CourseFormDialog from '@/components/CourseFormDialog.vue'
import EmptyState from '@/components/EmptyState.vue'
import StatusTag from '@/components/StatusTag.vue'
import { useAuthStore } from '@/stores/auth'
import { COURSE_SORT_OPTIONS, useCourseStore } from '@/stores/course'
import type { Course, CourseCategory, CourseStatus } from '@/types/course'

const route = useRoute()
const router = useRouter()
const courseStore = useCourseStore()
const authStore = useAuthStore()

/* ---------------- 留在组件里的瞬时 UI 状态（不进 store） ---------------- */
/** 详情抽屉是否展开：只有本页面关心，路由离开即随组件销毁 */
const drawerOpen = ref(false)
/** 抽屉当前查看的课程 id */
const drawerCourseId = ref<string | null>(null)
/** 新建/编辑表单是否展开 */
const formOpen = ref(false)
/** 正在编辑的课程，null 表示新建 */
const editingCourse = ref<Course | null>(null)
/** 待删除课程（二次确认对话框的目标），null 表示对话框关闭 */
const confirmTarget = ref<Course | null>(null)
const confirmError = ref<string | null>(null)
const deleting = ref(false)
const statusUpdatingId = ref<string | null>(null)
const actionMessage = ref<string | null>(null)

/** 关键字输入框草稿：只有点击"查询"或回车才写回 store 的查询条件 */
const keywordInput = ref(courseStore.query.keyword)

const TERM_OPTIONS = ['2026-2027-1', '2026-2027-2', '2025-2026-2']
const CATEGORY_OPTIONS: { value: CourseCategory; label: string }[] = [
  { value: 'required', label: '必修' },
  { value: 'elective', label: '选修' },
  { value: 'general', label: '通识' },
]
const STATUS_OPTIONS: { value: CourseStatus; label: string }[] = [
  { value: 'draft', label: '草稿' },
  { value: 'open', label: '进行中' },
  { value: 'closed', label: '已结课' },
  { value: 'archived', label: '已归档' },
]

const courses = computed(() => courseStore.list)
const stats = computed(() => courseStore.stats)
const isEmptyResult = computed(() => courseStore.isEmpty)

/** 预览条数：给屏幕阅读器播报"列表发生变化" */
const listSummary = computed(() =>
  courseStore.loading
    ? '课程列表加载中'
    : `已显示 ${courses.value.length} 门课程，共 ${courseStore.total} 门`,
)

watch(
  () => courseStore.query.keyword,
  (keyword) => {
    keywordInput.value = keyword
  },
)

/* ---------------- 查询与分页：全部调用 store 的 action ---------------- */

function submitQuery(): void {
  void courseStore.applyQuery({ keyword: keywordInput.value.trim() })
}

function resetQuery(): void {
  keywordInput.value = ''
  void courseStore.resetQuery()
}

function onTermChange(event: Event): void {
  void courseStore.applyQuery({ term: (event.target as HTMLSelectElement).value })
}

function onCategoryChange(event: Event): void {
  void courseStore.applyQuery({
    category: (event.target as HTMLSelectElement).value as CourseCategory | '',
  })
}

function onStatusChange(event: Event): void {
  void courseStore.applyQuery({
    status: (event.target as HTMLSelectElement).value as CourseStatus | '',
  })
}

function onSortChange(event: Event): void {
  void courseStore.setSort((event.target as HTMLSelectElement).value)
}

function onPageChange(page: number, size: number): void {
  if (size !== courseStore.size) {
    void courseStore.setSize(size)
    return
  }
  void courseStore.setPage(page)
}

function handleStatSelect(filterKey: string): void {
  void courseStore.applyQuery({ status: filterKey === 'openTotal' ? 'open' : '' })
}

function filterByStatus(status: CourseStatus): void {
  void courseStore.applyQuery({ status })
  closeDrawer()
}

/* ---------------- 详情抽屉 ---------------- */

function openDrawer(courseId: string): void {
  drawerCourseId.value = courseId
  drawerOpen.value = true
  void router.replace({ query: { ...route.query, course: courseId } })
}

function handleDrawerVisible(value: boolean): void {
  if (!value) {
    closeDrawer()
    return
  }
  drawerOpen.value = true
}

function closeDrawer(): void {
  drawerOpen.value = false
  drawerCourseId.value = null
  const nextQuery = { ...route.query }
  delete nextQuery.course
  void router.replace({ query: nextQuery })
}

/* ---------------- 新建 / 编辑 / 删除 ---------------- */

function openCreateForm(): void {
  editingCourse.value = null
  formOpen.value = true
}

function openEditForm(course: Course): void {
  editingCourse.value = course
  formOpen.value = true
}

function handleSaved(course: Course): void {
  actionMessage.value = `课程「${course.title}」保存成功，列表与统计已同步刷新。`
}

function askRemove(course: Course): void {
  confirmTarget.value = course
  confirmError.value = null
}

async function confirmRemove(): Promise<void> {
  const target = confirmTarget.value
  if (!target) {
    return
  }
  deleting.value = true
  confirmError.value = null
  try {
    await courseStore.removeCourse(target.id)
    actionMessage.value = `课程「${target.title}」已删除（服务端软删除，状态变为 archived）。`
    confirmTarget.value = null
    closeDrawer()
  } catch (error) {
    // 例如仍有在修学生的课程被删除时，服务端会返回业务码 30002
    confirmError.value = error instanceof Error ? error.message : '删除失败'
  } finally {
    deleting.value = false
  }
}

async function changeStatus(course: Course, event: Event): Promise<void> {
  const nextStatus = (event.target as HTMLSelectElement).value as CourseStatus
  statusUpdatingId.value = course.id
  try {
    const updated = await courseStore.changeStatus(course.id, nextStatus)
    actionMessage.value = `课程「${updated.title}」状态已更新。`
  } catch (error) {
    actionMessage.value = error instanceof Error ? error.message : '状态更新失败'
    await courseStore.fetchList()
  } finally {
    statusUpdatingId.value = null
  }
}

function openDashboardHint(): void {
  void router.push({ name: 'dashboard' })
}

onMounted(() => {
  // 从概览页点了某门课的"查看详情"时，query 里带着 course=xxx
  const courseFromQuery = route.query.course
  if (typeof courseFromQuery === 'string' && courseFromQuery !== '') {
    openDrawer(courseFromQuery)
  }
  void courseStore.refreshAll()
})
</script>

<template>
  <div class="stack">
    <div class="page-head">
      <div>
        <h1>课程管理</h1>
        <p class="page-head__desc">
          查询条件、页码与列表数据都放在 <code>useCourseStore</code> 里；本页只保留抽屉是否展开、
          表单草稿这类"离开页面即可丢弃"的状态。
        </p>
      </div>
      <div class="row">
        <button type="button" class="btn" :disabled="courseStore.loading" @click="courseStore.fetchList()">
          刷新列表
        </button>
        <button
          v-if="authStore.canManageCourse"
          type="button"
          class="btn btn--primary"
          @click="openCreateForm"
        >
          新建课程
        </button>
      </div>
    </div>

    <section class="stats-row" aria-label="课程统计">
      <AppStatCard
        label="课程总数"
        :value="stats?.courseTotal ?? 0"
        unit="门"
        tone="primary"
        clickable
        filter-key="courseTotal"
        @select="handleStatSelect"
      />
      <AppStatCard
        label="进行中"
        :value="stats?.openTotal ?? 0"
        unit="门"
        tone="success"
        clickable
        filter-key="openTotal"
        @select="handleStatSelect"
      />
      <AppStatCard label="学分合计" :value="stats?.creditTotal ?? 0" unit="分" />
    </section>

    <section class="surface section stack">
      <form class="toolbar query-form" @submit.prevent="submitQuery">
        <div class="field query-form__field">
          <label class="field__label" for="course-keyword">关键字</label>
          <input
            id="course-keyword"
            v-model="keywordInput"
            class="input"
            type="search"
            name="keyword"
            placeholder="课程名称 / 课程代码 / 任课教师"
          />
        </div>

        <div class="field query-form__field">
          <label class="field__label" for="course-term-filter">学年学期</label>
          <select
            id="course-term-filter"
            class="select"
            name="term"
            :value="courseStore.query.term"
            @change="onTermChange"
          >
            <option value="">全部学期</option>
            <option v-for="term in TERM_OPTIONS" :key="term" :value="term">{{ term }}</option>
          </select>
        </div>

        <div class="field query-form__field">
          <label class="field__label" for="course-category-filter">课程类别</label>
          <select
            id="course-category-filter"
            class="select"
            name="category"
            :value="courseStore.query.category"
            @change="onCategoryChange"
          >
            <option value="">全部类别</option>
            <option v-for="option in CATEGORY_OPTIONS" :key="option.value" :value="option.value">
              {{ option.label }}
            </option>
          </select>
        </div>

        <div class="field query-form__field">
          <label class="field__label" for="course-status-filter">课程状态</label>
          <select
            id="course-status-filter"
            class="select"
            name="status"
            :value="courseStore.query.status"
            @change="onStatusChange"
          >
            <option value="">全部状态</option>
            <option v-for="option in STATUS_OPTIONS" :key="option.value" :value="option.value">
              {{ option.label }}
            </option>
          </select>
        </div>

        <div class="field query-form__field">
          <label class="field__label" for="course-sort">排序</label>
          <select
            id="course-sort"
            class="select"
            name="sort"
            :value="courseStore.sort"
            @change="onSortChange"
          >
            <option v-for="option in COURSE_SORT_OPTIONS" :key="option.value" :value="option.value">
              {{ option.label }}
            </option>
          </select>
        </div>

        <div class="row query-form__actions">
          <button type="submit" class="btn btn--primary">查询</button>
          <button type="button" class="btn" @click="resetQuery">重置</button>
        </div>
      </form>

      <div class="toolbar">
        <p class="page-head__desc" aria-live="polite">{{ listSummary }}</p>
        <div class="row">
          <button
            type="button"
            class="btn btn--sm"
            :class="{ 'btn--primary': courseStore.viewMode === 'card' }"
            :aria-pressed="courseStore.viewMode === 'card'"
            @click="courseStore.setViewMode('card')"
          >
            卡片视图
          </button>
          <button
            type="button"
            class="btn btn--sm"
            :class="{ 'btn--primary': courseStore.viewMode === 'table' }"
            :aria-pressed="courseStore.viewMode === 'table'"
            @click="courseStore.setViewMode('table')"
          >
            表格视图
          </button>
        </div>
      </div>

      <p v-if="actionMessage" class="alert alert--success" role="status">
        <span class="alert__icon" aria-hidden="true">✓</span>
        <span>{{ actionMessage }}</span>
      </p>

      <p v-if="courseStore.error" class="alert alert--error" role="alert">
        <span class="alert__icon" aria-hidden="true">!</span>
        <span>{{ courseStore.error }}</span>
        <button type="button" class="btn btn--sm" @click="courseStore.fetchList()">重试</button>
      </p>

      <div v-if="courseStore.loading" class="skeleton-stack">
        <p class="sr-only">课程列表加载中</p>
        <div class="skeleton"></div>
        <div class="skeleton"></div>
        <div class="skeleton"></div>
      </div>

      <template v-else-if="isEmptyResult">
        <EmptyState
          :title="courseStore.hasActiveQuery ? '没有符合条件的课程' : '暂无课程数据'"
          :description="
            courseStore.hasActiveQuery
              ? '当前查询条件没有匹配结果，可以清空条件后重新查询。'
              : '可以从新建课程开始，或确认 Mock 服务是否已启动。'
          "
          :action-text="
            courseStore.hasActiveQuery ? '清空查询条件' : authStore.canManageCourse ? '新建课程' : ''
          "
          @action="courseStore.hasActiveQuery ? resetQuery() : openCreateForm()"
        />
      </template>

      <div v-else-if="courseStore.viewMode === 'card'" class="card-grid">
        <CourseCard
          v-for="course in courses"
          :key="course.id"
          :course="course"
          :can-manage="authStore.canManageCourse"
          :selected="drawerOpen && drawerCourseId === course.id"
          @view="openDrawer"
          @edit="openEditForm"
          @remove="askRemove"
          @filter-status="filterByStatus"
        />
      </div>

      <div v-else class="table-wrap">
        <table class="data-table">
          <caption>
            课程列表（表格视图）。状态列可直接切换，切换调用
            <code>PATCH /api/v1/courses/{courseId}/status</code>。
          </caption>
          <thead>
            <tr>
              <th scope="col">课程代码</th>
              <th scope="col">课程名称</th>
              <th scope="col">任课教师</th>
              <th scope="col">学期</th>
              <th scope="col">类别</th>
              <th scope="col" class="data-table__num">学分</th>
              <th scope="col" class="data-table__num">已选</th>
              <th scope="col">状态</th>
              <th scope="col">操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="course in courses" :key="course.id">
              <td>{{ course.code }}</td>
              <td>{{ course.title }}</td>
              <td>{{ course.teacherName }}</td>
              <td>{{ course.term }}</td>
              <td>{{ course.category }}</td>
              <td class="data-table__num">{{ course.credits }}</td>
              <td class="data-table__num">{{ course.enrolledCount }}/{{ course.capacity }}</td>
              <td>
                <StatusTag :value="course.status" domain="course" />
                <select
                  v-if="authStore.canManageCourse"
                  class="select select--inline"
                  :value="course.status"
                  :disabled="statusUpdatingId === course.id"
                  :aria-label="`调整课程「${course.title}」的状态`"
                  @change="changeStatus(course, $event)"
                >
                  <option v-for="option in STATUS_OPTIONS" :key="option.value" :value="option.value">
                    {{ option.label }}
                  </option>
                </select>
              </td>
              <td>
                <div class="row row--tight">
                  <button type="button" class="btn btn--sm" @click="openDrawer(course.id)">
                    详情
                  </button>
                  <button
                    v-if="authStore.canManageCourse"
                    type="button"
                    class="btn btn--sm"
                    @click="openEditForm(course)"
                  >
                    编辑
                  </button>
                  <button
                    v-if="authStore.canManageCourse"
                    type="button"
                    class="btn btn--sm btn--danger"
                    @click="askRemove(course)"
                  >
                    删除
                  </button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <AppPagination
        v-if="!isEmptyResult"
        :page="courseStore.page"
        :size="courseStore.size"
        :total="courseStore.total"
        :disabled="courseStore.loading"
        @change="onPageChange"
      />

      <p class="page-head__desc">
        <span aria-hidden="true">ⓘ</span>
        修改查询条件时页码会重置为第 1 页；删除本页最后一条记录时页码会自动回退一页，
        这两条规则都写在 <code>useCourseStore</code> 的 action 里。
        <button type="button" class="btn btn--ghost" @click="openDashboardHint">返回概览</button>
      </p>
    </section>

    <CourseDetailDrawer
      :open="drawerOpen"
      :course-id="drawerCourseId"
      @update:open="handleDrawerVisible"
      @edit="openEditForm"
      @remove="askRemove"
      @filter-status="filterByStatus"
    />

    <CourseFormDialog
      :open="formOpen"
      :course="editingCourse"
      @update:open="formOpen = $event"
      @saved="handleSaved"
    />

    <div v-if="confirmTarget" class="modal-backdrop" @click.self="confirmTarget = null">
      <section
        class="modal"
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="confirm-remove-title"
        aria-describedby="confirm-remove-desc"
      >
        <h2 id="confirm-remove-title">确认删除课程</h2>
        <p id="confirm-remove-desc">
          即将删除「{{ confirmTarget.title }}」（{{ confirmTarget.code }}）。服务端执行软删除，
          删除后课程状态变为 <code>archived</code>，列表中仍可通过"已归档"筛选查看。
        </p>
        <p v-if="confirmError" class="alert alert--error" role="alert">
          <span class="alert__icon" aria-hidden="true">!</span>
          <span>{{ confirmError }}</span>
        </p>
        <div class="modal__foot">
          <button type="button" class="btn" :disabled="deleting" @click="confirmTarget = null">
            取消
          </button>
          <button type="button" class="btn btn--danger" :disabled="deleting" @click="confirmRemove">
            {{ deleting ? '删除中…' : '确定删除' }}
          </button>
        </div>
      </section>
    </div>
  </div>
</template>

<style scoped>
.stats-row {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-3);
}

.query-form {
  align-items: flex-end;
}

.query-form__field {
  flex: 1 1 180px;
}

.query-form__actions {
  flex: 0 0 auto;
}

.card-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: var(--space-3);
}

.row--tight {
  gap: var(--space-2);
}

.select--inline {
  width: auto;
  min-height: 32px;
  padding: 2px var(--space-2);
  font-size: 13px;
}

.modal-backdrop {
  position: fixed;
  inset: 0;
  z-index: 40;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--space-5);
  background: rgba(16, 26, 48, 0.42);
}

.modal {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
  width: min(460px, 100%);
  padding: var(--space-5);
  border-radius: var(--radius-lg);
  background: var(--color-surface);
  box-shadow: var(--shadow-md);
}

.modal__foot {
  display: flex;
  gap: var(--space-3);
  justify-content: flex-end;
}
</style>
