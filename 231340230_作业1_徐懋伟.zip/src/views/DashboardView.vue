<script setup lang="ts">
import { computed, onMounted } from 'vue'
import { RouterLink, useRouter } from 'vue-router'
import AppStatCard from '@/components/AppStatCard.vue'
import CourseCard from '@/components/CourseCard.vue'
import EmptyState from '@/components/EmptyState.vue'
import { useAuthStore } from '@/stores/auth'
import { useCourseStore } from '@/stores/course'

const router = useRouter()
const courseStore = useCourseStore()
const authStore = useAuthStore()

const stats = computed(() => courseStore.stats)
const recentCourses = computed(() => courseStore.list.slice(0, 3))

const ENVELOPE_SAMPLE = `{
  "code": 0,
  "message": "OK",
  "data": { "list": [], "total": 15, "page": 1, "size": 10 },
  "timestamp": "2026-09-16T06:21:33.412Z",
  "requestId": "3f9c1d42-6b7e-4f0a-9c2d-51b8e0a7d3a1"
}`

function formatDateTime(value: string): string {
  const date = new Date(value)
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString('zh-CN', { hour12: false })
}

/** 点击统计卡：把"看一眼"变成"带着条件去列表页" */
function handleStatSelect(filterKey: string): void {
  if (filterKey === 'assignmentTotal') {
    void router.push({ name: 'assignments' })
    return
  }
  if (filterKey === 'openTotal') {
    void courseStore.applyQuery({ status: 'open' })
  } else {
    void courseStore.resetQuery()
  }
  void router.push({ name: 'courses' })
}

/** 概览页复用 CourseCard，点击"查看详情"跳到课程页并通过 query 自动打开抽屉 */
function openCourseDetail(courseId: string): void {
  void router.push({ name: 'courses', query: { course: courseId } })
}

onMounted(() => {
  void courseStore.fetchStats()
  void courseStore.fetchList()
})
</script>

<template>
  <div class="stack">
    <div class="page-head">
      <div>
        <h1>概览</h1>
        <p class="page-head__desc">
          当前身份：{{ authStore.displayName }}（{{ authStore.role }}）。统计数字来自
          <code>GET /api/v1/statistics/overview</code>，与课程列表共用同一份 store 状态。
        </p>
      </div>
    </div>

    <p v-if="courseStore.error" class="alert alert--error" role="alert">
      <span class="alert__icon" aria-hidden="true">!</span>
      <span>{{ courseStore.error }}</span>
    </p>

    <section class="stats-row" aria-label="关键指标">
      <AppStatCard
        label="课程总数"
        :value="stats?.courseTotal ?? 0"
        unit="门"
        tone="primary"
        clickable
        filter-key="courseTotal"
        hint="点击查看全部课程"
        @select="handleStatSelect"
      />
      <AppStatCard
        label="进行中课程"
        :value="stats?.openTotal ?? 0"
        unit="门"
        tone="success"
        clickable
        filter-key="openTotal"
        hint="status = open"
        @select="handleStatSelect"
      />
      <AppStatCard
        label="学分合计"
        :value="stats?.creditTotal ?? 0"
        unit="分"
        hint="所有未归档课程的学分之和"
      />
      <AppStatCard
        label="作业总数"
        :value="stats?.assignmentTotal ?? 0"
        unit="个"
        tone="warning"
        clickable
        filter-key="assignmentTotal"
        hint="点击进入作业管理"
        @select="handleStatSelect"
      />
    </section>

    <div class="dashboard-grid">
      <section class="surface section stack">
        <div class="toolbar">
          <h2>最近更新的课程</h2>
          <RouterLink class="btn btn--sm" to="/courses">全部课程</RouterLink>
        </div>

        <div v-if="recentCourses.length > 0" class="card-grid">
          <CourseCard
            v-for="course in recentCourses"
            :key="course.id"
            :course="course"
            dense
            @view="openCourseDetail"
          />
        </div>
        <EmptyState
          v-else
          title="还没有课程数据"
          description="确认 Mock 服务已启动后刷新页面，或到课程管理页新建一门课程。"
        />
      </section>

      <section class="surface section stack">
        <h2>接口契约速览</h2>
        <dl class="meta-list">
          <div>
            <dt>契约版本</dt>
            <dd>v1.0.0（<code>docs/api-contract-v1.md</code>）</dd>
          </div>
          <div>
            <dt>基础路径</dt>
            <dd><code>/api/v1</code></dd>
          </div>
          <div>
            <dt>端点数量</dt>
            <dd>19 个（含 3 个认证端点）</dd>
          </div>
          <div>
            <dt>统计刷新时间</dt>
            <dd>{{ stats ? formatDateTime(stats.generatedAt) : '—' }}</dd>
          </div>
        </dl>
        <h3>统一返回信封示例</h3>
        <pre class="code-block">{{ ENVELOPE_SAMPLE }}</pre>
        <p class="page-head__desc">
          业务失败时 <code>code</code> 非 0；其中"业务冲突"与"规则不满足"两类仍返回 HTTP 200，
          以便前端统一走一套错误处理分支。
        </p>
      </section>
    </div>
  </div>
</template>

<style scoped>
.stats-row {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-3);
}

.dashboard-grid {
  display: grid;
  grid-template-columns: minmax(0, 1.4fr) minmax(0, 1fr);
  gap: var(--space-4);
  align-items: start;
}

.card-grid {
  display: grid;
  gap: var(--space-3);
}

.meta-list {
  display: grid;
  gap: var(--space-3);
  margin: 0;
}

.meta-list dt {
  color: var(--color-text-muted);
  font-size: 13px;
}

.meta-list dd {
  margin: 0;
  font-size: 14px;
}

.code-block {
  overflow-x: auto;
  margin: 0;
  padding: var(--space-3);
  border-radius: var(--radius-md);
  background: #1c2438;
  color: #e6ebf7;
  font-family: var(--font-mono);
  font-size: 12px;
  line-height: 1.6;
}

@media (max-width: 900px) {
  .dashboard-grid {
    grid-template-columns: minmax(0, 1fr);
  }
}
</style>
