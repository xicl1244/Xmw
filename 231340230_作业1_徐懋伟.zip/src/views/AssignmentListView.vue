<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue'
import AppPagination from '@/components/AppPagination.vue'
import EmptyState from '@/components/EmptyState.vue'
import StatusTag from '@/components/StatusTag.vue'
import { courseService } from '@/services/courseService'
import { useAssignmentStore } from '@/stores/assignment'
import { useAuthStore } from '@/stores/auth'
import type { AssignmentStatus } from '@/types/assignment'
import type { Course } from '@/types/course'

const assignmentStore = useAssignmentStore()
const authStore = useAuthStore()

/** 课程下拉选项：一次性取 100 条（契约允许的 size 上限为 100） */
const courseOptions = ref<Course[]>([])
const keywordInput = ref(assignmentStore.query.keyword)
const confirmTargetId = ref<string | null>(null)
const confirmError = ref<string | null>(null)
const deleting = ref(false)
const actionMessage = ref<string | null>(null)

const STATUS_OPTIONS: { value: AssignmentStatus; label: string }[] = [
  { value: 'draft', label: '未发布' },
  { value: 'published', label: '已发布' },
  { value: 'closed', label: '已截止' },
]

const assignments = computed(() => assignmentStore.list)
const isEmptyResult = computed(() => assignmentStore.isEmpty)

const listSummary = computed(() =>
  assignmentStore.loading
    ? '作业列表加载中'
    : `已显示 ${assignments.value.length} 条作业，共 ${assignmentStore.total} 条`,
)

const courseTitleMap = computed(() => {
  const map = new Map<string, string>()
  for (const course of courseOptions.value) {
    map.set(course.id, course.title)
  }
  return map
})

const confirmTarget = computed(() => {
  if (confirmTargetId.value === null) {
    return null
  }
  return assignments.value.find((item) => item.id === confirmTargetId.value) ?? null
})

watch(
  () => assignmentStore.query.keyword,
  (keyword) => {
    keywordInput.value = keyword
  },
)

function submitQuery(): void {
  void assignmentStore.applyQuery({ keyword: keywordInput.value.trim() })
}

function resetQuery(): void {
  keywordInput.value = ''
  void assignmentStore.resetQuery()
}

function onCourseChange(event: Event): void {
  void assignmentStore.applyQuery({ courseId: (event.target as HTMLSelectElement).value })
}

function onStatusChange(event: Event): void {
  void assignmentStore.applyQuery({
    status: (event.target as HTMLSelectElement).value as AssignmentStatus | '',
  })
}

function onPageChange(page: number, size: number): void {
  if (size !== assignmentStore.size) {
    void assignmentStore.setSize(size)
    return
  }
  void assignmentStore.setPage(page)
}

function askRemove(assignmentId: string): void {
  confirmTargetId.value = assignmentId
  confirmError.value = null
}

async function confirmRemove(): Promise<void> {
  const assignmentId = confirmTargetId.value
  if (assignmentId === null) {
    return
  }
  deleting.value = true
  confirmError.value = null
  try {
    await assignmentStore.removeAssignment(assignmentId)
    actionMessage.value = '作业已删除，列表与分页已同步。'
    confirmTargetId.value = null
  } catch (error) {
    confirmError.value = error instanceof Error ? error.message : '删除失败'
  } finally {
    deleting.value = false
  }
}

function formatDateTime(value: string): string {
  const date = new Date(value)
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString('zh-CN', { hour12: false })
}

/** 已过截止时间的作业给出显式文字提示，避免只靠颜色区分 */
function dueText(dueAt: string): string {
  const due = new Date(dueAt)
  if (Number.isNaN(due.getTime())) {
    return '时间格式异常'
  }
  return due.getTime() < Date.now() ? '已过期' : '截止时间未到'
}

onMounted(() => {
  void assignmentStore.fetchList()
  void courseService
    .list({ keyword: '', term: '', category: '', status: '', page: 1, size: 100, sort: 'title,asc' })
    .then((result) => {
      courseOptions.value = result.list
    })
    .catch(() => {
      courseOptions.value = []
    })
})
</script>

<template>
  <div class="stack">
    <div class="page-head">
      <div>
        <h1>作业管理</h1>
        <p class="page-head__desc">
          数据来自 <code>GET /api/v1/assignments</code>。本页演示"列表查询 + 分页 + 删除"，
          新增与编辑表单按分工由第 2 章实现（契约已在本仓库 <code>docs/api-contract-v1.md</code> 中定稿）。
        </p>
      </div>
    </div>

    <section class="surface section stack">
      <form class="toolbar query-form" @submit.prevent="submitQuery">
        <div class="field query-form__field">
          <label class="field__label" for="assignment-keyword">关键字</label>
          <input
            id="assignment-keyword"
            v-model="keywordInput"
            class="input"
            type="search"
            name="keyword"
            placeholder="作业标题"
          />
        </div>

        <div class="field query-form__field">
          <label class="field__label" for="assignment-course-filter">所属课程</label>
          <select
            id="assignment-course-filter"
            class="select"
            name="courseId"
            :value="assignmentStore.query.courseId"
            @change="onCourseChange"
          >
            <option value="">全部课程</option>
            <option v-for="course in courseOptions" :key="course.id" :value="course.id">
              {{ course.title }}
            </option>
          </select>
        </div>

        <div class="field query-form__field">
          <label class="field__label" for="assignment-status-filter">状态</label>
          <select
            id="assignment-status-filter"
            class="select"
            name="status"
            :value="assignmentStore.query.status"
            @change="onStatusChange"
          >
            <option value="">全部状态</option>
            <option v-for="option in STATUS_OPTIONS" :key="option.value" :value="option.value">
              {{ option.label }}
            </option>
          </select>
        </div>

        <div class="row query-form__actions">
          <button type="submit" class="btn btn--primary">查询</button>
          <button type="button" class="btn" @click="resetQuery">重置</button>
        </div>
      </form>

      <p class="page-head__desc" aria-live="polite">{{ listSummary }}</p>

      <p v-if="actionMessage" class="alert alert--success" role="status">
        <span class="alert__icon" aria-hidden="true">✓</span>
        <span>{{ actionMessage }}</span>
      </p>

      <p v-if="assignmentStore.error" class="alert alert--error" role="alert">
        <span class="alert__icon" aria-hidden="true">!</span>
        <span>{{ assignmentStore.error }}</span>
        <button type="button" class="btn btn--sm" @click="assignmentStore.fetchList()">重试</button>
      </p>

      <div v-if="assignmentStore.loading" class="skeleton-stack">
        <p class="sr-only">作业列表加载中</p>
        <div class="skeleton"></div>
        <div class="skeleton"></div>
      </div>

      <EmptyState
        v-else-if="isEmptyResult"
        :title="assignmentStore.hasActiveQuery ? '没有符合条件的作业' : '暂无作业数据'"
        :description="
          assignmentStore.hasActiveQuery
            ? '试着放宽关键字或清空课程、状态筛选。'
            : 'Mock 服务启动后会自动载入示例作业数据。'
        "
        :action-text="assignmentStore.hasActiveQuery ? '清空查询条件' : ''"
        @action="resetQuery"
      />

      <div v-else class="table-wrap">
        <table class="data-table">
          <caption>
            作业列表。排序固定为 <code>dueAt,asc</code>（截止时间早的排在前面），
            同分时按 <code>id,asc</code> 兜底。
          </caption>
          <thead>
            <tr>
              <th scope="col">作业标题</th>
              <th scope="col">所属课程</th>
              <th scope="col">截止时间</th>
              <th scope="col">时间状态</th>
              <th scope="col" class="data-table__num">满分</th>
              <th scope="col" class="data-table__num">已提交</th>
              <th scope="col">状态</th>
              <th v-if="authStore.canManageAssignment" scope="col">操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="assignment in assignments" :key="assignment.id">
              <td>{{ assignment.title }}</td>
              <td>{{ courseTitleMap.get(assignment.courseId) ?? assignment.courseId }}</td>
              <td>{{ formatDateTime(assignment.dueAt) }}</td>
              <td>{{ dueText(assignment.dueAt) }}</td>
              <td class="data-table__num">{{ assignment.maxScore }}</td>
              <td class="data-table__num">{{ assignment.submitCount }}</td>
              <td><StatusTag :value="assignment.status" domain="assignment" /></td>
              <td v-if="authStore.canManageAssignment">
                <button
                  type="button"
                  class="btn btn--sm btn--danger"
                  @click="askRemove(assignment.id)"
                >
                  删除
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <AppPagination
        v-if="!isEmptyResult"
        :page="assignmentStore.page"
        :size="assignmentStore.size"
        :total="assignmentStore.total"
        :disabled="assignmentStore.loading"
        @change="onPageChange"
      />
    </section>

    <div v-if="confirmTarget" class="modal-backdrop" @click.self="confirmTargetId = null">
      <section
        class="modal"
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="confirm-assignment-title"
        aria-describedby="confirm-assignment-desc"
      >
        <h2 id="confirm-assignment-title">确认删除作业</h2>
        <p id="confirm-assignment-desc">
          删除「{{ confirmTarget.title }}」后，该作业及其提交记录将从列表移除。此操作不可撤销。
        </p>
        <p v-if="confirmError" class="alert alert--error" role="alert">
          <span class="alert__icon" aria-hidden="true">!</span>
          <span>{{ confirmError }}</span>
        </p>
        <div class="modal__foot">
          <button type="button" class="btn" :disabled="deleting" @click="confirmTargetId = null">
            取消
          </button>
          <button type="button" class="btn btn--danger" :disabled="deleting" @click="confirmRemove">
            {{ deleting ? '删除中…' : '确定删除' }}
          </button>
        </div>
      </section>
    </div>
  </div>
</template>

<style scoped>
.query-form {
  align-items: flex-end;
}

.query-form__field {
  flex: 1 1 180px;
}

.query-form__actions {
  flex: 0 0 auto;
}

.modal-backdrop {
  position: fixed;
  inset: 0;
  z-index: 40;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--space-5);
  background: rgba(16, 26, 48, 0.42);
}

.modal {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
  width: min(460px, 100%);
  padding: var(--space-5);
  border-radius: var(--radius-lg);
  background: var(--color-surface);
  box-shadow: var(--shadow-md);
}

.modal__foot {
  display: flex;
  gap: var(--space-3);
  justify-content: flex-end;
}
</style>
