# 课程学习与作业管理平台　REST 接口契约 v1.0.0

> 本文件是前后端共同遵守的唯一接口依据。评价标准只有一条：
> **把这份文档交给一个没有参加过讨论的同学，他能不能不问任何问题就把后端接口实现出来。**
> 因此下面所有"校验规则""失败响应"都写到可以直接照着敲代码的程度。

---

## 1. 文档头

| 项 | 内容 |
| --- | --- |
| 契约版本 | `v1.0.0` |
| 适用范围 | 课程学习与作业管理平台的 Web 前端（Vue 3）与本项目 Mock 服务 / 后续真实后端 |
| 基础路径 | `/api/v1`（开发环境由 Vite 代理 `http://localhost:3000`；生产环境为同域部署） |
| 数据格式 | 请求与响应均为 `application/json; charset=utf-8`，请求体最大 64 KB |
| 时间格式 | ISO 8601 UTC，毫秒精度，例如 `2026-09-16T06:21:33.412Z`；前端负责按本地时区展示 |
| 字符与命名 | 请求体与响应字段统一 `camelCase`；路径分段用 `kebab-case`；枚举值统一英文小写 |
| 认证方式 | Bearer Token。`Authorization: Bearer <token>`，令牌有效期 7200 秒，由 `POST /auth/login` 下发 |
| 幂等性 | `GET` / `PUT` / `DELETE` 幂等；`POST` 非幂等（重复提交会产生新资源） |
| 版本变更规则 | 兼容性新增（加字段、加端点）→ 次版本号 +1；不兼容变更（删字段、改语义、改路径）→ 主版本号 +1 并新建 `api-contract-v2.md`，`v1` 至少并行维护 4 周；任何变更必须写进第 7 节"变更记录" |
| 契约负责人 | 第 1 组（第 1 章前端组）：契约评审通过后冻结；修改需在组会上确认并在变更记录中登记 |
| 最后更新 | 2026-09-16 |

**本契约不包含的内容**：文件上传（作业附件）、成绩导出的具体列定义、消息推送。这三项分别在第 3、4 章立项，产生新端点时按版本变更规则追加。

---

## 2. 统一返回信封

所有端点（**包括失败响应**）都返回同一结构，前端只写一套解析逻辑。

### 2.1 字段表

| 字段 | 类型 | 必返 | 说明 |
| --- | --- | --- | --- |
| `code` | number | 是 | 业务状态码，`0` 表示业务成功；非 0 见第 3 节 |
| `message` | string | 是 | 面向人的提示文本。成功时为 `OK` 或简短说明；失败时说明"哪里错了" |
| `data` | object \| array \| null | 是 | 业务数据。成功时为结果对象；业务失败时为 `null`；参数校验失败时为 `{ "errors": [...] }`（见 2.4） |
| `timestamp` | string | 是 | 服务端生成该响应的时间（ISO 8601 UTC，毫秒精度） |
| `requestId` | string | 是 | 请求追踪号（UUID v4），与响应头 `X-Request-Id` 相同 |

### 2.2 成功示例

```http
GET /api/v1/courses?page=1&size=2
```

```json
{
  "code": 0,
  "message": "OK",
  "data": {
    "list": [
      {
        "id": "C1015",
        "code": "CS1015",
        "title": "程序设计基础实践",
        "teacherName": "王砚秋",
        "term": "2025-2026-2",
        "category": "general",
        "credits": 1,
        "capacity": 150,
        "enrolledCount": 148,
        "status": "archived",
        "description": "面向新生的编程入门实践，已归档。",
        "createdAt": "2026-08-17T02:00:00.000Z",
        "updatedAt": "2026-08-27T02:00:00.000Z"
      }
    ],
    "total": 15,
    "page": 1,
    "size": 2
  },
  "timestamp": "2026-09-16T06:21:33.412Z",
  "requestId": "3f9c1d42-6b7e-4f0a-9c2d-51b8e0a7d3a1"
}
```

### 2.3 失败示例

```json
{
  "code": 30001,
  "message": "课程代码 CS1001 已存在（课程：数据结构与算法）",
  "data": null,
  "timestamp": "2026-09-16T06:22:10.008Z",
  "requestId": "b1a7c2e0-9f43-4d55-8a10-77c2f9ef0d31"
}
```

### 2.4 参数校验失败的 `data`

```json
{
  "code": 10001,
  "message": "参数校验失败：code 必须是 2 位大写字母 + 4 位数字，例如 CS1001；credits 必须在 0.5~10 之间",
  "data": {
    "errors": [
      { "field": "code", "message": "必须是 2 位大写字母 + 4 位数字，例如 CS1001" },
      { "field": "credits", "message": "必须在 0.5~10 之间" }
    ]
  },
  "timestamp": "2026-09-16T06:23:02.540Z",
  "requestId": "0d5b41c7-33a2-4c8f-9d7e-6b1f0a2c48e9"
}
```

**`message` 拼接规则（写操作端点统一适用）**：

1. 固定前缀 `参数校验失败：`；
2. 每条错误写作 `<字段名> <空格> <原因>`，例如 `title 长度必须在 2~60 个字符之间`；
3. 多条之间用中文分号 `；` 连接，**按请求体中字段出现的顺序**排列；
4. 最多展示 5 条，超过 5 条时在末尾追加 `等 N 项`（N 为实际错误总数）；
5. `data.errors` 数组**始终返回全部错误**，前端据此把错误标到对应表单字段上。

### 2.5 为什么信封里必须有 `timestamp`

1. **排查"看到的是不是缓存"**：前端把 `timestamp` 和本地时间一起打印，一眼就能判断列表是刚拉的还是几秒前的旧数据。
2. **对齐前后端时钟**：`timestamp` 与 `requestId` 一起写入日志，跨端比对时不必怀疑两端机器时间不一致。
3. **页面提示与审计**：界面可以直接显示"统计口径生成于 xx:xx"（我们的概览页就是这样显示 `generatedAt` / `timestamp` 的），后端日志也能按时间窗口归档。
4. **配合幂等与重试**：重试请求时，同一个 `requestId` 的多次记录可以按 `timestamp` 排序找出真正生效的那一次。

---

## 3. 业务状态码表

| code | 名称 | 对应 HTTP | 触发场景 | `message` 示例 |
| --- | --- | --- | --- | --- |
| `0` | SUCCESS | 200（创建成功为 **201**） | 业务处理成功 | `OK` / `课程创建成功` |
| `10001` | PARAM_INVALID | 400 | 必填缺失、格式/范围不合法、JSON 非法、`size` 超范围 | `参数校验失败：credits 必须在 0.5~10 之间` |
| `10002` | RESOURCE_NOT_FOUND | 404 | 路径参数指向的资源不存在，或端点不存在 | `课程不存在：C9999` |
| `10003` | METHOD_NOT_ALLOWED | 405 | 路径存在但方法不被支持（真实后端由网关返回；Mock 不触发） | `该端点不支持 POST 方法` |
| `20001` | UNAUTHENTICATED | 401 | 未带令牌、令牌无效或已过期、登录口令错误 | `未提供访问令牌或令牌已过期，请重新登录` |
| `20002` | FORBIDDEN | 403 | 已登录但角色不足，或不是该数据的所有者 | `该操作需要 teacher 或 admin 角色，当前角色为 student` |
| `30001` | BUSINESS_CONFLICT | **200** | 唯一性冲突、状态冲突（如重复选课、已是目标状态、重复退课） | `课程代码 CS1001 已存在（课程：数据结构与算法）` |
| `30002` | RULE_VIOLATION | **200** | 业务规则不满足（容量已满、作业已截止、仍有未截止作业不能删除课程） | `课程容量已满（50/50），无法选课` |
| `40001` | RATE_LIMITED | 429 | 同一 IP/账号在时间窗内请求过多（预留，Mock 未实现） | `请求过于频繁，请 60 秒后重试` |
| `50000` | INTERNAL_ERROR | 500 | 服务端未预期异常 | `服务端内部错误，请稍后重试` |

### 3.1 为什么"业务失败"用 HTTP 200

`30001` / `30002` 两类失败**在协议层是成功的**：请求被正确理解、被正确处理，服务器也没有崩溃，只是业务规则不允许。把它们映射成 4xx/5xx 会带来三个具体麻烦：

1. **前端被迫写两套错误分支**：`axios` 的 `catch` 只处理 HTTP 错误，业务失败走 `catch`、业务成功走 `then`，同一段"把错误显示到表单"的逻辑要写两遍。约定"业务失败也是 200"之后，前端只需判断 `code !== 0`。
2. **无法区分"网络/权限问题"与"用户操作问题"**：`403` 意味着"你换个身份再试"，`30001` 意味着"你把课程代码改一下再提交"。混在同一层状态码里，UI 只能提示一句笼统的"操作失败"。
3. **代理与网关会改写状态码**：部分反向代理/网关对 4xx/5xx 有重试、熔断或统一错误页行为，业务冲突被误判成系统故障。业务语义放在 body 里最稳。

与此同时，**参数错误、未登录、权限不足仍然使用真实的 HTTP 状态码**（400/401/403/404），因为它们描述的是"调用方式错了"，不是"业务不允许"。

---

## 4. 分页返回结构

所有列表端点（`GET /courses`、`GET /assignments`、`GET /assignments/{id}/submissions`）的成功响应中，`data` 固定为：

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `list` | array | 当前页数据数组，元素结构见第 5 节数据字典；无数据时为 `[]`（不是 `null`） |
| `total` | number | **符合查询条件的记录总数**（不是当前页条数） |
| `page` | number | 实际页码，从 `1` 开始 |
| `size` | number | 实际每页条数 |

### 4.1 请求参数规则

| 参数 | 类型 | 默认值 | 校验规则 | 非法时的响应 |
| --- | --- | --- | --- | --- |
| `page` | number | `1` | 必须是 ≥ 1 的整数 | `400` + `10001`，`field = "page"` |
| `size` | number | `10` | 必须是 1~100 的整数 | `400` + `10001`，`field = "size"` |
| `sort` | string | 见 4.3 | 必须在白名单内 | `400` + `10001`，`field = "sort"` |

**页码越界行为（必须实现，前端依赖它）**：当 `page` 大于总页数时，服务端**不报错**，而是返回最后一页，并把响应中的 `page` 改为实际页码。例如 14 条数据、`size=5`、请求 `page=999`，返回 `page=3`、`total=14`。前端在每次取数后用响应里的 `page` / `size` 覆盖本地状态，从而不会出现"分页器停在第 999 页、列表却是空的"。

### 4.2 排序规则

1. 排序表达式格式为 `字段,方向`，方向只能是 `asc` / `desc`；方向缺省时按 `asc`。
2. 白名单（超出白名单一律 `10001`）：
   - 课程列表：`createdAt,desc`（默认）、`createdAt,asc`、`credits,desc`、`enrolledCount,desc`
   - 作业列表：`dueAt,asc`（默认）、`dueAt,desc`、`publishAt,desc`、`createdAt,desc`
3. **兜底排序**：主排序字段取值相同时，一律按 `id` 升序（`id,asc`）作为第二排序键，保证分页结果在同一数据集上稳定可复现，不会出现"翻页时同一条记录出现两次"。
4. 排序字段的可用值以"排序时的实际值"为准（例如 `enrolledCount` 是服务端统计出来的值，不是存储字段）。

---

## 5. 数据字典

### 5.1 Course（课程，主业务实体）

| 字段 | 类型 | 必填 | 由谁生成 | 校验规则 | 枚举取值 | 说明 |
| --- | --- | --- | --- | --- | --- | --- |
| `id` | string | 是 | 服务端 | 只读，格式 `C` + 4 位数字 | — | 主键，例如 `C1001` |
| `code` | string | 是 | 客户端 | 正则 `^[A-Z]{2}\d{4}$`，**全校唯一**（唯一冲突返回 `30001`） | — | 课程代码，例如 `CS1001` |
| `title` | string | 是 | 客户端 | 去首尾空格后长度 2~60 个字符 | — | 课程名称 |
| `teacherName` | string | 是 | 客户端 | 去首尾空格后长度 1~20 个字符；`teacher` 角色提交时必须等于本人姓名 | — | 任课教师姓名（v1 用姓名而非 id，见第 7 节待确认项 1） |
| `term` | string | 是 | 客户端 | 正则 `^\d{4}-\d{4}-[12]$` | — | 学年学期，例如 `2026-2027-1` |
| `category` | string | 是 | 客户端 | 枚举 | `required` 必修 / `elective` 选修 / `general` 通识 | 课程类别 |
| `credits` | number | 是 | 客户端 | 0.5 ≤ credits ≤ 10，且是 0.5 的整数倍 | — | 学分 |
| `capacity` | number | 是 | 客户端 | 1 ≤ capacity ≤ 300 的整数 | — | 课程容量（人数） |
| `enrolledCount` | number | 是 | **服务端** | 只读，由选课记录统计得出 | — | 在修人数（`status != dropped` 的选课记录数 + 历史基数） |
| `status` | string | 是 | 客户端 / 服务端 | 枚举；创建时缺省 `draft`；**变更状态必须走 `PATCH /courses/{id}/status`**，不能通过 `PUT` 直接改 | `draft` 草稿 / `open` 进行中 / `closed` 已结课 / `archived` 已归档（软删除） | 课程状态 |
| `description` | string \| null | 否 | 客户端 | 长度 ≤ 200 个字符；缺省为 `null` | — | 课程简介 |
| `createdAt` | string | 是 | **服务端** | 只读，ISO 8601 UTC | — | 创建时间 |
| `updatedAt` | string | 是 | **服务端** | 只读，每次写操作刷新 | — | 最近更新时间 |

### 5.2 Assignment（作业）

| 字段 | 类型 | 必填 | 由谁生成 | 校验规则 | 枚举取值 | 说明 |
| --- | --- | --- | --- | --- | --- | --- |
| `id` | string | 是 | 服务端 | 只读，格式 `A` + 4 位数字 | — | 主键，例如 `A2001` |
| `courseId` | string | 是 | 客户端 | 必须指向已存在的课程，否则 `404` + `10002` | — | 所属课程 |
| `title` | string | 是 | 客户端 | 长度 2~60 个字符 | — | 作业标题 |
| `description` | string \| null | 否 | 客户端 | 长度 ≤ 500 个字符 | — | 作业要求 |
| `publishAt` | string | 是 | 客户端 | ISO 8601；不可为 `null` | — | 发布时间 |
| `dueAt` | string | 是 | 客户端 | ISO 8601，**必须严格晚于 `publishAt`**，否则 `10001` | — | 截止时间 |
| `maxScore` | number | 是 | 客户端 | 1~100 的整数 | — | 满分 |
| `status` | string | 是 | 客户端 / 服务端 | 枚举；创建时缺省 `draft` | `draft` 未发布 / `published` 已发布 / `closed` 已截止 | 作业状态 |
| `submitCount` | number | 是 | **服务端** | 只读，`> 0` 时不允许删除该作业（`30002`） | — | 已提交份数 |
| `createdAt` / `updatedAt` | string | 是 | **服务端** | 只读 | — | 创建 / 更新时间 |

### 5.3 Enrollment（选课记录）

| 字段 | 类型 | 必填 | 由谁生成 | 校验规则 | 枚举取值 | 说明 |
| --- | --- | --- | --- | --- | --- | --- |
| `id` | string | 是 | 服务端 | 只读，格式 `E` + 4 位数字 | — | 选课记录主键 |
| `courseId` | string | 是 | 路径参数 | 课程必须存在，且状态为 `open` | — | 课程 |
| `studentId` | string | 是 | 客户端 | 必须存在于用户表；`student` 角色只能填写本人 `id`，否则 `403` | — | 学生 |
| `studentName` | string | 是 | **服务端** | 只读，由 `studentId` 关联得出 | — | 学生姓名（列表展示用） |
| `status` | string | 是 | 服务端 | 只读 | `enrolled` 在修 / `dropped` 已退课 / `completed` 已完成 | 选课状态 |
| `score` | number \| null | 是 | 服务端 | 只读，0 ≤ score ≤ 100，未评分时为 `null` | — | 成绩 |
| `createdAt` | string | 是 | **服务端** | 只读 | — | 选课时间 |

### 5.4 User（用户）

| 字段 | 类型 | 必填 | 由谁生成 | 校验规则 | 枚举取值 | 说明 |
| --- | --- | --- | --- | --- | --- | --- |
| `id` | string | 是 | 服务端 | 只读 | — | 主键，例如 `U2001` |
| `username` | string | 是 | 客户端（登录时） | 长度 4~20，字母数字下划线 | — | 登录名 |
| `name` | string | 是 | 服务端 | 只读 | — | 显示姓名 |
| `email` | string | 是 | 服务端 | 邮箱格式；示例数据统一 `example.com` 域 | — | 邮箱 |
| `role` | string | 是 | 服务端 | 只读 | `student` 学生 / `teacher` 教师 / `admin` 管理员 | 角色 |
| `status` | string | 是 | 服务端 | 只读 | `active` 正常 / `inactive` 停用 / `locked` 锁定 | 账号状态 |
| `createdAt` / `updatedAt` | string | 是 | **服务端** | 只读 | — | 创建 / 更新时间 |

> ⚠️ **口令相关字段（`password`、任何散列或盐）只允许出现在请求体中，任何响应（含错误响应）不得回传。** 契约自检脚本会对每个响应做敏感字段扫描（`npm run test:api`）。

### 5.5 状态类字段的取值约定

1. **一律使用英文小写枚举**，中文只出现在前端展示层（见 `src/components/StatusTag.vue` 的映射表）。
2. 前端展示时必须**同时给出文字与图形符号**，不允许只靠颜色区分状态。
3. 新增枚举值时：后端先上线并保持向后兼容，前端遇到未知值按"未知状态"展示而不是崩溃（`StatusTag` 已实现该兜底）。

---

## 6. 端点清单

图例：**登录** = 是否需要认证；**角色** = 需要的角色（`公开` 表示无需登录）。

| # | 方法 | 路径 | 说明 | 登录 | 角色 | 由哪一章实现 |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | POST | `/api/v1/auth/login` | 登录并获取访问令牌 | 否 | 公开 | 第 1 章 |
| 2 | POST | `/api/v1/auth/logout` | 退出登录，令牌立即失效 | 是 | 任意已登录 | 第 1 章 |
| 3 | GET | `/api/v1/auth/me` | 获取当前登录用户 | 是 | 任意已登录 | 第 1 章 |
| 4 | GET | `/api/v1/courses` | 分页查询课程列表 | 否 | 公开 | 第 1 章 |
| 5 | GET | `/api/v1/courses/{courseId}` | 查询课程详情 | 否 | 公开 | 第 1 章 |
| 6 | POST | `/api/v1/courses` | 新建课程 | 是 | teacher / admin | 第 2 章 |
| 7 | PUT | `/api/v1/courses/{courseId}` | 全量更新课程 | 是 | teacher（本人课程）/ admin | 第 2 章 |
| 8 | PATCH | `/api/v1/courses/{courseId}/status` | 变更课程状态 | 是 | teacher（本人课程）/ admin | 第 2 章 |
| 9 | DELETE | `/api/v1/courses/{courseId}` | 删除课程（软删除） | 是 | teacher（本人课程）/ admin | 第 2 章 |
| 10 | GET | `/api/v1/courses/{courseId}/enrollments` | 查询课程选课名单 | 是 | teacher / admin | 第 3 章 |
| 11 | POST | `/api/v1/courses/{courseId}/enrollments` | 学生选课 | 是 | student（本人）/ teacher / admin | 第 3 章 |
| 12 | DELETE | `/api/v1/enrollments/{enrollmentId}` | 退课 | 是 | 本人 / teacher / admin | 第 3 章 |
| 13 | GET | `/api/v1/assignments` | 分页查询作业列表 | 否 | 公开 | 第 1 章 |
| 14 | GET | `/api/v1/assignments/{assignmentId}` | 查询作业详情 | 否 | 公开 | 第 1 章 |
| 15 | POST | `/api/v1/assignments` | 新建作业 | 是 | teacher / admin | 第 2 章 |
| 16 | PUT | `/api/v1/assignments/{assignmentId}` | 全量更新作业 | 是 | teacher / admin | 第 2 章 |
| 17 | DELETE | `/api/v1/assignments/{assignmentId}` | 删除作业 | 是 | teacher / admin | 第 2 章 |
| 18 | GET | `/api/v1/assignments/{assignmentId}/submissions` | 查询作业提交列表 | 是 | teacher / admin | 第 3 章 |
| 19 | GET | `/api/v1/statistics/overview` | 统计概览 | 是 | 任意已登录 | 第 4 章 |

**命名说明**：本契约全部使用"名词复数 + HTTP 动词"的 REST 风格，禁止出现 `/getCourseList`、`/deleteCourseById` 这类动词式路径。

### 6.1 读操作端点细则

#### 4. `GET /api/v1/courses`

- **查询参数**

  | 参数 | 类型 | 必填 | 默认 | 校验 | 说明 |
  | --- | --- | --- | --- | --- | --- |
  | `keyword` | string | 否 | `''` | 长度 ≤ 50 | 模糊匹配 `title` / `code` / `teacherName`，大小写不敏感 |
  | `term` | string | 否 | `''` | `^\d{4}-\d{4}-[12]$` 或空串 | 精确匹配学年学期 |
  | `category` | string | 否 | `''` | 枚举或空串 | 课程类别 |
  | `status` | string | 否 | `''` | 枚举或空串 | 课程状态 |
  | `page` / `size` / `sort` | — | 否 | `1` / `10` / `createdAt,desc` | 见第 4 节 | 分页与排序 |

- **默认过滤**：`status` 为空时**不返回 `archived` 课程**；显式传 `status=archived` 时返回已归档课程（回收站视图）。
- **成功返回**：`200` + `code 0`，`data` 为分页结构，元素为 `Course`。

#### 5. `GET /api/v1/courses/{courseId}`

- **路径参数**：`courseId` 必须存在，否则 `404` + `10002`。
- **成功返回**：`200` + `Course` 对象（含服务端统计的 `enrolledCount`）。

#### 10. `GET /api/v1/courses/{courseId}/enrollments`

- **成功返回**：`200` + `Enrollment[]`（不分页；单课选课记录量级可控）。按 `createdAt,asc` 返回。
- **失败**：课程不存在 → `404` + `10002`；角色不足 → `403` + `20002`。

#### 13. `GET /api/v1/assignments`

- **查询参数**：`keyword`（≤ 50，模糊匹配 `title`）、`courseId`（精确）、`status`（枚举）、`page` / `size` / `sort`（默认 `dueAt,asc`）。
- **成功返回**：`200` + 分页结构，元素为 `Assignment`。

#### 14. `GET /api/v1/assignments/{assignmentId}`

- **成功返回**：`200` + `Assignment`；不存在 → `404` + `10002`。

#### 18. `GET /api/v1/assignments/{assignmentId}/submissions`

- **成功返回**：`200` + 分页结构（`list` 元素为提交记录；v1 中提交记录字段由第 3 章补充，未实现前返回 `list: []`、`total` 等于该作业的 `submitCount`）。
- **失败**：作业不存在 → `404` + `10002`；角色不足 → `403` + `20002`。

#### 19. `GET /api/v1/statistics/overview`

- **成功返回**：`200` + 以下对象：

  | 字段 | 类型 | 统计口径 |
  | --- | --- | --- |
  | `courseTotal` | number | `status != archived` 的课程数 |
  | `openTotal` | number | `status == open` 的课程数 |
  | `creditTotal` | number | `status != archived` 课程的 `credits` 之和 |
  | `assignmentTotal` | number | 全部作业数（含草稿） |
  | `generatedAt` | string | 统计生成时间，ISO 8601 |

### 6.2 写操作端点细则

> 每个写操作都按"请求体 → 成功返回 → 校验失败 → 业务冲突 → 权限不足"五段说明。
> 通用约定：校验失败一律 `400` + `10001`，`data.errors` 为逐字段错误数组，`message` 按 2.4 的规则拼接。

#### 6. `POST /api/v1/courses`　新建课程

- **请求体**（`*` 为必填）

  | 字段 | 必填 | 说明 |
  | --- | --- | --- |
  | `code`* | 是 | `^[A-Z]{2}\d{4}$`，全校唯一 |
  | `title`* | 是 | 2~60 字符 |
  | `teacherName`* | 是 | 1~20 字符；`teacher` 角色必须等于本人姓名 |
  | `term`* | 是 | `^\d{4}-\d{4}-[12]$` |
  | `category`* | 是 | `required` / `elective` / `general` |
  | `credits`* | 是 | 0.5~10，0.5 的整数倍 |
  | `capacity`* | 是 | 1~300 整数 |
  | `status` | 否 | 缺省 `draft` |
  | `description` | 否 | ≤ 200 字符，缺省 `null` |
  | `id` / `enrolledCount` / `createdAt` / `updatedAt` | — | **服务端生成，客户端传入一律忽略** |

- **成功返回**：`201` + `code 0` + 新建的 `Course` 对象（含服务端生成的 `id`、`enrolledCount: 0`、`createdAt`、`updatedAt`）。
- **校验失败**：`400` + `10001`。示例：`{"code":10001,"message":"参数校验失败：code 必须是 2 位大写字母 + 4 位数字，例如 CS1001；credits 必须在 0.5~10 之间", "data":{"errors":[{"field":"code","message":"必须是 2 位大写字母 + 4 位数字，例如 CS1001"},{"field":"credits","message":"必须在 0.5~10 之间"}]}}`
- **业务冲突**：`code` 已存在 → `200` + `30001`，`message` 格式为 `课程代码 {code} 已存在（课程：{已存在的课程名}）`。
- **权限不足**：未登录 → `401` + `20001`；角色不是 teacher/admin → `403` + `20002`；teacher 提交的 `teacherName` 不是本人 → `403` + `20002`，`message` 为 `教师只能创建任课教师为本人（{本人姓名}）的课程`。

#### 7. `PUT /api/v1/courses/{courseId}`　全量更新课程

- **请求体**：与"新建课程"完全一致（PUT 语义：未提交的可选字段按缺省值处理，例如 `status` 缺省回 `draft`、`description` 缺省回 `null`）。`id` / `enrolledCount` / `createdAt` / `updatedAt` 仍由服务端维护。
- **成功返回**：`200` + `code 0` + 更新后的 `Course`。
- **校验失败**：`400` + `10001`（规则同新建）。
- **业务冲突 / 规则不满足**：
  - `code` 被**其它**课程占用 → `200` + `30001`，`message` 为 `课程代码 {code} 已被课程「{课程名}」占用`；
  - `capacity` 小于当前 `enrolledCount` → `200` + `30002`，`message` 为 `容量（{capacity}）不能小于当前已选人数（{enrolledCount}）`。
- **权限不足**：未登录 → `401` + `20001`；角色不足或非本人课程 → `403` + `20002`；课程不存在 → `404` + `10002`。

#### 8. `PATCH /api/v1/courses/{courseId}/status`　变更课程状态

- **请求体**：`{ "status": "open" }`，`status` 必填且必须为枚举值之一。
- **状态迁移白名单**（不在表内的迁移一律拒绝）：

  | 当前状态 | 允许迁移到 |
  | --- | --- |
  | `draft` | `open`、`archived` |
  | `open` | `closed`、`archived` |
  | `closed` | `open`、`archived` |
  | `archived` | 无（终态） |

- **成功返回**：`200` + `code 0` + 更新后的 `Course`。
- **校验失败**：`400` + `10001`（`status` 缺失或非枚举）。
- **业务冲突**：目标状态与当前状态相同 → `200` + `30001`，`message` 为 `课程当前已经是 {status} 状态`。
- **规则不满足**：非法迁移（含对 `archived` 课程操作）→ `200` + `30002`，`message` 为 `不允许从 {当前} 变更到 {目标}，允许的目标状态：{白名单}`。
- **权限不足**：`401` + `20001`；`403` + `20002`；`404` + `10002`。

#### 9. `DELETE /api/v1/courses/{courseId}`　删除课程

- **请求体**：无。
- **语义**：**软删除**，服务端把 `status` 置为 `archived` 并刷新 `updatedAt`，记录不物理删除；`GET /courses` 默认不再返回它，需要时用 `status=archived` 查看。
- **成功返回**：`200` + `code 0` + `data: null`，`message` 为 `课程已删除（软删除，status=archived）`。
  > 刻意不使用 HTTP 204：204 不允许带响应体，前端就拿不到统一信封，需要在 `axios` 里对 204 单独分支。**所有"无数据返回"的成功响应统一为 `200` + `data: null`。**
- **规则不满足**：该课程下仍有 `status=published` 且 `dueAt` 大于当前时间的作业 → `200` + `30002`，`message` 为 `该课程还有 {N} 个未截止的已发布作业，请先关闭作业后再删除课程`。
- **权限不足**：`401` + `20001`；`403` + `20002`；`404` + `10002`。

#### 11. `POST /api/v1/courses/{courseId}/enrollments`　学生选课

- **请求体**

  | 字段 | 必填 | 说明 |
  | --- | --- | --- |
  | `studentId` | 否 | 缺省为当前登录用户；`student` 角色若填写他人 `id` → `403` + `20002`；`teacher` / `admin` 可指定任意学生 |
  | `id` / `status` / `score` / `createdAt` | — | **服务端生成，客户端传入一律忽略** |

- **成功返回**：`201` + `code 0` + 新建的 `Enrollment`（含 `studentName`、`status: "enrolled"`、`score: null`）。
- **校验失败**：`400` + `10001`。本端点只有路径参数与 `studentId`，若 `studentId` 非字符串同样返回 `10001`。
- **业务冲突**：该学生在该课程已有 `status != dropped` 的记录 → `200` + `30001`，`message` 为 `学生 {姓名} 已在课程「{课程名}」中，不能重复选课`。
- **规则不满足**（均为 `200` + `30002`）：
  - 课程状态不是 `open` → `课程当前状态为 {status}，只有 open 状态的课程可选`；
  - `enrolledCount >= capacity` → `课程容量已满（{已选}/{容量}），无法选课`。
- **权限不足 / 不存在**：未登录 → `401` + `20001`；学生为他人选课 → `403` + `20002`；课程不存在 → `404` + `10002`（`studentId` 指向不存在的用户同样 `404` + `10002`）。

#### 12. `DELETE /api/v1/enrollments/{enrollmentId}`　退课

- **请求体**：无。
- **语义**：软删除，`status` 由 `enrolled` 变为 `dropped`。
- **成功返回**：`200` + `code 0` + `data: null`。
- **业务冲突**：当前状态不是 `enrolled`（如重复退课）→ `200` + `30001`，`message` 为 `当前选课状态为 {status}，只有 enrolled 状态可以退课`。
- **权限不足 / 不存在**：学生退选他人课程 → `403` + `20002`；未登录 → `401` + `20001`；记录不存在 → `404` + `10002`。

#### 15. `POST /api/v1/assignments`　新建作业

- **请求体**（`*` 为必填）

  | 字段 | 必填 | 说明 |
  | --- | --- | --- |
  | `courseId`* | 是 | 必须指向已存在课程 |
  | `title`* | 是 | 2~60 字符 |
  | `description` | 否 | ≤ 500 字符，缺省 `null` |
  | `publishAt`* | 是 | ISO 8601 |
  | `dueAt`* | 是 | ISO 8601，必须严格晚于 `publishAt` |
  | `maxScore`* | 是 | 1~100 整数 |
  | `status` | 否 | 缺省 `draft` |
  | `id` / `submitCount` / `createdAt` / `updatedAt` | — | **服务端生成，客户端传入一律忽略** |

- **成功返回**：`201` + `code 0` + 新建的 `Assignment`（`submitCount: 0`）。
- **校验失败**：`400` + `10001`。示例：`{"code":10001,"message":"参数校验失败：dueAt 必须晚于 publishAt","data":{"errors":[{"field":"dueAt","message":"必须晚于 publishAt"}]}}`
- **业务冲突**：本端点暂无唯一性约束；同一课程下允许同名作业（若后续要求"同课程标题唯一"，见第 7 节待确认项 2）。
- **权限不足 / 不存在**：未登录 → `401` + `20001`；角色不是 teacher/admin → `403` + `20002`；`courseId` 指向的课程不存在 → `404` + `10002`，`message` 为 `courseId 对应的课程不存在：{courseId}`。

#### 16. `PUT /api/v1/assignments/{assignmentId}`　全量更新作业

- **请求体**：与新建一致。
- **成功返回**：`200` + `code 0` + 更新后的 `Assignment`（`submitCount` 由服务端保持，不接受客户端修改）。
- **校验失败**：`400` + `10001`。
- **规则不满足**：作业当前 `status == closed` → `200` + `30002`，`message` 为 `已截止（closed）的作业不允许再修改`。
- **权限不足 / 不存在**：`401` + `20001`；`403` + `20002`；`404` + `10002`。

#### 17. `DELETE /api/v1/assignments/{assignmentId}`　删除作业

- **请求体**：无。
- **语义**：物理删除（作业与提交记录同生命周期，提交记录由第 3 章实现）。
- **成功返回**：`200` + `code 0` + `data: null`。
- **规则不满足**：`submitCount > 0` → `200` + `30002`，`message` 为 `该作业已有 {N} 份提交，不能删除`。
- **权限不足 / 不存在**：`401` + `20001`；`403` + `20002`；`404` + `10002`。

#### 1. `POST /api/v1/auth/login`　登录

- **请求体**：`username`（必填，4~20 字符）、`password`（必填，8~32 字符）。**口令只出现在请求体中。**
- **成功返回**：`200` + `code 0` + `{ token, expiresIn, user }`，`user` 为 `User` 对象（不含任何口令字段）。
- **校验失败**：`400` + `10001`（字段缺失或格式不符）。
- **业务失败**：用户名不存在或口令错误 → `401` + `20001`，`message` 统一为 `用户名或口令错误`（**不区分"用户不存在"与"口令错误"，避免账号枚举**）。
- **权限不足**：账号 `status != active` → `403` + `20002`，`message` 为 `账号状态为 {status}，无法登录`。

#### 2. `POST /api/v1/auth/logout`　退出登录

- **请求体**：无。
- **成功返回**：`200` + `code 0` + `data: null`；此后同一令牌访问任何受保护端点都返回 `401` + `20001`。
- **权限不足**：未登录 → `401` + `20001`。

---

## 7. 待确认事项与变更记录

### 7.1 待确认事项（需要第 2 周课前与老师/后端组一起销项）

| # | 待确认事项 | 当前临时约定 | 影响范围 | 计划确认时间 |
| --- | --- | --- | --- | --- |
| 1 | `Course.teacherName` 用"姓名"还是"用户 id" | v1 用姓名，接口层不校验重名 | 若改为 `teacherId`，则 `Course`、`CourseInput` 与前端表单都要改，属于不兼容变更 | 第 2 周课前 |
| 2 | 同一课程下是否允许作业标题重复 | v1 允许重复 | 若要求唯一，需新增 `30001` 冲突分支与前端提示 | 第 2 周课前 |
| 3 | `GET /courses/{id}/enrollments` 是否需要分页 | v1 不分页，一次性返回 | 单门课选课人数超过 200 时响应体过大，需要改成第 4 节分页结构 | 第 3 章立项时 |
| 4 | 退课后重新选课是否复用原记录 | v1 新建一条记录（历史保留） | 影响 `enrolledCount` 统计口径与成绩归属 | 第 3 章立项时 |
| 5 | 令牌续期方式（刷新令牌 / 滑动过期） | v1 只有 7200 秒固定有效期，过期即重新登录 | 影响前端 `401` 拦截逻辑与登录页 | 第 4 章立项时 |
| 6 | 统计口径是否包含 `draft` 课程 | v1 包含（只排除 `archived`） | 影响概览页数字与课程列表筛选的一致性 | 第 2 周课前 |

### 7.2 变更记录

| 版本 | 日期 | 修改人 | 变更说明 |
| --- | --- | --- | --- |
| v1.0.0 | 2026-09-15 | 第 1 组·前端组 | 初稿：确定统一信封、业务状态码表、分页结构、Course/Assignment/Enrollment/User 数据字典与 19 个端点 |
| v1.0.0 | 2026-09-15 | 第 1 组·前端组 | 评审修订：明确"业务失败用 HTTP 200"的适用范围；补充 `page` 越界夹紧规则与 `id,asc` 兜底排序；删除响应中所有口令字段 |
| v1.0.0 | 2026-09-16 | 第 1 组·前端组 | 联调修订：删除成功统一为 `200` + `data: null`（不用 204）；`DELETE /courses/{id}` 增加"存在未截止已发布作业时返回 30002"的规则；补充 6 条待确认事项 |

### 7.3 契约自检

契约不是"写完就算"，本仓库提供了可执行的验收脚本，逐条验证上面的成功与失败路径：

```bash
npm run test:api
```

脚本会自行拉起 Mock 服务并输出 48 条用例结果，同时检查：

1. 每个响应都符合第 2 节的统一信封（字段齐全、`timestamp` 可解析、`requestId` 与响应头 `X-Request-Id` 一致）；
2. 每个响应都不包含 `password` / `tokenHash` 等敏感字段。

最新一次运行结果见 `evidence/api-smoke.txt`。

---

## 8. 前端调用约定（写给同组前端同学）

1. **只通过 `src/services/*` 调用接口**，展示组件内不出现 `axios`、不读 `route` / `store`。
2. `src/services/api.ts` 已做统一拆信封：成功resolve `data`，失败抛出 `ApiError`（含 `code`、`httpStatus`、`errors`）。
3. 需要"逐字段标红"的表单，直接读取 `ApiError.errors`，字段名与第 5 节数据字典一致。
4. 分页列表取数后，用响应里的 `page` / `size` 覆盖本地状态，不要假设请求页一定被采纳。
5. 新增端点时，同步更新本节、第 6 节端点清单与本文件第 7.2 节变更记录，三者缺一不可。
